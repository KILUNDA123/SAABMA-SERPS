import 'reflect-metadata';
import { DataSource } from 'typeorm';
import { config } from 'dotenv';
import { allEntities } from './config/database.config';

// This file exists ONLY for the TypeORM CLI (migration:generate,
// migration:run, migration:revert) - NestJS itself uses
// TypeOrmModule.forRoot(getDatabaseConfig()) in app.module.ts, not this.
// They share the same `allEntities` list so a migration generated here is
// always checked against the exact same schema the running app expects.
config();

export const AppDataSource = new DataSource({
  type: 'postgres',
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432', 10),
  username: process.env.DB_USER || 'saabma',
  password: process.env.DB_PASSWORD || 'changeme',
  database: process.env.DB_NAME || 'saabma_serps',
  entities: allEntities,
  migrations: [__dirname + '/migrations/*{.js,.ts}'],
  synchronize: false,
});
