import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { AuditLog } from '../../modules/audit/entities/audit-log.entity';

// Applied globally (see app.module.ts). Fires AFTER any POST/PATCH/PUT/DELETE
// request completes successfully, writing a row to audit_logs with who did
// it, what route/method, and the response body as "newValue". This is
// intentionally simple - a route-level log, not a field-by-field entity
// diff - so it works uniformly across every module without each one having
// to wire up its own auditing. "Nothing can disappear without a trace."
@Injectable()
export class AuditInterceptor implements NestInterceptor {
  constructor(
    @InjectRepository(AuditLog)
    private readonly auditLogRepository: Repository<AuditLog>,
  ) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const request = context.switchToHttp().getRequest();
    const method = request.method;

    const mutating = ['POST', 'PATCH', 'PUT', 'DELETE'].includes(method);
    if (!mutating) {
      return next.handle();
    }

    return next.handle().pipe(
      tap((responseBody) => {
        // Fire-and-forget: auditing must never slow down or break the
        // actual request, so we don't await this or let it throw upward.
        this.writeLog(request, method, responseBody).catch(() => {
          /* deliberately swallowed - see comment above */
        });
      }),
    );
  }

  private async writeLog(request: any, method: string, responseBody: any): Promise<void> {
    const entityType = request.route?.path?.split('/')[1] || request.url;
    const entityId = responseBody?.id || request.params?.id || null;

    const log = this.auditLogRepository.create({
      user: request.user ? { id: request.user.userId } : undefined,
      action: method,
      entityType,
      entityId,
      newValue: this.safeSerialize(responseBody),
      ipAddress: request.ip,
      userAgent: request.headers?.['user-agent'],
    });

    await this.auditLogRepository.save(log);
  }

  private safeSerialize(value: any): any {
    try {
      const json = JSON.parse(JSON.stringify(value));
      return this.redact(json);
    } catch {
      return null;
    }
  }

  // Fields that must never land in the audit log, wherever they appear in a
  // response body: password hashes, live JWTs, and admin-generated
  // temporary passwords. Recursive, since e.g. POST /auth/login's response
  // nests { user: {...}, accessToken, ... }.
  private static readonly REDACTED_KEYS = new Set([
    'passwordHash',
    'password',
    'accessToken',
    'refreshToken',
    'temporaryPassword',
    'currentPassword',
    'newPassword',
  ]);

  private redact(value: any): any {
    if (Array.isArray(value)) {
      return value.map((item) => this.redact(item));
    }
    if (value && typeof value === 'object') {
      const out: Record<string, any> = {};
      for (const [key, val] of Object.entries(value)) {
        out[key] = AuditInterceptor.REDACTED_KEYS.has(key) ? '[REDACTED]' : this.redact(val);
      }
      return out;
    }
    return value;
  }
}
