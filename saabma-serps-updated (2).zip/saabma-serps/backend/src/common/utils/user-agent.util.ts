// Lightweight User-Agent parsing - deliberately not a heavyweight dependency.
// Good enough for the three things the login-monitoring dashboard needs:
// device type, OS, and browser name. Not exhaustive; falls back to "Unknown"
// rather than guessing.

export interface ParsedUserAgent {
  deviceType: 'Mobile' | 'Tablet' | 'Desktop' | 'Unknown';
  os: string;
  browser: string;
}

export function parseUserAgent(userAgent?: string | null): ParsedUserAgent {
  if (!userAgent) {
    return { deviceType: 'Unknown', os: 'Unknown', browser: 'Unknown' };
  }
  const ua = userAgent;

  let deviceType: ParsedUserAgent['deviceType'] = 'Desktop';
  if (/iPad|Tablet(?!.*Mobile)/i.test(ua)) {
    deviceType = 'Tablet';
  } else if (/Mobile|iPhone|Android/i.test(ua)) {
    deviceType = 'Mobile';
  } else if (!/Windows|Macintosh|Linux|X11/i.test(ua)) {
    deviceType = 'Unknown';
  }

  let os = 'Unknown';
  if (/Windows NT/i.test(ua)) os = 'Windows';
  else if (/Mac OS X/i.test(ua)) os = 'macOS';
  else if (/Android/i.test(ua)) os = 'Android';
  else if (/iPhone OS|iPad.*OS/i.test(ua)) os = 'iOS';
  else if (/Linux/i.test(ua)) os = 'Linux';

  let browser = 'Unknown';
  if (/Edg\//i.test(ua)) browser = 'Edge';
  else if (/OPR\//i.test(ua)) browser = 'Opera';
  else if (/Chrome\//i.test(ua) && !/Chromium/i.test(ua)) browser = 'Chrome';
  else if (/Firefox\//i.test(ua)) browser = 'Firefox';
  else if (/Safari\//i.test(ua) && !/Chrome/i.test(ua)) browser = 'Safari';

  return { deviceType, os, browser };
}
