import { MigrationInterface, QueryRunner } from "typeorm";

export class AddRevenueHistoryTable1784009418756 implements MigrationInterface {
    name = 'AddRevenueHistoryTable1784009418756'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "revenue_history" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "period" date NOT NULL, "revenue" numeric(12,2) NOT NULL DEFAULT '0', "collections" numeric(12,2) NOT NULL DEFAULT '0', "outstanding" numeric(12,2) NOT NULL DEFAULT '0', "createdAt" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "UQ_a58a7202bf3d9d03c3293e6b8a1" UNIQUE ("period"), CONSTRAINT "PK_a2e6e7599c908f7c6b8563905a8" PRIMARY KEY ("id"))`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP TABLE "revenue_history"`);
    }

}
