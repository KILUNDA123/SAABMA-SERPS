import { MigrationInterface, QueryRunner } from "typeorm";

export class AddSessionId1784202461203 implements MigrationInterface {
    name = 'AddSessionId1784202461203'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "users" ADD "currentSessionId" character varying`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "currentSessionId"`);
    }

}
