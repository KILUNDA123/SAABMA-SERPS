import { MigrationInterface, QueryRunner } from "typeorm";

export class EnterpriseAuthSecurity1784180478600 implements MigrationInterface {
    name = 'EnterpriseAuthSecurity1784180478600'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "users" ADD "employeeId" character varying`);
        // Backfill any existing rows with a placeholder unique ID before
        // enforcing NOT NULL - real accounts get their real employeeId from
        // the seed data (or from HR/CEO assigning one going forward); this
        // only protects rows that predate this migration.
        await queryRunner.query(`UPDATE "users" SET "employeeId" = 'SERP/LEGACY/' || substring("id"::text, 1, 8) WHERE "employeeId" IS NULL`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "employeeId" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "users" ADD CONSTRAINT "UQ_a7191f881489123fab6c8e52738" UNIQUE ("employeeId")`);
        await queryRunner.query(`CREATE TYPE "public"."users_accountstatus_enum" AS ENUM('active', 'suspended', 'inactive', 'locked', 'pending_first_login')`);
        await queryRunner.query(`ALTER TABLE "users" ADD "accountStatus" "public"."users_accountstatus_enum" NOT NULL DEFAULT 'active'`);
        await queryRunner.query(`ALTER TABLE "users" ADD "mustChangePassword" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "users" ADD "failedLoginAttempts" integer NOT NULL DEFAULT '0'`);
        await queryRunner.query(`ALTER TABLE "users" ADD "lockedUntil" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "users" ADD "passwordChangedAt" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "email" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "email" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "passwordChangedAt"`);
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "lockedUntil"`);
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "failedLoginAttempts"`);
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "mustChangePassword"`);
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "accountStatus"`);
        await queryRunner.query(`DROP TYPE "public"."users_accountstatus_enum"`);
        await queryRunner.query(`ALTER TABLE "users" DROP CONSTRAINT "UQ_a7191f881489123fab6c8e52738"`);
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "employeeId"`);
    }

}
