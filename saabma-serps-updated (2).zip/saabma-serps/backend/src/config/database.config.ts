import { TypeOrmModuleOptions } from '@nestjs/typeorm';

import { User } from '../modules/users/entities/user.entity';
import { LoginEvent } from '../modules/login-events/entities/login-event.entity';
import { Role, Permission } from '../modules/roles/entities/role.entity';
import { Department } from '../modules/departments/entities/department.entity';
import { Shift } from '../modules/shifts/entities/shift.entity';
import { Employee } from '../modules/employees/entities/employee.entity';
import { AttendanceRecord } from '../modules/attendance/entities/attendance.entity';

import { Batch } from '../modules/batches/entities/batch.entity';
import { SoakingRecord } from '../modules/soaking/entities/soaking-record.entity';
import { WashingRecord } from '../modules/washing/entities/washing-record.entity';
import { DryingRecord } from '../modules/drying/entities/drying-record.entity';
import { ProductionRecord } from '../modules/production/entities/production-record.entity';
import { BrushingRecord } from '../modules/brushing/entities/brushing-record.entity';
import { BalingRecord } from '../modules/baling/entities/baling-record.entity';

import { InventoryItem } from '../modules/inventory/entities/inventory-item.entity';
import { Warehouse, StockMovement } from '../modules/warehouse/entities/warehouse.entity';
import { Supplier } from '../modules/suppliers/entities/supplier.entity';
import { Purchase, PurchaseItem } from '../modules/purchases/entities/purchase.entity';

import { Customer } from '../modules/customers/entities/customer.entity';
import { Invoice, InvoiceItem } from '../modules/invoices/entities/invoice.entity';
import { Payment } from '../modules/payments/entities/payment.entity';
import { Order, OrderItem } from '../modules/orders/entities/order.entity';

import { Vehicle, Driver } from '../modules/vehicles/entities/vehicle.entity';
import { Container, Shipment } from '../modules/shipments/entities/shipment.entity';
import { ExportDocument } from '../modules/documents/entities/document.entity';
import { RevenueHistory } from '../modules/reports/entities/revenue-history.entity';

import { Notification } from '../modules/notifications/entities/notification.entity';
import { Approval } from '../modules/approvals/entities/approval.entity';
import { AuditLog } from '../modules/audit/entities/audit-log.entity';

export const allEntities = [
  // Auth / people
  User,
  LoginEvent,
  Role,
  Permission,
  Department,
  Shift,
  Employee,
  AttendanceRecord,

  // Production flow (batch traceability)
  Batch,
  SoakingRecord,
  WashingRecord,
  DryingRecord,
  ProductionRecord,
  BrushingRecord,
  BalingRecord,

  // Warehouse / stock / procurement
  InventoryItem,
  Warehouse,
  StockMovement,
  Supplier,
  Purchase,
  PurchaseItem,

  // Sales / finance
  Customer,
  Invoice,
  InvoiceItem,
  Payment,
  Order,
  OrderItem,

  // Export / logistics
  Vehicle,
  Driver,
  Container,
  Shipment,
  ExportDocument,

  // System
  Notification,
  Approval,
  AuditLog,
  RevenueHistory,
];

export const getDatabaseConfig = (): TypeOrmModuleOptions => ({
  type: 'postgres',
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432', 10),
  username: process.env.DB_USER || 'saabma',
  password: process.env.DB_PASSWORD || 'changeme',
  database: process.env.DB_NAME || 'saabma_serps',
  entities: allEntities,
  migrations: [__dirname + '/../migrations/*{.js,.ts}'],
  // Versioned migrations are now the source of truth for schema changes -
  // synchronize is OFF by default. Set DB_SYNCHRONIZE=true in .env only for
  // fast local prototyping when you don't care about migration history yet
  // (e.g. iterating on a brand new entity before its first migration exists).
  synchronize: process.env.DB_SYNCHRONIZE === 'true',
  migrationsRun: process.env.DB_AUTO_MIGRATE !== 'false', // run pending migrations automatically on boot by default
});
