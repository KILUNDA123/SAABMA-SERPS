import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD } from '@nestjs/core';
import { getDatabaseConfig } from './config/database.config';
import { UsersModule } from './modules/users/users.module';
import { AuthModule } from './modules/auth/auth.module';
import { LoginEventsModule } from './modules/login-events/login-events.module';
import { EmployeesModule } from './modules/employees/employees.module';
import { BatchesModule } from './modules/batches/batches.module';
import { ProductionModule } from './modules/production/production.module';
import { WashingModule } from './modules/washing/washing.module';
import { BrushingModule } from './modules/brushing/brushing.module';
import { SoakingModule } from './modules/soaking/soaking.module';
import { DryingModule } from './modules/drying/drying.module';
import { BalingModule } from './modules/baling/baling.module';
import { InventoryModule } from './modules/inventory/inventory.module';
import { WarehouseModule } from './modules/warehouse/warehouse.module';
import { AttendanceModule } from './modules/attendance/attendance.module';
import { VehiclesModule } from './modules/vehicles/vehicles.module';
import { BiometricsModule } from './modules/biometrics/biometrics.module';
import { CustomersModule } from './modules/customers/customers.module';
import { InvoicesModule } from './modules/invoices/invoices.module';
import { AuditModule } from './modules/audit/audit.module';
import { OrdersModule } from './modules/orders/orders.module';
import { ShipmentsModule } from './modules/shipments/shipments.module';
import { ReportsModule } from './modules/reports/reports.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { PermissionsModule } from './modules/permissions/permissions.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { DocumentsModule } from './modules/documents/documents.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRoot(getDatabaseConfig()),
    // Global default: 100 requests/min per IP. Auth endpoints override this
    // with a much stricter limit via @Throttle() - see auth.controller.ts
    // and users.controller.ts - since brute-forcing a password is the
    // actual threat model, not general API usage.
    ThrottlerModule.forRoot([{ ttl: 60_000, limit: 100 }]),
    UsersModule,
    AuthModule,
    LoginEventsModule,
    EmployeesModule,
    BatchesModule,
    ProductionModule,
    WashingModule,
    BrushingModule,
    SoakingModule,
    DryingModule,
    BalingModule,
    InventoryModule,
    WarehouseModule,
    AttendanceModule,
    VehiclesModule,
    BiometricsModule,
    CustomersModule,
    InvoicesModule,
    AuditModule,
    OrdersModule,
    ShipmentsModule,
    ReportsModule,
    DashboardModule,
    PermissionsModule,
    NotificationsModule,
    DocumentsModule,
  ],
  providers: [
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
  ],
})
export class AppModule {}
