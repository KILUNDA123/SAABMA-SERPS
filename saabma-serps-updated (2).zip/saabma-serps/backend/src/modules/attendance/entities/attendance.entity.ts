import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, CreateDateColumn } from 'typeorm';
import { Employee } from '../../employees/entities/employee.entity';
import { Shift } from '../../shifts/entities/shift.entity';

// Populated by the fingerprint scanner integration (door controller pushes
// a scan event -> this record is created/updated). Payroll reads from here.

@Entity('attendance_records')
export class AttendanceRecord {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Employee)
  @JoinColumn()
  employee: Employee;

  @ManyToOne(() => Shift, { nullable: true })
  @JoinColumn()
  shift: Shift;

  @Column({ type: 'date' })
  date: string;

  @Column({ type: 'timestamp', nullable: true })
  timeIn: Date;

  @Column({ type: 'timestamp', nullable: true })
  timeOut: Date;

  @Column('decimal', { precision: 5, scale: 2, default: 0 })
  hoursWorked: number;

  @Column({ default: false })
  isLate: boolean;

  @Column('decimal', { precision: 5, scale: 2, default: 0 })
  overtimeHours: number;

  @Column({ nullable: true })
  biometricScanRef: string; // raw event id from the fingerprint device, for traceability

  @CreateDateColumn()
  createdAt: Date;
}
