import { Controller, Get, Post, Param, UseGuards } from '@nestjs/common';
import { AttendanceService } from './attendance.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../permissions/permissions.guard';
import { RequirePermission } from '../permissions/require-permission.decorator';
import { PERMISSIONS } from '../permissions/permissions.constants';

@Controller('attendance')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class AttendanceController {
  constructor(private readonly attendanceService: AttendanceService) {}

  // Company-wide roster - attendance:view is granted broadly (down to
  // casual workers) so they can check their own status, but that must NOT
  // imply visibility into everyone else's attendance. attendance:manage is
  // the HR/CEO/Ops-tier permission for the full company list.
  @Get()
  @RequirePermission(PERMISSIONS.ATTENDANCE_MANAGE)
  findAll() {
    return this.attendanceService.findAll();
  }

  @Get('missing-today')
  @RequirePermission(PERMISSIONS.ATTENDANCE_MANAGE)
  findMissingToday() {
    return this.attendanceService.findMissingToday();
  }

  @Post('notify-missing-today')
  @RequirePermission(PERMISSIONS.ATTENDANCE_MANAGE)
  notifyMissingToday() {
    return this.attendanceService.notifyMissingToday();
  }

  // Single-employee lookup - covered by the broadly-granted attendance:view.
  // NOTE: this does not yet verify the caller IS that employee (there's no
  // User<->Employee link in the schema to check against) - see the
  // explanation at the end of this response for that gap.
  @Get('employee/:employeeId')
  @RequirePermission(PERMISSIONS.ATTENDANCE_VIEW)
  findByEmployee(@Param('employeeId') employeeId: string) {
    return this.attendanceService.findByEmployee(employeeId);
  }
}
