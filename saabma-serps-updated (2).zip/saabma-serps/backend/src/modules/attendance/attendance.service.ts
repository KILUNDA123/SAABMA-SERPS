import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AttendanceRecord } from './entities/attendance.entity';
import { Employee } from '../employees/entities/employee.entity';
import { EmployeesService } from '../employees/employees.service';
import { NotificationsService } from '../notifications/notifications.service';
import { NotificationType } from '../notifications/entities/notification.entity';
import { UserRole } from '../users/entities/user.entity';

export interface ScanResult {
  action: 'clock_in' | 'clock_out';
  record: AttendanceRecord;
  employee: Employee;
}

@Injectable()
export class AttendanceService {
  constructor(
    @InjectRepository(AttendanceRecord)
    private readonly attendanceRepository: Repository<AttendanceRecord>,
    private readonly employeesService: EmployeesService,
    private readonly notificationsService: NotificationsService,
  ) {}

  // The single entry point for the door's fingerprint scanner. It doesn't
  // need to know whether this is a clock-in or clock-out - it just reports
  // "this fingerprint was scanned right now" and the system figures out
  // which one it must be: no open (timeOut-less) record for today -> clock
  // in; an open record exists -> clock out, and hours/overtime are computed
  // automatically. This matches "Fingerprint Scanner -> Identity Verified ->
  // Door Unlocks -> Attendance Saved" from the original plan.
  async recordScan(fingerprintTemplateId: string, scanRef?: string): Promise<ScanResult> {
    const employee = await this.employeesService.findByFingerprintTemplateId(fingerprintTemplateId);
    const today = new Date().toISOString().slice(0, 10);

    const openRecord = await this.attendanceRepository.findOne({
      where: { employee: { id: employee.id }, date: today },
      relations: ['employee', 'shift'],
    });

    if (!openRecord) {
      const record = this.attendanceRepository.create({
        employee,
        shift: employee.defaultShift,
        date: today,
        timeIn: new Date(),
        biometricScanRef: scanRef,
        isLate: this.calculateIsLate(employee, new Date()),
      });
      const saved = await this.attendanceRepository.save(record);
      return { action: 'clock_in', record: saved, employee };
    }

    if (!openRecord.timeOut) {
      openRecord.timeOut = new Date();
      const { hoursWorked, overtimeHours } = this.calculateHours(openRecord.timeIn, openRecord.timeOut);
      openRecord.hoursWorked = hoursWorked;
      openRecord.overtimeHours = overtimeHours;
      const saved = await this.attendanceRepository.save(openRecord);
      return { action: 'clock_out', record: saved, employee };
    }

    // Already clocked in AND out today - a second scan starts a fresh
    // record (e.g. a worker leaving and returning for an evening shift).
    const record = this.attendanceRepository.create({
      employee,
      shift: employee.defaultShift,
      date: today,
      timeIn: new Date(),
      biometricScanRef: scanRef,
      isLate: this.calculateIsLate(employee, new Date()),
    });
    const saved = await this.attendanceRepository.save(record);
    return { action: 'clock_in', record: saved, employee };
  }

  private calculateIsLate(employee: Employee, scanTime: Date): boolean {
    if (!employee.defaultShift) return false;
    const [shiftHour, shiftMinute] = employee.defaultShift.startTime.split(':').map(Number);
    const shiftStart = new Date(scanTime);
    shiftStart.setHours(shiftHour, shiftMinute, 0, 0);
    return scanTime.getTime() > shiftStart.getTime();
  }

  private calculateHours(timeIn: Date, timeOut: Date): { hoursWorked: number; overtimeHours: number } {
    const ms = timeOut.getTime() - new Date(timeIn).getTime();
    const hoursWorked = Math.max(0, Math.round((ms / (1000 * 60 * 60)) * 100) / 100);
    const overtimeHours = hoursWorked > 8 ? Math.round((hoursWorked - 8) * 100) / 100 : 0;
    return { hoursWorked, overtimeHours };
  }

  async findAll(): Promise<AttendanceRecord[]> {
    return this.attendanceRepository.find({
      relations: ['employee', 'shift'],
      order: { date: 'DESC', timeIn: 'DESC' },
    });
  }

  async findByEmployee(employeeCode: string): Promise<AttendanceRecord[]> {
    return this.attendanceRepository.find({
      where: { employee: { employeeCode } },
      relations: ['employee', 'shift'],
      order: { date: 'DESC' },
    });
  }

  async findMissingToday(): Promise<Employee[]> {
    // Employees who are active but have no attendance record for today -
    // feeds the "Attendance Missing -> HR notified" flow from the plan.
    const today = new Date().toISOString().slice(0, 10);
    const allEmployees = await this.employeesService.findAll();
    const todayRecords = await this.attendanceRepository.find({
      where: { date: today },
      relations: ['employee'],
    });
    const presentIds = new Set(todayRecords.map((r) => r.employee.id));
    return allEmployees.filter((e) => e.isActive && !presentIds.has(e.id));
  }

  // Manually triggered (e.g. by an HR user clicking a button, or an external
  // scheduler calling this endpoint once a day) rather than an automatic
  // cron job - this sandbox has no reliable way to verify a scheduled task
  // actually fires on time, so a callable, testable endpoint is the honest
  // choice here. Wiring @nestjs/schedule for a daily cron is a small,
  // separate addition once this is running somewhere persistent.
  async notifyMissingToday(): Promise<{ notifiedCount: number; missingEmployees: Employee[] }> {
    const missing = await this.findMissingToday();

    if (missing.length > 0) {
      const names = missing.map((e) => e.fullName).join(', ');
      const notified = await this.notificationsService.notifyRole(
        UserRole.HR,
        NotificationType.ATTENDANCE_MISSING,
        `${missing.length} employee(s) have no attendance record today: ${names}.`,
        '/attendance/missing-today',
      );
      return { notifiedCount: notified.length, missingEmployees: missing };
    }

    return { notifiedCount: 0, missingEmployees: [] };
  }
}
