import { IsString } from 'class-validator';

// This is what the physical door controller pushes to the backend on every
// successful fingerprint scan - it doesn't know or care whether it's a
// time-in or time-out, the backend figures that out.
export class ScanEventDto {
  @IsString()
  fingerprintTemplateId: string;
}
