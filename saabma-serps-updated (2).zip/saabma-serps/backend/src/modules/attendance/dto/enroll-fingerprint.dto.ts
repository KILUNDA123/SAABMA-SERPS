import { IsString } from 'class-validator';

export class EnrollFingerprintDto {
  @IsString()
  fingerprintTemplateId: string; // opaque ID from the physical scanner/door controller
}
