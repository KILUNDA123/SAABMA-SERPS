import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Shipment, Container, ShipmentStatus } from './entities/shipment.entity';
import { Batch } from '../batches/entities/batch.entity';
import { Vehicle, Driver } from '../vehicles/entities/vehicle.entity';
import { CustomersService } from '../customers/customers.service';
import { NotificationsService } from '../notifications/notifications.service';
import { NotificationType } from '../notifications/entities/notification.entity';
import { UserRole } from '../users/entities/user.entity';

@Injectable()
export class ShipmentsService {
  constructor(
    @InjectRepository(Shipment)
    private readonly shipmentsRepository: Repository<Shipment>,
    @InjectRepository(Container)
    private readonly containersRepository: Repository<Container>,
    @InjectRepository(Batch)
    private readonly batchesRepository: Repository<Batch>,
    @InjectRepository(Vehicle)
    private readonly vehiclesRepository: Repository<Vehicle>,
    @InjectRepository(Driver)
    private readonly driversRepository: Repository<Driver>,
    private readonly customersService: CustomersService,
    private readonly notificationsService: NotificationsService,
  ) {}

  async createContainer(data: { containerNumber: string; sealNumber?: string; totalWeightKg?: number }): Promise<Container> {
    const container = this.containersRepository.create(data);
    return this.containersRepository.save(container);
  }

  async findAllContainers(): Promise<Container[]> {
    return this.containersRepository.find({ order: { containerNumber: 'ASC' } });
  }

  private async generateShipmentNumber(): Promise<string> {
    const now = new Date();
    const datePart = `${String(now.getFullYear()).slice(2)}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
    const prefix = `SHP${datePart}`;
    const countToday = await this.shipmentsRepository
      .createQueryBuilder('s')
      .where('s.shipmentNumber LIKE :prefix', { prefix: `${prefix}%` })
      .getCount();
    return `${prefix}${String(countToday + 1).padStart(4, '0')}`;
  }

  async create(data: {
    customerId: string;
    batchIds: string[];
    containerId?: string;
    vehicleId?: string;
    driverId?: string;
    port?: string;
    eta?: string;
  }): Promise<Shipment> {
    const customer = await this.customersService.findOne(data.customerId);

    const batches = await this.batchesRepository.find({ where: { id: In(data.batchIds) } });
    if (batches.length !== data.batchIds.length) {
      throw new NotFoundException('One or more batch IDs were not found');
    }

    let container: Container | undefined;
    if (data.containerId) {
      const found = await this.containersRepository.findOne({ where: { id: data.containerId } });
      if (!found) throw new NotFoundException('Container not found');
      container = found;
    }

    let vehicle: Vehicle | undefined;
    if (data.vehicleId) {
      const found = await this.vehiclesRepository.findOne({ where: { id: data.vehicleId } });
      if (!found) throw new NotFoundException('Vehicle not found');
      vehicle = found;
    }

    let driver: Driver | undefined;
    if (data.driverId) {
      const found = await this.driversRepository.findOne({ where: { id: data.driverId } });
      if (!found) throw new NotFoundException('Driver not found');
      driver = found;
    }

    const shipmentNumber = await this.generateShipmentNumber();

    const shipment = this.shipmentsRepository.create({
      shipmentNumber,
      customer,
      batches,
      container,
      vehicle,
      driver,
      port: data.port,
      eta: data.eta,
      status: ShipmentStatus.PREPARING,
    });

    return this.shipmentsRepository.save(shipment);
  }

  async findAll(): Promise<Shipment[]> {
    return this.shipmentsRepository.find({
      relations: ['customer', 'batches', 'container', 'vehicle', 'driver'],
      order: { createdAt: 'DESC' },
    });
  }

  async findOne(id: string): Promise<Shipment> {
    const shipment = await this.shipmentsRepository.findOne({
      where: { id },
      relations: ['customer', 'batches', 'container', 'vehicle', 'driver'],
    });
    if (!shipment) {
      throw new NotFoundException('Shipment not found');
    }
    return shipment;
  }

  // Simple forward-only status update - matches the "Shipment Loaded ->
  // Operations notified" style flow from the plan. Notification wiring
  // itself happens once the Notifications module has a way to emit events;
  // this is the point in the code that event would fire from.
  async updateStatus(id: string, status: ShipmentStatus): Promise<Shipment> {
    const shipment = await this.findOne(id);
    shipment.status = status;
    const saved = await this.shipmentsRepository.save(shipment);

    // "Shipment Loaded -> Operations notified" from the plan.
    if (status === ShipmentStatus.LOADED) {
      await this.notificationsService.notifyRole(
        UserRole.OPERATIONS_MANAGER,
        NotificationType.SHIPMENT_LOADED,
        `Shipment ${shipment.shipmentNumber} for ${shipment.customer.name} has been loaded.`,
        `/shipments/${shipment.id}`,
      );
    }

    return saved;
  }
}
