import { Controller, Post, Get, Patch, Param, Body, UseGuards } from '@nestjs/common';
import { ShipmentsService } from './shipments.service';
import { CreateShipmentDto } from './dto/create-shipment.dto';
import { UpdateShipmentStatusDto } from './dto/update-shipment-status.dto';
import { CreateContainerDto } from './dto/create-container.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../permissions/permissions.guard';
import { RequirePermission } from '../permissions/require-permission.decorator';
import { PERMISSIONS } from '../permissions/permissions.constants';

@Controller('shipments')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class ShipmentsController {
  constructor(private readonly shipmentsService: ShipmentsService) {}

  @Post('containers')
  @RequirePermission(PERMISSIONS.SHIPMENTS_MANAGE)
  createContainer(@Body() dto: CreateContainerDto) {
    return this.shipmentsService.createContainer(dto);
  }

  @Get('containers')
  @RequirePermission(PERMISSIONS.SHIPMENTS_VIEW)
  findAllContainers() {
    return this.shipmentsService.findAllContainers();
  }

  @Post()
  @RequirePermission(PERMISSIONS.SHIPMENTS_MANAGE)
  create(@Body() dto: CreateShipmentDto) {
    return this.shipmentsService.create(dto);
  }

  @Get()
  @RequirePermission(PERMISSIONS.SHIPMENTS_VIEW)
  findAll() {
    return this.shipmentsService.findAll();
  }

  @Get(':id')
  @RequirePermission(PERMISSIONS.SHIPMENTS_VIEW)
  findOne(@Param('id') id: string) {
    return this.shipmentsService.findOne(id);
  }

  @Patch(':id/status')
  @RequirePermission(PERMISSIONS.SHIPMENTS_MANAGE)
  updateStatus(@Param('id') id: string, @Body() dto: UpdateShipmentStatusDto) {
    return this.shipmentsService.updateStatus(id, dto.status);
  }
}
