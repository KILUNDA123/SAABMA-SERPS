import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, ManyToMany, JoinTable, CreateDateColumn } from 'typeorm';
import { Customer } from '../../customers/entities/customer.entity';
import { Batch } from '../../batches/entities/batch.entity';
import { Vehicle, Driver } from '../../vehicles/entities/vehicle.entity';

export enum ShipmentStatus {
  PREPARING = 'preparing',
  LOADED = 'loaded',
  IN_TRANSIT = 'in_transit',
  AT_PORT = 'at_port',
  SHIPPED = 'shipped',
  DELIVERED = 'delivered',
}

@Entity('containers')
export class Container {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  containerNumber: string;

  @Column({ nullable: true })
  sealNumber: string;

  @Column('decimal', { precision: 12, scale: 2, default: 0 })
  totalWeightKg: number;
}

@Entity('shipments')
export class Shipment {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  shipmentNumber: string;

  @ManyToOne(() => Customer)
  @JoinColumn()
  customer: Customer;

  @ManyToOne(() => Container, { nullable: true })
  @JoinColumn()
  container: Container;

  @ManyToOne(() => Vehicle, { nullable: true })
  @JoinColumn()
  vehicle: Vehicle;

  @ManyToOne(() => Driver, { nullable: true })
  @JoinColumn()
  driver: Driver;

  @ManyToMany(() => Batch)
  @JoinTable()
  batches: Batch[]; // full traceability: shipment -> batches -> every processing stage

  @Column({ nullable: true })
  port: string;

  @Column({ type: 'enum', enum: ShipmentStatus, default: ShipmentStatus.PREPARING })
  status: ShipmentStatus;

  @Column({ type: 'date', nullable: true })
  eta: string;

  @CreateDateColumn()
  createdAt: Date;
}
