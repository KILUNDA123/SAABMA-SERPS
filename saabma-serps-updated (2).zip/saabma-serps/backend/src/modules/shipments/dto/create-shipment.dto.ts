import { IsUUID, IsArray, IsOptional, IsString } from 'class-validator';

export class CreateShipmentDto {
  @IsUUID()
  customerId: string;

  @IsArray()
  @IsUUID('4', { each: true })
  batchIds: string[];

  @IsOptional()
  @IsUUID()
  containerId?: string;

  @IsOptional()
  @IsUUID()
  vehicleId?: string;

  @IsOptional()
  @IsUUID()
  driverId?: string;

  @IsOptional()
  @IsString()
  port?: string;

  @IsOptional()
  @IsString()
  eta?: string;
}
