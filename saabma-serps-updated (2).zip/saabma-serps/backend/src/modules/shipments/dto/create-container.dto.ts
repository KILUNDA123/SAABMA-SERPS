import { IsString, IsOptional, IsNumber, Min } from 'class-validator';

export class CreateContainerDto {
  @IsString()
  containerNumber: string;

  @IsOptional()
  @IsString()
  sealNumber?: string;

  @IsOptional()
  @IsNumber()
  @Min(0)
  totalWeightKg?: number;
}
