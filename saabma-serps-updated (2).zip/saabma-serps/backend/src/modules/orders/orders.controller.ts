import { Controller, Post, Get, Patch, Param, Body, UseGuards } from '@nestjs/common';
import { OrdersService } from './orders.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../permissions/permissions.guard';
import { RequirePermission } from '../permissions/require-permission.decorator';
import { PERMISSIONS } from '../permissions/permissions.constants';

@Controller('orders')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class OrdersController {
  constructor(private readonly ordersService: OrdersService) {}

  @Post()
  @RequirePermission(PERMISSIONS.SALES_CREATE)
  create(@Body() dto: CreateOrderDto) {
    return this.ordersService.create(dto);
  }

  @Get()
  @RequirePermission(PERMISSIONS.SALES_VIEW)
  findAll() {
    return this.ordersService.findAll();
  }

  @Get(':id')
  @RequirePermission(PERMISSIONS.SALES_VIEW)
  findOne(@Param('id') id: string) {
    return this.ordersService.findOne(id);
  }

  @Patch(':id/confirm')
  @RequirePermission(PERMISSIONS.SALES_CREATE)
  confirm(@Param('id') id: string) {
    return this.ordersService.confirm(id);
  }

  @Patch(':id/invoice')
  @RequirePermission(PERMISSIONS.SALES_CREATE)
  convertToInvoice(@Param('id') id: string) {
    return this.ordersService.convertToInvoice(id);
  }

  @Patch(':id/cancel')
  @RequirePermission(PERMISSIONS.SALES_CREATE)
  cancel(@Param('id') id: string) {
    return this.ordersService.cancel(id);
  }
}
