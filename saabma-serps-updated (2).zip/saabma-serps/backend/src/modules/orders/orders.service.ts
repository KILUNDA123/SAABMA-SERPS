import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Order, OrderItem, OrderStatus } from './entities/order.entity';
import { CustomersService } from '../customers/customers.service';
import { InventoryService } from '../inventory/inventory.service';
import { InvoicesService } from '../invoices/invoices.service';
import { Invoice } from '../invoices/entities/invoice.entity';

@Injectable()
export class OrdersService {
  constructor(
    @InjectRepository(Order)
    private readonly ordersRepository: Repository<Order>,
    @InjectRepository(OrderItem)
    private readonly orderItemsRepository: Repository<OrderItem>,
    private readonly customersService: CustomersService,
    private readonly inventoryService: InventoryService,
    private readonly invoicesService: InvoicesService,
  ) {}

  private async generateOrderNumber(): Promise<string> {
    const now = new Date();
    const datePart = `${String(now.getFullYear()).slice(2)}${String(now.getMonth() + 1).padStart(2, '0')}`;
    const prefix = `ORD${datePart}`;
    const countThisMonth = await this.ordersRepository
      .createQueryBuilder('order')
      .where('order.orderNumber LIKE :prefix', { prefix: `${prefix}%` })
      .getCount();
    const sequence = String(countThisMonth + 1).padStart(4, '0');
    return `${prefix}${sequence}`;
  }

  async create(data: {
    customerId: string;
    items: { inventoryItemId: string; description: string; quantity: number; unitPrice: number }[];
  }): Promise<Order> {
    if (!data.items?.length) {
      throw new BadRequestException('An order must have at least one item');
    }

    const customer = await this.customersService.findOne(data.customerId);
    // Verify the inventory items exist (but do NOT deduct stock yet - an
    // order is a commitment to sell, not a completed sale).
    await Promise.all(data.items.map((line) => this.inventoryService.findOne(line.inventoryItemId)));

    const total = data.items.reduce((sum, line) => sum + line.quantity * line.unitPrice, 0);
    const orderNumber = await this.generateOrderNumber();

    const order = this.ordersRepository.create({
      orderNumber,
      customer,
      status: OrderStatus.DRAFT,
      total,
    });
    const savedOrder = await this.ordersRepository.save(order);

    for (const line of data.items) {
      const inventoryItem = await this.inventoryService.findOne(line.inventoryItemId);
      const item = this.orderItemsRepository.create({
        order: savedOrder,
        inventoryItem,
        description: line.description,
        quantity: line.quantity,
        unitPrice: line.unitPrice,
        lineTotal: line.quantity * line.unitPrice,
      });
      await this.orderItemsRepository.save(item);
    }

    return this.findOne(savedOrder.id);
  }

  async findAll(): Promise<Order[]> {
    return this.ordersRepository.find({
      relations: ['customer', 'items', 'items.inventoryItem'],
      order: { createdAt: 'DESC' },
    });
  }

  async findOne(id: string): Promise<Order> {
    const order = await this.ordersRepository.findOne({
      where: { id },
      relations: ['customer', 'items', 'items.inventoryItem'],
    });
    if (!order) {
      throw new NotFoundException('Order not found');
    }
    return order;
  }

  async confirm(id: string): Promise<Order> {
    const order = await this.findOne(id);
    if (order.status !== OrderStatus.DRAFT) {
      throw new BadRequestException(`Order is already ${order.status}`);
    }
    order.status = OrderStatus.CONFIRMED;
    return this.ordersRepository.save(order);
  }

  // The moment stock actually gets deducted and the customer actually owes
  // money - reuses InvoicesService.create so the exact same stock-check /
  // stock-deduction / outstanding-balance logic runs, rather than duplicating
  // it here. An order can only be invoiced once (invoiceId guards this).
  async convertToInvoice(id: string): Promise<{ order: Order; invoice: Invoice }> {
    const order = await this.findOne(id);

    if (order.invoiceId) {
      throw new BadRequestException('This order has already been invoiced');
    }
    if (order.status === OrderStatus.CANCELLED) {
      throw new BadRequestException('Cannot invoice a cancelled order');
    }

    const invoice = await this.invoicesService.create({
      customerId: order.customer.id,
      invoiceDate: new Date().toISOString().slice(0, 10),
      items: order.items.map((line) => ({
        inventoryItemId: line.inventoryItem.id,
        description: line.description,
        quantity: Number(line.quantity),
        unitPrice: Number(line.unitPrice),
      })),
    });

    order.status = OrderStatus.INVOICED;
    order.invoiceId = invoice.id;
    await this.ordersRepository.save(order);

    return { order: await this.findOne(id), invoice };
  }

  async cancel(id: string): Promise<Order> {
    const order = await this.findOne(id);
    if (order.status === OrderStatus.INVOICED) {
      throw new BadRequestException('Cannot cancel an order that has already been invoiced');
    }
    order.status = OrderStatus.CANCELLED;
    return this.ordersRepository.save(order);
  }
}
