import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, OneToMany, CreateDateColumn } from 'typeorm';
import { Supplier } from '../../suppliers/entities/supplier.entity';
import { InventoryItem } from '../../inventory/entities/inventory-item.entity';

export enum PurchaseStatus {
  REQUESTED = 'requested', // auto-created when stock hits reorder level
  ORDERED = 'ordered',
  RECEIVED = 'received',
  CANCELLED = 'cancelled',
}

@Entity('purchases')
export class Purchase {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  purchaseNumber: string;

  @ManyToOne(() => Supplier)
  @JoinColumn()
  supplier: Supplier;

  @Column({ type: 'enum', enum: PurchaseStatus, default: PurchaseStatus.REQUESTED })
  status: PurchaseStatus;

  @OneToMany(() => PurchaseItem, (item) => item.purchase, { cascade: true })
  items: PurchaseItem[];

  @Column('decimal', { precision: 12, scale: 2, default: 0 })
  totalCost: number;

  @CreateDateColumn()
  createdAt: Date;
}

@Entity('purchase_items')
export class PurchaseItem {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Purchase, (purchase) => purchase.items)
  @JoinColumn()
  purchase: Purchase;

  @ManyToOne(() => InventoryItem)
  @JoinColumn()
  item: InventoryItem;

  @Column('decimal', { precision: 12, scale: 2 })
  quantity: number;

  @Column('decimal', { precision: 12, scale: 2 })
  unitCost: number;
}
