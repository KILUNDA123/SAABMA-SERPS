import { Injectable, UnauthorizedException, ForbiddenException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import * as crypto from 'crypto';
import { UsersService } from '../users/users.service';
import { User, AccountStatus, UserRole } from '../users/entities/user.entity';
import { LoginEvent } from '../login-events/entities/login-event.entity';
import { AuditLog } from '../audit/entities/audit-log.entity';
import { GeoService } from '../geo/geo.service';
import { NotificationsService } from '../notifications/notifications.service';
import { NotificationType } from '../notifications/entities/notification.entity';

export interface JwtPayload {
  sub: string;
  employeeId: string;
  role: string;
  sessionId: string;
}

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;

@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly jwtService: JwtService,
    private readonly geoService: GeoService,
    private readonly notificationsService: NotificationsService,
    @InjectRepository(LoginEvent)
    private readonly loginEventsRepository: Repository<LoginEvent>,
    @InjectRepository(AuditLog)
    private readonly auditLogRepository: Repository<AuditLog>,
  ) {}

  private async recordAudit(action: string, user: User | null, details: Record<string, any>, ipAddress?: string, userAgent?: string) {
    // Fire-and-forget, same philosophy as the global AuditInterceptor:
    // auditing must never block or fail a login/security action.
    try {
      const log = this.auditLogRepository.create({
        user: user ? ({ id: user.id } as User) : undefined,
        action,
        entityType: 'User',
        entityId: user?.id ?? undefined,
        newValue: details,
        ipAddress,
        userAgent,
      });
      await this.auditLogRepository.save(log);
    } catch {
      /* deliberately swallowed */
    }
  }

  async validateUser(
    employeeId: string,
    password: string,
    ipAddress?: string,
    userAgent?: string,
  ): Promise<User> {
    const user = await this.usersService.findByEmployeeId(employeeId);

    // Same generic message for "no such account" and "wrong password" -
    // never reveal which one it was.
    const genericFailure = async (reason: string, foundUser: User | null) => {
      if (foundUser) {
        const attempts = foundUser.failedLoginAttempts + 1;
        const patch: Partial<User> = { failedLoginAttempts: attempts };
        if (attempts >= MAX_FAILED_ATTEMPTS) {
          patch.accountStatus = AccountStatus.LOCKED;
          patch.lockedUntil = new Date(Date.now() + LOCKOUT_MINUTES * 60 * 1000);
          await this.recordAudit('ACCOUNT_LOCKED', foundUser, { reason: 'too many failed attempts', attempts }, ipAddress, userAgent);
        }
        await this.usersService.updateFields(foundUser.id, patch);
      }
      await this.recordAudit('LOGIN_FAILED', foundUser, { employeeId, reason }, ipAddress, userAgent);
      throw new UnauthorizedException('Invalid credentials');
    };

    if (!user) {
      await genericFailure('no account with this employee ID', null);
      throw new UnauthorizedException('Invalid credentials');
    }

    if (user.accountStatus === AccountStatus.SUSPENDED) {
      await this.recordAudit('LOGIN_BLOCKED', user, { reason: 'account suspended' }, ipAddress, userAgent);
      throw new ForbiddenException('This account is suspended. Contact HR or your administrator.');
    }
    if (user.accountStatus === AccountStatus.INACTIVE) {
      await this.recordAudit('LOGIN_BLOCKED', user, { reason: 'account inactive' }, ipAddress, userAgent);
      throw new ForbiddenException('This account is inactive. Contact HR or your administrator.');
    }
    if (user.accountStatus === AccountStatus.LOCKED) {
      if (user.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
        const minutesLeft = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000);
        await this.recordAudit('LOGIN_BLOCKED', user, { reason: 'account locked', minutesLeft }, ipAddress, userAgent);
        throw new ForbiddenException(`This account is locked. Try again in ${minutesLeft} minute(s), or contact your administrator.`);
      }
      // Lockout window has passed - clear it and let the password check proceed.
      await this.usersService.updateFields(user.id, { accountStatus: AccountStatus.ACTIVE, failedLoginAttempts: 0, lockedUntil: null });
      user.accountStatus = AccountStatus.ACTIVE;
    }
    if (!user.isActive) {
      await genericFailure('account deactivated', user);
      throw new UnauthorizedException('Invalid credentials');
    }

    const passwordMatches = await bcrypt.compare(password, user.passwordHash);
    if (!passwordMatches) {
      await genericFailure('wrong password', user);
      throw new UnauthorizedException('Invalid credentials');
    }

    // Success - reset the failure counter.
    if (user.failedLoginAttempts > 0) {
      await this.usersService.updateFields(user.id, { failedLoginAttempts: 0 });
    }

    return user;
  }

  async login(data: {
    employeeId: string;
    password: string;
    latitude: number;
    longitude: number;
    accuracyMeters?: number;
    ipAddress?: string;
    userAgent?: string;
  }) {
    const user = await this.validateUser(data.employeeId, data.password, data.ipAddress, data.userAgent);
    await this.usersService.updateLastLogin(user.id);

    // New-device / new-location alert: based on real history, not a guess.
    // Only fires once the user has at least one prior login on record, so
    // the very first login of a new account is never flagged as "unusual".
    const priorLogins = await this.loginEventsRepository.find({ where: { user: { id: user.id } } });
    if (priorLogins.length > 0 && data.ipAddress) {
      const seenBefore = priorLogins.some((e) => e.ipAddress === data.ipAddress);
      if (!seenBefore) {
        const message = `${user.fullName} (${user.employeeId}) just signed in from a new IP address (${data.ipAddress}) not seen on this account before.`;
        await this.notificationsService.notifyUser(user, NotificationType.SECURITY_ALERT, message);
        await this.notificationsService.notifyRole(UserRole.CEO, NotificationType.SECURITY_ALERT, message);
        await this.recordAudit('NEW_DEVICE_LOGIN', user, { ipAddress: data.ipAddress }, data.ipAddress, data.userAgent);
      }
    }

    // Single-active-session enforcement: a fresh session ID is generated
    // and persisted on every login. JwtStrategy checks each request's
    // token against this exact value, so logging in anywhere else
    // silently invalidates every previously issued token for this user.
    const sessionId = crypto.randomUUID();
    await this.usersService.updateFields(user.id, { currentSessionId: sessionId });

    // Reverse geocode best-effort - never blocks or fails the login itself.
    const geo = await this.geoService.reverseGeocode(data.latitude, data.longitude);

    const loginEvent = this.loginEventsRepository.create({
      user,
      latitude: data.latitude,
      longitude: data.longitude,
      accuracyMeters: data.accuracyMeters,
      resolvedAddress: geo.resolvedAddress ?? undefined,
      ipAddress: data.ipAddress,
      userAgent: data.userAgent,
    });
    await this.loginEventsRepository.save(loginEvent);

    const payload: JwtPayload = {
      sub: user.id,
      employeeId: user.employeeId,
      role: user.role,
      sessionId,
    };

    return {
      accessToken: this.jwtService.sign(payload),
      mustChangePassword: user.mustChangePassword,
      user: {
        id: user.id,
        employeeId: user.employeeId,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
      },
      loginLocation: {
        latitude: data.latitude,
        longitude: data.longitude,
        resolvedAddress: geo.resolvedAddress,
        resolvedVia: geo.resolvedVia,
      },
    };
  }

  async changePassword(userId: string, currentPassword: string, newPassword: string, ipAddress?: string, userAgent?: string) {
    const user = await this.usersService.findById(userId);
    const matches = await bcrypt.compare(currentPassword, user.passwordHash);
    if (!matches) {
      await this.recordAudit('PASSWORD_CHANGE_FAILED', user, { reason: 'current password incorrect' }, ipAddress, userAgent);
      throw new BadRequestException('Current password is incorrect');
    }
    if (currentPassword === newPassword) {
      throw new BadRequestException('New password must be different from your current password');
    }
    const passwordHash = await bcrypt.hash(newPassword, 10);
    await this.usersService.updateFields(user.id, {
      passwordHash,
      mustChangePassword: false,
      passwordChangedAt: new Date(),
    });
    await this.recordAudit('PASSWORD_CHANGED', user, {}, ipAddress, userAgent);
    return { success: true };
  }
}
