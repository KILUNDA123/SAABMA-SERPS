import { SetMetadata } from '@nestjs/common';
import { UserRole } from '../../users/entities/user.entity';

export const ROLES_KEY = 'roles';

// Usage: @Roles(UserRole.SUPERVISOR, UserRole.CEO) above a controller method
export const Roles = (...roles: UserRole[]) => SetMetadata(ROLES_KEY, roles);
