import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { JwtStrategy } from './strategies/jwt.strategy';
import { UsersModule } from '../users/users.module';
import { LoginEvent } from '../login-events/entities/login-event.entity';
import { AuditLog } from '../audit/entities/audit-log.entity';
import { GeoModule } from '../geo/geo.module';
import { NotificationsModule } from '../notifications/notifications.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([LoginEvent, AuditLog]),
    UsersModule,
    PassportModule,
    GeoModule,
    NotificationsModule,
    JwtModule.register({
      secret: process.env.JWT_SECRET || 'change_this_to_a_long_random_string',
      signOptions: { expiresIn: '12h' },
    }),
  ],
  providers: [AuthService, JwtStrategy],
  controllers: [AuthController],
  exports: [AuthService],
})
export class AuthModule {}
