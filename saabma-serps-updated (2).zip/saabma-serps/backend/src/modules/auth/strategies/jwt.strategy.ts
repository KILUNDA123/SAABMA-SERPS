import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { JwtPayload } from '../auth.service';
import { UsersService } from '../../users/users.service';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private readonly usersService: UsersService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_SECRET || 'change_this_to_a_long_random_string',
    });
  }

  // Whatever is returned here becomes `request.user` in controllers.
  // Single-active-session enforcement lives here: a token is only valid
  // if its sessionId still matches the user's currentSessionId - logging
  // in again anywhere overwrites that value, so the old token starts
  // failing here on its very next request.
  async validate(payload: JwtPayload) {
    const user = await this.usersService.findById(payload.sub);
    if (!user || user.currentSessionId !== payload.sessionId) {
      throw new UnauthorizedException('This session is no longer valid - you signed in elsewhere.');
    }
    return { userId: payload.sub, employeeId: payload.employeeId, role: payload.role };
  }
}
