import { IsString, IsNumber, IsOptional, Min, Max } from 'class-validator';

export class LoginDto {
  // Company-issued identifier (e.g. SERP/EXE/001) - email is no longer
  // accepted as a login credential per policy.
  @IsString()
  employeeId: string;

  @IsString()
  password: string;

  // Mandatory - not optional. A login request with no coordinates is
  // rejected by validation before it ever reaches AuthService. The client
  // (web/mobile) must request the browser/device geolocation permission
  // and only submit the login form once coordinates are obtained - this is
  // what "forces" location at sign-in.
  @IsNumber()
  @Min(-90)
  @Max(90)
  latitude: number;

  @IsNumber()
  @Min(-180)
  @Max(180)
  longitude: number;

  @IsOptional()
  @IsNumber()
  accuracyMeters?: number;
}
