import { Entity, PrimaryGeneratedColumn, Column, ManyToMany, JoinTable } from 'typeorm';

// Fine-grained RBAC layer. User.role (enum) is used for fast/simple checks;
// Role + Permission give per-feature control (e.g. "can_approve_production",
// "can_view_finance") for cases where the 11 broad roles aren't granular enough.

@Entity('permissions')
export class Permission {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  code: string; // e.g. 'production.approve', 'finance.view'

  @Column({ nullable: true })
  description: string;
}

@Entity('roles')
export class Role {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  name: string;

  @ManyToMany(() => Permission)
  @JoinTable()
  permissions: Permission[];
}
