import { Controller, Post, Get, Param, Body, UseGuards, Res, NotFoundException } from '@nestjs/common';
import { Response } from 'express';
import * as fs from 'fs';
import { DocumentsService } from './documents.service';
import { GenerateDocumentDto } from './dto/generate-document.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../permissions/permissions.guard';
import { RequirePermission } from '../permissions/require-permission.decorator';
import { PERMISSIONS } from '../permissions/permissions.constants';

@Controller('documents')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class DocumentsController {
  constructor(private readonly documentsService: DocumentsService) {}

  @Post('generate')
  @RequirePermission(PERMISSIONS.DOCUMENTS_VIEW)
  generate(@Body() dto: GenerateDocumentDto) {
    return this.documentsService.generate(dto);
  }

  @Get()
  @RequirePermission(PERMISSIONS.DOCUMENTS_VIEW)
  findAll() {
    return this.documentsService.findAll();
  }

  @Get(':id')
  @RequirePermission(PERMISSIONS.DOCUMENTS_VIEW)
  findOne(@Param('id') id: string) {
    return this.documentsService.findOne(id);
  }

  @Get(':id/download')
  @RequirePermission(PERMISSIONS.DOCUMENTS_DOWNLOAD)
  async download(@Param('id') id: string, @Res() res: Response) {
    const document = await this.documentsService.findOne(id);
    const filePath = this.documentsService.getFilePath(id);

    if (!fs.existsSync(filePath)) {
      throw new NotFoundException('Generated file is missing from storage');
    }

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${document.documentNumber}.pdf"`);
    fs.createReadStream(filePath).pipe(res);
  }
}
