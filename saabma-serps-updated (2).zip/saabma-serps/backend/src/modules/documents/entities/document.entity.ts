import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, CreateDateColumn } from 'typeorm';
import { Shipment } from '../../shipments/entities/shipment.entity';
import { Invoice } from '../../invoices/entities/invoice.entity';

export enum DocumentType {
  INVOICE = 'invoice',
  PACKING_LIST = 'packing_list',
  DELIVERY_NOTE = 'delivery_note',
  CARGO_MANIFEST = 'cargo_manifest',
  CERTIFICATE_OF_ORIGIN = 'certificate_of_origin',
  EXPORT_DECLARATION = 'export_declaration',
}

// Every export document is generated FROM existing data (shipment + batches +
// invoice) rather than typed manually - this row just tracks the generated
// file + which shipment/invoice it belongs to, so nothing is typed twice.
@Entity('documents')
export class ExportDocument {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'enum', enum: DocumentType })
  type: DocumentType;

  @ManyToOne(() => Shipment, { nullable: true })
  @JoinColumn()
  shipment: Shipment;

  @ManyToOne(() => Invoice, { nullable: true })
  @JoinColumn()
  invoice: Invoice;

  @Column()
  fileUrl: string; // path/URL in MinIO or S3

  @Column({ nullable: true })
  documentNumber: string;

  @CreateDateColumn()
  generatedAt: Date;
}
