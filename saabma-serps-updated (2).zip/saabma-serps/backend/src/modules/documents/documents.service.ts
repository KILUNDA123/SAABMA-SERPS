import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as fs from 'fs';
import * as path from 'path';
import { randomUUID } from 'crypto';
import { ExportDocument, DocumentType } from './entities/document.entity';
import { Shipment } from '../shipments/entities/shipment.entity';
import { Invoice } from '../invoices/entities/invoice.entity';
import {
  newPdf,
  addCompanyHeader,
  addSectionTitle,
  addKeyValueRow,
  addTable,
  addFooter,
} from './pdf-builder.util';

// Where generated PDFs actually live on disk. In production this should be
// MinIO/S3 (same note as the original plan's "Storage" section) - local
// disk is fine for development and for this sandbox, where we don't have
// network access to set up real object storage anyway.
const STORAGE_DIR = path.join(__dirname, '..', '..', '..', 'storage', 'documents');

@Injectable()
export class DocumentsService {
  constructor(
    @InjectRepository(ExportDocument)
    private readonly documentsRepository: Repository<ExportDocument>,
    @InjectRepository(Shipment)
    private readonly shipmentsRepository: Repository<Shipment>,
    @InjectRepository(Invoice)
    private readonly invoicesRepository: Repository<Invoice>,
  ) {
    if (!fs.existsSync(STORAGE_DIR)) {
      fs.mkdirSync(STORAGE_DIR, { recursive: true });
    }
  }

  private async generateDocumentNumber(type: DocumentType): Promise<string> {
    const prefixes: Record<DocumentType, string> = {
      [DocumentType.INVOICE]: 'INV',
      [DocumentType.PACKING_LIST]: 'PKL',
      [DocumentType.DELIVERY_NOTE]: 'DLN',
      [DocumentType.CARGO_MANIFEST]: 'CGM',
      [DocumentType.CERTIFICATE_OF_ORIGIN]: 'COO',
      [DocumentType.EXPORT_DECLARATION]: 'EXD',
    };
    const now = new Date();
    const datePart = `${String(now.getFullYear()).slice(2)}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
    const prefix = `${prefixes[type]}${datePart}`;

    const countToday = await this.documentsRepository
      .createQueryBuilder('d')
      .where('d.documentNumber LIKE :prefix', { prefix: `${prefix}%` })
      .getCount();

    return `${prefix}${String(countToday + 1).padStart(4, '0')}`;
  }

  private async loadShipment(shipmentId: string): Promise<Shipment> {
    const shipment = await this.shipmentsRepository.findOne({
      where: { id: shipmentId },
      relations: ['customer', 'batches', 'container', 'vehicle', 'driver'],
    });
    if (!shipment) {
      throw new NotFoundException('Shipment not found');
    }
    return shipment;
  }

  private async loadInvoice(invoiceId: string): Promise<Invoice> {
    const invoice = await this.invoicesRepository.findOne({
      where: { id: invoiceId },
      relations: ['customer', 'items'],
    });
    if (!invoice) {
      throw new NotFoundException('Invoice not found');
    }
    return invoice;
  }

  private async saveAndRecord(
    type: DocumentType,
    doc: PDFKit.PDFDocument,
    documentNumber: string,
    shipment?: Shipment,
    invoice?: Invoice,
  ): Promise<ExportDocument> {
    const id = randomUUID();
    const filePath = path.join(STORAGE_DIR, `${id}.pdf`);

    await new Promise<void>((resolve, reject) => {
      const stream = fs.createWriteStream(filePath);
      doc.pipe(stream);
      doc.end();
      stream.on('finish', resolve);
      stream.on('error', reject);
    });

    const record = this.documentsRepository.create({
      id,
      type,
      shipment,
      invoice,
      documentNumber,
      fileUrl: `/documents/${id}/download`,
    });

    return this.documentsRepository.save(record);
  }

  async generatePackingList(shipmentId: string): Promise<ExportDocument> {
    const shipment = await this.loadShipment(shipmentId);
    const documentNumber = await this.generateDocumentNumber(DocumentType.PACKING_LIST);

    const doc = newPdf();
    addCompanyHeader(doc, 'PACKING LIST', documentNumber);

    addSectionTitle(doc, 'Shipment Details');
    addKeyValueRow(doc, 'Shipment Number', shipment.shipmentNumber);
    addKeyValueRow(doc, 'Customer', shipment.customer.name);
    addKeyValueRow(doc, 'Destination Country', shipment.customer.country || 'N/A');
    addKeyValueRow(doc, 'Port', shipment.port || 'N/A');
    if (shipment.container) addKeyValueRow(doc, 'Container No.', shipment.container.containerNumber);

    addSectionTitle(doc, 'Batches in this Shipment');
    const totalWeight = shipment.batches.reduce((sum, b) => sum + Number(b.rawWeightKg), 0);
    addTable(
      doc,
      ['Batch Number', 'Stage', 'Weight (kg)'],
      shipment.batches.map((b) => [b.batchNumber, b.currentStage, Number(b.rawWeightKg).toFixed(2)]),
      [220, 150, 120],
    );
    addKeyValueRow(doc, 'Total Weight', `${totalWeight.toFixed(2)} kg`);

    addFooter(doc);
    return this.saveAndRecord(DocumentType.PACKING_LIST, doc, documentNumber, shipment);
  }

  async generateCertificateOfOrigin(shipmentId: string): Promise<ExportDocument> {
    const shipment = await this.loadShipment(shipmentId);
    const documentNumber = await this.generateDocumentNumber(DocumentType.CERTIFICATE_OF_ORIGIN);

    const doc = newPdf();
    addCompanyHeader(doc, 'CERTIFICATE OF ORIGIN', documentNumber);

    addSectionTitle(doc, 'Declaration');
    doc
      .fontSize(10)
      .text(
        `We, Saabma Limited, hereby certify that the goods described below, being ${shipment.batches.length} batch(es) of processed sisal fibre, are of Kenyan origin and were manufactured and processed at our facility in Meru, Kenya.`,
        { align: 'justify' },
      )
      .moveDown(1);

    addSectionTitle(doc, 'Consignment Details');
    addKeyValueRow(doc, 'Shipment Number', shipment.shipmentNumber);
    addKeyValueRow(doc, 'Consignee', shipment.customer.name);
    addKeyValueRow(doc, 'Destination', shipment.customer.country || 'N/A');
    addKeyValueRow(doc, 'Country of Origin', 'Kenya');
    const totalWeight = shipment.batches.reduce((sum, b) => sum + Number(b.rawWeightKg), 0);
    addKeyValueRow(doc, 'Total Net Weight', `${totalWeight.toFixed(2)} kg`);
    addKeyValueRow(doc, 'Batch Numbers', shipment.batches.map((b) => b.batchNumber).join(', '));

    addFooter(doc);
    return this.saveAndRecord(DocumentType.CERTIFICATE_OF_ORIGIN, doc, documentNumber, shipment);
  }

  async generateCargoManifest(shipmentId: string): Promise<ExportDocument> {
    const shipment = await this.loadShipment(shipmentId);
    const documentNumber = await this.generateDocumentNumber(DocumentType.CARGO_MANIFEST);

    const doc = newPdf();
    addCompanyHeader(doc, 'CARGO MANIFEST', documentNumber);

    addSectionTitle(doc, 'Transport Details');
    addKeyValueRow(doc, 'Shipment Number', shipment.shipmentNumber);
    addKeyValueRow(doc, 'Status', shipment.status);
    addKeyValueRow(doc, 'Port', shipment.port || 'N/A');
    addKeyValueRow(doc, 'ETA', shipment.eta || 'N/A');
    if (shipment.container) {
      addKeyValueRow(doc, 'Container No.', shipment.container.containerNumber);
      addKeyValueRow(doc, 'Seal No.', shipment.container.sealNumber || 'N/A');
    }
    if (shipment.vehicle) addKeyValueRow(doc, 'Vehicle', shipment.vehicle.plateNumber);
    if (shipment.driver) addKeyValueRow(doc, 'Driver', shipment.driver.fullName);

    addSectionTitle(doc, 'Cargo');
    addTable(
      doc,
      ['Batch Number', 'Weight (kg)'],
      shipment.batches.map((b) => [b.batchNumber, Number(b.rawWeightKg).toFixed(2)]),
      [250, 150],
    );

    addFooter(doc);
    return this.saveAndRecord(DocumentType.CARGO_MANIFEST, doc, documentNumber, shipment);
  }

  async generateDeliveryNote(invoiceId: string): Promise<ExportDocument> {
    const invoice = await this.loadInvoice(invoiceId);
    const documentNumber = await this.generateDocumentNumber(DocumentType.DELIVERY_NOTE);

    const doc = newPdf();
    addCompanyHeader(doc, 'DELIVERY NOTE', documentNumber);

    addSectionTitle(doc, 'Customer');
    addKeyValueRow(doc, 'Name', invoice.customer.name);
    addKeyValueRow(doc, 'Country', invoice.customer.country || 'N/A');
    addKeyValueRow(doc, 'Related Invoice', invoice.invoiceNumber);

    addSectionTitle(doc, 'Items Delivered');
    addTable(
      doc,
      ['Description', 'Quantity', 'Unit Price'],
      invoice.items.map((i) => [i.description, Number(i.quantity).toFixed(2), Number(i.unitPrice).toFixed(2)]),
      [250, 100, 100],
    );

    addFooter(doc);
    return this.saveAndRecord(DocumentType.DELIVERY_NOTE, doc, documentNumber, undefined, invoice);
  }

  async generateExportDeclaration(shipmentId: string, invoiceId?: string): Promise<ExportDocument> {
    const shipment = await this.loadShipment(shipmentId);
    const invoice = invoiceId ? await this.loadInvoice(invoiceId) : undefined;
    const documentNumber = await this.generateDocumentNumber(DocumentType.EXPORT_DECLARATION);

    const doc = newPdf();
    addCompanyHeader(doc, 'EXPORT DECLARATION', documentNumber);

    addSectionTitle(doc, 'Exporter');
    addKeyValueRow(doc, 'Company', 'Saabma Limited');
    addKeyValueRow(doc, 'Country', 'Kenya');

    addSectionTitle(doc, 'Consignment');
    addKeyValueRow(doc, 'Shipment Number', shipment.shipmentNumber);
    addKeyValueRow(doc, 'Consignee', shipment.customer.name);
    addKeyValueRow(doc, 'Destination', shipment.customer.country || 'N/A');
    const totalWeight = shipment.batches.reduce((sum, b) => sum + Number(b.rawWeightKg), 0);
    addKeyValueRow(doc, 'Total Weight', `${totalWeight.toFixed(2)} kg`);
    if (invoice) {
      addKeyValueRow(doc, 'Declared Value', `${invoice.total} (Invoice ${invoice.invoiceNumber})`);
    } else {
      addKeyValueRow(doc, 'Declared Value', 'Not linked to an invoice');
    }

    addFooter(doc);
    return this.saveAndRecord(DocumentType.EXPORT_DECLARATION, doc, documentNumber, shipment, invoice);
  }

  async generate(dto: { type: DocumentType; shipmentId?: string; invoiceId?: string }): Promise<ExportDocument> {
    switch (dto.type) {
      case DocumentType.PACKING_LIST:
        if (!dto.shipmentId) throw new BadRequestException('shipmentId is required for a packing list');
        return this.generatePackingList(dto.shipmentId);
      case DocumentType.CERTIFICATE_OF_ORIGIN:
        if (!dto.shipmentId) throw new BadRequestException('shipmentId is required for a certificate of origin');
        return this.generateCertificateOfOrigin(dto.shipmentId);
      case DocumentType.CARGO_MANIFEST:
        if (!dto.shipmentId) throw new BadRequestException('shipmentId is required for a cargo manifest');
        return this.generateCargoManifest(dto.shipmentId);
      case DocumentType.DELIVERY_NOTE:
        if (!dto.invoiceId) throw new BadRequestException('invoiceId is required for a delivery note');
        return this.generateDeliveryNote(dto.invoiceId);
      case DocumentType.EXPORT_DECLARATION:
        if (!dto.shipmentId) throw new BadRequestException('shipmentId is required for an export declaration');
        return this.generateExportDeclaration(dto.shipmentId, dto.invoiceId);
      default:
        throw new BadRequestException(`Document type "${dto.type}" is not generatable via this endpoint`);
    }
  }

  async findOne(id: string): Promise<ExportDocument> {
    const document = await this.documentsRepository.findOne({ where: { id } });
    if (!document) {
      throw new NotFoundException('Document not found');
    }
    return document;
  }

  getFilePath(id: string): string {
    return path.join(STORAGE_DIR, `${id}.pdf`);
  }

  async findAll(): Promise<ExportDocument[]> {
    return this.documentsRepository.find({ order: { generatedAt: 'DESC' } });
  }
}
