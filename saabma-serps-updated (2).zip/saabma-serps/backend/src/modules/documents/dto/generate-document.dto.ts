import { IsEnum, IsOptional, IsUUID } from 'class-validator';
import { DocumentType } from '../entities/document.entity';

export class GenerateDocumentDto {
  @IsEnum(DocumentType)
  type: DocumentType;

  @IsOptional()
  @IsUUID()
  shipmentId?: string;

  @IsOptional()
  @IsUUID()
  invoiceId?: string;
}
