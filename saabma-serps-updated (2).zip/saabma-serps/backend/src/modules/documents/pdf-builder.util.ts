import PDFDocument = require('pdfkit');

// Shared visual building blocks so every generated document looks like it
// came from the same company, rather than each generator reinventing layout.
export function newPdf(): PDFKit.PDFDocument {
  return new PDFDocument({ size: 'A4', margin: 50 });
}

export function addCompanyHeader(doc: PDFKit.PDFDocument, title: string, documentNumber: string) {
  doc
    .fontSize(18)
    .text('SAABMA LIMITED', { align: 'left' })
    .fontSize(9)
    .text('Sisal Fibre Processing & Export', { align: 'left' })
    .text('Meru, Kenya', { align: 'left' })
    .moveDown(1);

  doc
    .fontSize(14)
    .text(title, { align: 'center' })
    .fontSize(10)
    .text(`Document No: ${documentNumber}`, { align: 'center' })
    .text(`Date: ${new Date().toISOString().slice(0, 10)}`, { align: 'center' })
    .moveDown(1.5);
}

export function addSectionTitle(doc: PDFKit.PDFDocument, title: string) {
  doc.moveDown(0.5).fontSize(12).text(title, { underline: true }).moveDown(0.3).fontSize(10);
}

export function addKeyValueRow(doc: PDFKit.PDFDocument, key: string, value: string) {
  doc.fontSize(10).text(`${key}: `, { continued: true }).font('Helvetica-Bold').text(value).font('Helvetica');
}

export function addTable(doc: PDFKit.PDFDocument, headers: string[], rows: string[][], colWidths: number[]) {
  const startX = doc.x;
  let y = doc.y;

  doc.font('Helvetica-Bold').fontSize(9);
  let x = startX;
  headers.forEach((h, i) => {
    doc.text(h, x, y, { width: colWidths[i] });
    x += colWidths[i];
  });
  y += 18;
  doc.font('Helvetica').fontSize(9);

  rows.forEach((row) => {
    x = startX;
    row.forEach((cell, i) => {
      doc.text(cell, x, y, { width: colWidths[i] });
      x += colWidths[i];
    });
    y += 16;
  });

  doc.y = y + 10;
}

export function addFooter(doc: PDFKit.PDFDocument) {
  doc
    .moveDown(2)
    .fontSize(9)
    .text('_____________________________', { align: 'left' })
    .text('Authorized Signatory', { align: 'left' })
    .moveDown(1)
    .fontSize(8)
    .fillColor('gray')
    .text('This document was generated automatically by Saabma SERPS from live production and shipment records.', {
      align: 'center',
    })
    .fillColor('black');
}
