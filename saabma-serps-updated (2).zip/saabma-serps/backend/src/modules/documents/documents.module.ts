import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExportDocument } from './entities/document.entity';
import { Shipment } from '../shipments/entities/shipment.entity';
import { Invoice } from '../invoices/entities/invoice.entity';
import { DocumentsService } from './documents.service';
import { DocumentsController } from './documents.controller';

@Module({
  imports: [TypeOrmModule.forFeature([ExportDocument, Shipment, Invoice])],
  controllers: [DocumentsController],
  providers: [DocumentsService],
  exports: [DocumentsService],
})
export class DocumentsModule {}
