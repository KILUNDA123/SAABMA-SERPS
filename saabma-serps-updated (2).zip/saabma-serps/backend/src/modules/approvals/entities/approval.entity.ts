import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, CreateDateColumn } from 'typeorm';
import { Employee } from '../../employees/entities/employee.entity';
import { ApprovalStatus } from '../../production/entities/production-record.entity';

export enum ApprovableEntityType {
  PRODUCTION = 'production_record',
  WASHING = 'washing_record',
  BRUSHING = 'brushing_record',
  SOAKING = 'soaking_record',
  DRYING = 'drying_record',
  BALING = 'baling_record',
}

// Generic approval log (who approved what, when, with what comment) sitting
// ALONGSIDE the status field on each record - the record's status column is
// for fast filtering/queries, this table is the traceable audit history,
// matching the "digital approval workflow" in the plan.
@Entity('approvals')
export class Approval {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'enum', enum: ApprovableEntityType })
  entityType: ApprovableEntityType;

  @Column()
  entityId: string;

  @ManyToOne(() => Employee)
  @JoinColumn()
  reviewedBy: Employee;

  @Column({ type: 'enum', enum: ApprovalStatus })
  decision: ApprovalStatus;

  @Column({ nullable: true })
  comment: string;

  @CreateDateColumn()
  createdAt: Date;
}
