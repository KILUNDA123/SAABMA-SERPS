import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductionRecord } from '../production/entities/production-record.entity';
import { Invoice } from '../invoices/entities/invoice.entity';
import { Payment } from '../payments/entities/payment.entity';
import { AttendanceRecord } from '../attendance/entities/attendance.entity';
import { WashingRecord } from '../washing/entities/washing-record.entity';
import { InventoryItem } from '../inventory/entities/inventory-item.entity';
import { ReportsService } from './reports.service';
import { ReportsController } from './reports.controller';

@Module({
  imports: [TypeOrmModule.forFeature([ProductionRecord, Invoice, Payment, AttendanceRecord, WashingRecord, InventoryItem])],
  controllers: [ReportsController],
  providers: [ReportsService],
})
export class ReportsModule {}
