import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity('revenue_history')
export class RevenueHistory {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'date', unique: true })
  period: string;

  @Column('decimal', { precision: 12, scale: 2, default: 0 })
  revenue: number;

  @Column('decimal', { precision: 12, scale: 2, default: 0 })
  collections: number;

  @Column('decimal', { precision: 12, scale: 2, default: 0 })
  outstanding: number;

  @CreateDateColumn()
  createdAt: Date;
}
