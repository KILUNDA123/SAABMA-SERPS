import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
const PDFDocument = require('pdfkit');
const xlsx = require('xlsx');
import { ProductionRecord, ApprovalStatus } from '../production/entities/production-record.entity';
import { Invoice } from '../invoices/entities/invoice.entity';
import { Payment } from '../payments/entities/payment.entity';
import { AttendanceRecord } from '../attendance/entities/attendance.entity';
import { WashingRecord } from '../washing/entities/washing-record.entity';
import { InventoryItem } from '../inventory/entities/inventory-item.entity';
import { ReportQueryDto } from './dto/report-query.dto';
import { ReportResponse } from './interfaces/report.interface';

@Injectable()
export class ReportsService {
  constructor(
    @InjectRepository(ProductionRecord)
    private readonly productionRepository: Repository<ProductionRecord>,
    @InjectRepository(Invoice)
    private readonly invoicesRepository: Repository<Invoice>,
    @InjectRepository(Payment)
    private readonly paymentsRepository: Repository<Payment>,
    @InjectRepository(AttendanceRecord)
    private readonly attendanceRepository: Repository<AttendanceRecord>,
    @InjectRepository(WashingRecord)
    private readonly washingRepository: Repository<WashingRecord>,
    @InjectRepository(InventoryItem)
    private readonly inventoryRepository: Repository<InventoryItem>,
  ) {}

  private slugify(value: string): string {
    return value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  }

  private escapeCsv(value: unknown): string {
    const text = value == null ? '' : String(value);
    if (/[",\n]/.test(text)) {
      return `"${text.replace(/"/g, '""')}"`;
    }
    return text;
  }

  private toCsv(report: ReportResponse): string {
    const headers = Object.keys(report.rows[0] || {});
    const lines = [headers.map((header) => this.escapeCsv(header)).join(',')];

    for (const row of report.rows) {
      lines.push(headers.map((header) => this.escapeCsv(row[header])).join(','));
    }

    return lines.join('\n');
  }

  private async toPdf(report: ReportResponse): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      const doc = new PDFDocument({ size: 'A4', margin: 36 });
      const chunks: Buffer[] = [];

      doc.on('data', (chunk: Buffer) => chunks.push(Buffer.from(chunk)));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);

      doc.fontSize(18).text(report.title, { align: 'center' });
      doc.moveDown();
      doc.fontSize(10).text(`Generated: ${report.generatedAt}`);
      doc.text(`Filters: ${JSON.stringify(report.filters)}`);
      doc.moveDown();
      doc.text('Summary');
      Object.entries(report.summary).forEach(([key, value]) => doc.text(`- ${key}: ${value}`));
      doc.moveDown();
      doc.text('Rows');
      report.rows.slice(0, 20).forEach((row, index) => {
        doc.text(`${index + 1}. ${JSON.stringify(row)}`);
      });
      doc.end();
    });
  }

  private async buildExport(report: ReportResponse): Promise<ReportResponse> {
    if (!report.exportFormat || report.exportFormat === 'json') {
      return report;
    }

    const filename = `${this.slugify(report.title)}.${report.exportFormat === 'xlsx' ? 'xlsx' : report.exportFormat === 'pdf' ? 'pdf' : 'csv'}`;

    if (report.exportFormat === 'csv') {
      return {
        ...report,
        export: {
          format: report.exportFormat,
          filename,
          mimeType: 'text/csv;charset=utf-8',
          content: this.toCsv(report),
        },
      };
    }

    if (report.exportFormat === 'xlsx') {
      const sheet = xlsx.utils.json_to_sheet(report.rows);
      const workbook = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(workbook, sheet, 'Report');
      const content = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' });
      return {
        ...report,
        export: {
          format: report.exportFormat,
          filename,
          mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          content,
        },
      };
    }

    const content = await this.toPdf(report);
    return {
      ...report,
      export: {
        format: report.exportFormat,
        filename,
        mimeType: 'application/pdf',
        content,
      },
    };
  }

  async dailyProduction(date: string) {
    const qb = this.productionRepository.createQueryBuilder('p');
    qb.select('COALESCE(SUM(p.boxes), 0)', 'boxes')
      .addSelect('COALESCE(SUM(p.weightKg), 0)', 'weightKg')
      .addSelect('COUNT(DISTINCT p."operatorId")', 'employees')
      .addSelect(`SUM(CASE WHEN p.status = '${ApprovalStatus.REJECTED}' THEN 1 ELSE 0 END)`, 'rejected')
      .where('p.date = :date', { date });

    const row = await qb.getRawOne();
    return {
      date,
      boxes: Number(row.boxes) || 0,
      weightKg: Number(row.weightKg) || 0,
      employees: Number(row.employees) || 0,
      rejected: Number(row.rejected) || 0,
    };
  }

  async monthlyFinance(year: number, month: number) {
    const from = new Date(year, month - 1, 1).toISOString().slice(0, 10);
    const to = new Date(year, month, 1).toISOString().slice(0, 10);

    const invoiceRow = await this.invoicesRepository
      .createQueryBuilder('i')
      .select('COALESCE(SUM(i.total), 0)', 'revenue')
      .addSelect('COUNT(i.id)', 'invoiceCount')
      .where('i.invoiceDate >= :from AND i.invoiceDate < :to', { from, to })
      .getRawOne();

    const paymentRow = await this.paymentsRepository
      .createQueryBuilder('p')
      .select('COALESCE(SUM(p.amount), 0)', 'collected')
      .where('p.paidOn >= :from AND p.paidOn < :to', { from, to })
      .getRawOne();

    const revenue = Number(invoiceRow.revenue) || 0;
    const collected = Number(paymentRow.collected) || 0;

    return {
      year,
      month,
      invoiceCount: Number(invoiceRow.invoiceCount) || 0,
      revenueBilled: revenue,
      collected,
      outstanding: Math.max(0, revenue - collected),
    };
  }

  async attendanceReport(query: ReportQueryDto): Promise<ReportResponse> {
    const qb = this.attendanceRepository
      .createQueryBuilder('attendance')
      .leftJoinAndSelect('attendance.employee', 'employee')
      .leftJoinAndSelect('attendance.shift', 'shift');

    if (query.fromDate) qb.andWhere('attendance.date >= :fromDate', { fromDate: query.fromDate });
    if (query.toDate) qb.andWhere('attendance.date <= :toDate', { toDate: query.toDate });
    if (query.employeeId) qb.andWhere('employee.id = :employeeId', { employeeId: query.employeeId });

    const rows = await qb.orderBy('attendance.date', 'DESC').getMany();
    const summary = {
      totalRecords: rows.length,
      present: rows.filter((row) => row.timeIn).length,
      late: rows.filter((row) => row.isLate).length,
      overtimeHours: rows.reduce((sum, row) => sum + Number(row.overtimeHours || 0), 0),
    };

    const report = {
      title: 'Attendance Report',
      generatedAt: new Date().toISOString(),
      filters: { fromDate: query.fromDate, toDate: query.toDate, employeeId: query.employeeId },
      summary,
      rows: rows.map((row) => ({
        date: row.date,
        employee: row.employee?.fullName,
        employeeCode: row.employee?.employeeCode,
        shift: row.shift?.name,
        isLate: row.isLate,
        hoursWorked: Number(row.hoursWorked || 0),
        overtimeHours: Number(row.overtimeHours || 0),
      })),
      exportFormat: query.format,
    };

    return this.buildExport(report);
  }

  async washingReport(query: ReportQueryDto): Promise<ReportResponse> {
    const qb = this.washingRepository
      .createQueryBuilder('washing')
      .leftJoinAndSelect('washing.operator', 'operator')
      .leftJoinAndSelect('washing.batch', 'batch');

    if (query.fromDate) qb.andWhere('washing.date >= :fromDate', { fromDate: query.fromDate });
    if (query.toDate) qb.andWhere('washing.date <= :toDate', { toDate: query.toDate });
    if (query.employeeId) qb.andWhere('operator.id = :employeeId', { employeeId: query.employeeId });

    const rows = await qb.orderBy('washing.date', 'DESC').getMany();
    const summary = {
      totalJobs: rows.length,
      totalKg: rows.reduce((sum, row) => sum + Number(row.kg || 0), 0),
      totalFee: rows.reduce((sum, row) => sum + Number(row.fee || 0), 0),
      approved: rows.filter((row) => row.status === ApprovalStatus.APPROVED).length,
    };

    const report = {
      title: 'Washing Report',
      generatedAt: new Date().toISOString(),
      filters: { fromDate: query.fromDate, toDate: query.toDate, employeeId: query.employeeId },
      summary,
      rows: rows.map((row) => ({
        date: row.date,
        operator: row.operator?.fullName,
        batch: row.batch?.batchNumber,
        kg: Number(row.kg || 0),
        hydrogenUsedKg: Number(row.hydrogenUsedKg || 0),
        fee: Number(row.fee || 0),
        status: row.status,
      })),
      exportFormat: query.format,
    };

    return this.buildExport(report);
  }

  async inventoryReport(query: ReportQueryDto): Promise<ReportResponse> {
    const qb = this.inventoryRepository.createQueryBuilder('item');
    if (query.status) qb.andWhere('item.category = :status', { status: query.status });

    const rows = await qb.orderBy('item.name', 'ASC').getMany();
    const summary = {
      totalItems: rows.length,
      totalStock: rows.reduce((sum, row) => sum + Number(row.currentStock || 0), 0),
      lowStockAlerts: rows.filter((row) => Number(row.currentStock || 0) <= Number(row.reorderLevel || 0)).length,
    };

    const report = {
      title: 'Inventory Report',
      generatedAt: new Date().toISOString(),
      filters: { status: query.status },
      summary,
      rows: rows.map((row) => ({
        name: row.name,
        category: row.category,
        unit: row.unit,
        currentStock: Number(row.currentStock || 0),
        reorderLevel: Number(row.reorderLevel || 0),
      })),
      exportFormat: query.format,
    };

    return this.buildExport(report);
  }

  async invoiceReport(query: ReportQueryDto): Promise<ReportResponse> {
    const qb = this.invoicesRepository.createQueryBuilder('invoice').leftJoinAndSelect('invoice.customer', 'customer');
    if (query.fromDate) qb.andWhere('invoice.invoiceDate >= :fromDate', { fromDate: query.fromDate });
    if (query.toDate) qb.andWhere('invoice.invoiceDate <= :toDate', { toDate: query.toDate });
    if (query.status) qb.andWhere('invoice.status = :status', { status: query.status });

    const rows = await qb.orderBy('invoice.invoiceDate', 'DESC').getMany();
    const summary = {
      totalInvoices: rows.length,
      totalValue: rows.reduce((sum, row) => sum + Number(row.total || 0), 0),
      paid: rows.filter((row) => row.status === 'paid').length,
      overdue: rows.filter((row) => row.status === 'overdue').length,
    };

    const report = {
      title: 'Invoice Report',
      generatedAt: new Date().toISOString(),
      filters: { fromDate: query.fromDate, toDate: query.toDate, status: query.status },
      summary,
      rows: rows.map((row) => ({
        invoiceNumber: row.invoiceNumber,
        customer: row.customer?.name,
        invoiceDate: row.invoiceDate,
        total: Number(row.total || 0),
        status: row.status,
      })),
      exportFormat: query.format,
    };

    return this.buildExport(report);
  }

  async revenueReport(query: ReportQueryDto): Promise<ReportResponse> {
    const qb = this.invoicesRepository.createQueryBuilder('invoice');
    if (query.fromDate) qb.andWhere('invoice.invoiceDate >= :fromDate', { fromDate: query.fromDate });
    if (query.toDate) qb.andWhere('invoice.invoiceDate <= :toDate', { toDate: query.toDate });

    const rows = await qb.orderBy('invoice.invoiceDate', 'ASC').getMany();
    const summary = {
      invoiceCount: rows.length,
      billedRevenue: rows.reduce((sum, row) => sum + Number(row.total || 0), 0),
      collectedRevenue: rows.filter((row) => row.status === 'paid').reduce((sum, row) => sum + Number(row.total || 0), 0),
      outstandingRevenue: rows.filter((row) => row.status !== 'paid').reduce((sum, row) => sum + Number(row.total || 0), 0),
    };

    const report = {
      title: 'Revenue Report',
      generatedAt: new Date().toISOString(),
      filters: { fromDate: query.fromDate, toDate: query.toDate },
      summary,
      rows: rows.map((row) => ({
        invoiceDate: row.invoiceDate,
        invoiceNumber: row.invoiceNumber,
        total: Number(row.total || 0),
        status: row.status,
      })),
      exportFormat: query.format,
    };

    return this.buildExport(report);
  }

  async employeePerformanceReport(query: ReportQueryDto): Promise<ReportResponse> {
    const qb = this.productionRepository
      .createQueryBuilder('production')
      .leftJoinAndSelect('production.operator', 'operator')
      .leftJoinAndSelect('production.batch', 'batch');

    if (query.fromDate) qb.andWhere('production.date >= :fromDate', { fromDate: query.fromDate });
    if (query.toDate) qb.andWhere('production.date <= :toDate', { toDate: query.toDate });
    if (query.employeeId) qb.andWhere('operator.id = :employeeId', { employeeId: query.employeeId });

    const rows = await qb.getMany();
    const summary = {
      totalRecords: rows.length,
      totalBoxes: rows.reduce((sum, row) => sum + Number(row.boxes || 0), 0),
      totalWeightKg: rows.reduce((sum, row) => sum + Number(row.weightKg || 0), 0),
    };

    const report = {
      title: 'Employee Performance Report',
      generatedAt: new Date().toISOString(),
      filters: { fromDate: query.fromDate, toDate: query.toDate, employeeId: query.employeeId },
      summary,
      rows: rows.map((row) => ({
        employee: row.operator?.fullName,
        employeeCode: row.operator?.employeeCode,
        date: row.date,
        boxes: Number(row.boxes || 0),
        weightKg: Number(row.weightKg || 0),
        batch: row.batch?.batchNumber,
      })),
      exportFormat: query.format,
    };

    return this.buildExport(report);
  }
}
