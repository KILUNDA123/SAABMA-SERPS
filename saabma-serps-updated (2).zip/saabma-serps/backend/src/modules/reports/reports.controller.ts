import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ReportsService } from './reports.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../permissions/permissions.guard';
import { RequirePermission } from '../permissions/require-permission.decorator';
import { PERMISSIONS } from '../permissions/permissions.constants';
import { ReportQueryDto } from './dto/report-query.dto';

@Controller('reports')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class ReportsController {
  constructor(private readonly reportsService: ReportsService) {}

  @Get('daily-production')
  @RequirePermission(PERMISSIONS.REPORTS_VIEW)
  dailyProduction(@Query('date') date: string) {
    return this.reportsService.dailyProduction(date);
  }

  @Get('monthly-finance')
  @RequirePermission(PERMISSIONS.REPORTS_VIEW)
  monthlyFinance(@Query('year') year: string, @Query('month') month: string) {
    return this.reportsService.monthlyFinance(parseInt(year, 10), parseInt(month, 10));
  }

  @Get('attendance')
  @RequirePermission(PERMISSIONS.REPORTS_VIEW)
  attendanceReport(@Query() query: ReportQueryDto) {
    return this.reportsService.attendanceReport(query);
  }

  @Get('washing')
  @RequirePermission(PERMISSIONS.REPORTS_VIEW)
  washingReport(@Query() query: ReportQueryDto) {
    return this.reportsService.washingReport(query);
  }

  @Get('inventory')
  @RequirePermission(PERMISSIONS.REPORTS_VIEW)
  inventoryReport(@Query() query: ReportQueryDto) {
    return this.reportsService.inventoryReport(query);
  }

  @Get('invoices')
  @RequirePermission(PERMISSIONS.REPORTS_VIEW)
  invoiceReport(@Query() query: ReportQueryDto) {
    return this.reportsService.invoiceReport(query);
  }

  @Get('revenue')
  @RequirePermission(PERMISSIONS.REPORTS_VIEW)
  revenueReport(@Query() query: ReportQueryDto) {
    return this.reportsService.revenueReport(query);
  }

  @Get('employee-performance')
  @RequirePermission(PERMISSIONS.REPORTS_VIEW)
  employeePerformanceReport(@Query() query: ReportQueryDto) {
    return this.reportsService.employeePerformanceReport(query);
  }
}
