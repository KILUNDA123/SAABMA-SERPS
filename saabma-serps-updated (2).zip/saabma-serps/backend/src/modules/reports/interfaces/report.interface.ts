export interface ReportRow {
  [key: string]: string | number | boolean | null | undefined;
}

export interface ReportExport {
  format: 'json' | 'csv' | 'pdf' | 'xlsx';
  filename: string;
  mimeType: string;
  content: string | Buffer;
}

export interface ReportResponse {
  title: string;
  generatedAt: string;
  filters: Record<string, string | undefined>;
  summary: Record<string, number | string>;
  rows: ReportRow[];
  exportFormat?: 'json' | 'csv' | 'pdf' | 'xlsx';
  export?: ReportExport;
}
