import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Employee } from './entities/employee.entity';

@Injectable()
export class EmployeesService {
  constructor(
    @InjectRepository(Employee)
    private readonly employeesRepository: Repository<Employee>,
  ) {}

  async create(data: { employeeCode: string; fullName: string; position?: string; dailyRate: number }): Promise<Employee> {
    const employee = this.employeesRepository.create(data);
    return this.employeesRepository.save(employee);
  }

  async findAll(): Promise<Employee[]> {
    return this.employeesRepository.find({ order: { createdAt: 'DESC' } });
  }

  async findOne(id: string): Promise<Employee> {
    const employee = await this.employeesRepository.findOne({ where: { id } });
    if (!employee) {
      throw new NotFoundException('Employee not found');
    }
    return employee;
  }

  async findByFingerprintTemplateId(fingerprintTemplateId: string): Promise<Employee> {
    const employee = await this.employeesRepository.findOne({
      where: { fingerprintTemplateId },
      relations: ['defaultShift'],
    });
    if (!employee) {
      throw new NotFoundException('No employee is enrolled with this fingerprint template');
    }
    return employee;
  }

  async enrollFingerprint(id: string, fingerprintTemplateId: string): Promise<Employee> {
    const existing = await this.employeesRepository.findOne({ where: { fingerprintTemplateId } });
    if (existing && existing.id !== id) {
      throw new ConflictException('This fingerprint template is already enrolled to another employee');
    }
    const employee = await this.findOne(id);
    employee.fingerprintTemplateId = fingerprintTemplateId;
    return this.employeesRepository.save(employee);
  }
}
