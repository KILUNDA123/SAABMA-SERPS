import { Controller, Post, Get, Patch, Param, Body, UseGuards } from '@nestjs/common';
import { EmployeesService } from './employees.service';
import { CreateEmployeeDto } from './dto/create-employee.dto';
import { EnrollFingerprintDto } from '../attendance/dto/enroll-fingerprint.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../permissions/permissions.guard';
import { RequirePermission } from '../permissions/require-permission.decorator';
import { PERMISSIONS } from '../permissions/permissions.constants';

@Controller('employees')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class EmployeesController {
  constructor(private readonly employeesService: EmployeesService) {}

  @Post()
  @RequirePermission(PERMISSIONS.EMPLOYEES_CREATE)
  create(@Body() dto: CreateEmployeeDto) {
    return this.employeesService.create(dto);
  }

  @Get()
  @RequirePermission(PERMISSIONS.EMPLOYEES_VIEW)
  findAll() {
    return this.employeesService.findAll();
  }

  @Get(':id')
  @RequirePermission(PERMISSIONS.EMPLOYEES_VIEW)
  findOne(@Param('id') id: string) {
    return this.employeesService.findOne(id);
  }

  // Called once, typically by HR/admin, after physically scanning the
  // employee's finger on the enrollment device to link its template ID.
  @Patch(':id/fingerprint')
  @RequirePermission(PERMISSIONS.EMPLOYEES_EDIT)
  enrollFingerprint(@Param('id') id: string, @Body() dto: EnrollFingerprintDto) {
    return this.employeesService.enrollFingerprint(id, dto.fingerprintTemplateId);
  }
}
