import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Department } from '../../departments/entities/department.entity';
import { Shift } from '../../shifts/entities/shift.entity';

@Entity('employees')
export class Employee {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @OneToOne(() => User, { nullable: true })
  @JoinColumn()
  user: User;

  @Column()
  employeeCode: string; // e.g. EMP-0001

  @Column()
  fullName: string;

  @ManyToOne(() => Department, { nullable: true })
  @JoinColumn()
  department: Department;

  @ManyToOne(() => Shift, { nullable: true })
  @JoinColumn()
  defaultShift: Shift;

  @Column({ nullable: true })
  position: string;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  dailyRate: number;

  @Column({ nullable: true })
  fingerprintTemplateId: string; // reference to biometric device record

  @Column({ default: true })
  isActive: boolean;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
