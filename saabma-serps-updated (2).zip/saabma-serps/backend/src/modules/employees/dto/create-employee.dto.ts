import { IsString, IsOptional, IsNumber, Min } from 'class-validator';

export class CreateEmployeeDto {
  @IsString()
  employeeCode: string;

  @IsString()
  fullName: string;

  @IsOptional()
  @IsString()
  position?: string;

  @IsNumber()
  @Min(0)
  dailyRate: number;
}
