import { Injectable, Logger } from '@nestjs/common';

export interface GeoResolution {
  resolvedAddress: string | null;
  resolvedVia: 'google_maps' | 'unavailable';
}

// Wraps Google Maps' Geocoding API to turn (lat, lng) into a human-readable
// address. Requires GOOGLE_MAPS_API_KEY to be set in .env - get one from
// https://console.cloud.google.com/google/maps-apis (enable "Geocoding API").
//
// Design choice: this NEVER throws and NEVER blocks a login. If the key is
// missing, the network call fails, or Google returns an error, we log it and
// return null - the raw coordinates are still saved on the LoginEvent either
// way. Location tracking should not be able to lock someone out of the
// system just because a third-party API had a bad moment.
@Injectable()
export class GeoService {
  private readonly logger = new Logger(GeoService.name);

  async reverseGeocode(latitude: number, longitude: number): Promise<GeoResolution> {
    const apiKey = process.env.GOOGLE_MAPS_API_KEY;

    if (!apiKey) {
      this.logger.warn(
        'GOOGLE_MAPS_API_KEY is not set - storing raw coordinates only, skipping reverse geocoding.',
      );
      return { resolvedAddress: null, resolvedVia: 'unavailable' };
    }

    try {
      const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${apiKey}`;

      // Uses global fetch (Node 18+, available in NestJS 10's runtime target).
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      const response = await fetch(url, { signal: controller.signal });
      clearTimeout(timeout);

      if (!response.ok) {
        this.logger.error(`Google Maps API returned HTTP ${response.status}`);
        return { resolvedAddress: null, resolvedVia: 'unavailable' };
      }

      const data: any = await response.json();

      if (data.status !== 'OK' || !data.results?.length) {
        this.logger.warn(`Google Maps API returned status: ${data.status}`);
        return { resolvedAddress: null, resolvedVia: 'unavailable' };
      }

      return {
        resolvedAddress: data.results[0].formatted_address,
        resolvedVia: 'google_maps',
      };
    } catch (err) {
      this.logger.error(`Reverse geocoding failed: ${err instanceof Error ? err.message : err}`);
      return { resolvedAddress: null, resolvedVia: 'unavailable' };
    }
  }
}
