import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AttendanceRecord } from '../attendance/entities/attendance.entity';
import { AuditLog } from '../audit/entities/audit-log.entity';
import { Batch, BatchStage } from '../batches/entities/batch.entity';
import { Employee } from '../employees/entities/employee.entity';
import { Invoice, InvoiceStatus } from '../invoices/entities/invoice.entity';
import { InventoryItem } from '../inventory/entities/inventory-item.entity';
import { Notification } from '../notifications/entities/notification.entity';
import { Order, OrderStatus } from '../orders/entities/order.entity';
import { Payment } from '../payments/entities/payment.entity';
import { ProductionRecord } from '../production/entities/production-record.entity';
import { WashingRecord } from '../washing/entities/washing-record.entity';
import { StockMovement } from '../warehouse/entities/warehouse.entity';
import {
  DashboardActivity,
  DashboardChart,
  DashboardChartPoint,
  DashboardNotificationItem,
  DashboardOverviewPayload,
  DashboardSummary,
  DashboardSystemHealth,
  DashboardTopEmployee,
} from './interfaces/dashboard.interface';

@Injectable()
export class DashboardStatisticsService {
  constructor(
    @InjectRepository(Employee)
    private readonly employeesRepository: Repository<Employee>,
    @InjectRepository(AttendanceRecord)
    private readonly attendanceRepository: Repository<AttendanceRecord>,
    @InjectRepository(InventoryItem)
    private readonly inventoryRepository: Repository<InventoryItem>,
    @InjectRepository(ProductionRecord)
    private readonly productionRepository: Repository<ProductionRecord>,
    @InjectRepository(WashingRecord)
    private readonly washingRepository: Repository<WashingRecord>,
    @InjectRepository(Batch)
    private readonly batchesRepository: Repository<Batch>,
    @InjectRepository(Order)
    private readonly ordersRepository: Repository<Order>,
    @InjectRepository(Invoice)
    private readonly invoicesRepository: Repository<Invoice>,
    @InjectRepository(Payment)
    private readonly paymentsRepository: Repository<Payment>,
    @InjectRepository(Notification)
    private readonly notificationsRepository: Repository<Notification>,
    @InjectRepository(AuditLog)
    private readonly auditLogsRepository: Repository<AuditLog>,
    @InjectRepository(StockMovement)
    private readonly stockMovementsRepository: Repository<StockMovement>,
  ) {}

  async getOverview(): Promise<DashboardOverviewPayload> {
    const today = new Date().toISOString().slice(0, 10);
    const currentMonthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10);
    const currentYearStart = new Date(new Date().getFullYear(), 0, 1).toISOString().slice(0, 10);
    const lastThirtyDays = new Date();
    lastThirtyDays.setDate(lastThirtyDays.getDate() - 29);
    const productionWindowStart = lastThirtyDays.toISOString().slice(0, 10);

    const [summary, charts, topPerformingEmployees, recentActivities, recentNotifications, systemHealth] = await Promise.all([
      this.getSummary(today, currentMonthStart, currentYearStart, productionWindowStart),
      this.getCharts(today),
      this.getTopPerformingEmployees(),
      this.getRecentActivities(),
      this.getRecentNotifications(),
      this.getSystemHealth(today),
    ]);

    return {
      summary,
      charts,
      topPerformingEmployees,
      recentActivities,
      recentNotifications,
      systemHealth,
      generatedAt: new Date().toISOString(),
    };
  }

  private async getSummary(today: string, currentMonthStart: string, currentYearStart: string, productionWindowStart: string): Promise<DashboardSummary> {
    const start = new Date(`${today}T00:00:00.000Z`);
    const end = new Date(`${today}T23:59:59.999Z`);

    const [totalEmployees, presentToday, lateEmployees, warehouseStockCount, productsRunningLow, ordersToday, ordersPending, ordersCompleted, boxesReceivedToday, boxesWashedToday, boxesReadyForDispatch, invoicesGeneratedToday, outstandingInvoices, paymentsReceivedToday, monthlyRevenue, yearlyRevenue, averageDailyProduction] = await Promise.all([
      this.employeesRepository.count({ where: { isActive: true } }),
      this.attendanceRepository.count({ where: { date: today } }),
      this.attendanceRepository.count({ where: { date: today, isLate: true } }),
      this.inventoryRepository
        .createQueryBuilder('item')
        .select('COALESCE(SUM(item.currentStock), 0)', 'stock')
        .getRawOne()
        .then((row) => Number(row.stock) || 0),
      this.inventoryRepository
        .createQueryBuilder('item')
        .where('item.reorderLevel > 0')
        .andWhere('item.currentStock <= item.reorderLevel')
        .getCount(),
      this.ordersRepository
        .createQueryBuilder('order')
        .where('order.createdAt >= :start', { start })
        .andWhere('order.createdAt <= :end', { end })
        .getCount(),
      this.ordersRepository.count({ where: { status: OrderStatus.DRAFT } }),
      this.ordersRepository.count({ where: { status: OrderStatus.INVOICED } }),
      this.productionRepository
        .createQueryBuilder('production')
        .select('COALESCE(SUM(production.boxes), 0)', 'boxes')
        .where('production.date = :today', { today })
        .getRawOne()
        .then((row) => Number(row.boxes) || 0),
      this.washingRepository.count({ where: { date: today } }),
      this.batchesRepository.count({ where: { currentStage: BatchStage.WAREHOUSE } }),
      this.invoicesRepository.count({ where: { invoiceDate: today } }),
      this.invoicesRepository.count({ where: { status: InvoiceStatus.SENT } }),
      this.paymentsRepository
        .createQueryBuilder('payment')
        .select('COALESCE(SUM(payment.amount), 0)', 'amount')
        .where('payment.paidOn = :today', { today })
        .getRawOne()
        .then((row) => Number(row.amount) || 0),
      this.invoicesRepository
        .createQueryBuilder('invoice')
        .select('COALESCE(SUM(invoice.total), 0)', 'revenue')
        .where('invoice.invoiceDate >= :currentMonthStart', { currentMonthStart })
        .getRawOne()
        .then((row) => Number(row.revenue) || 0),
      this.invoicesRepository
        .createQueryBuilder('invoice')
        .select('COALESCE(SUM(invoice.total), 0)', 'revenue')
        .where('invoice.invoiceDate >= :currentYearStart', { currentYearStart })
        .getRawOne()
        .then((row) => Number(row.revenue) || 0),
      this.productionRepository
        .createQueryBuilder('production')
        .select('COALESCE(SUM(production.boxes), 0)', 'boxes')
        .addSelect('COUNT(DISTINCT production.date)', 'days')
        .where('production.date >= :start', { start: productionWindowStart })
        .getRawOne()
        .then((row) => {
          const boxes = Number(row.boxes) || 0;
          const days = Number(row.days) || 0;
          return days > 0 ? boxes / days : 0;
        }),
    ]);

    return {
      totalEmployees,
      employeesPresentToday: presentToday,
      employeesAbsentToday: Math.max(0, totalEmployees - presentToday),
      lateEmployees,
      warehouseStockCount: warehouseStockCount,
      productsRunningLow,
      ordersToday,
      ordersPending,
      ordersCompleted,
      boxesReceivedToday,
      boxesWashedToday,
      boxesReadyForDispatch,
      invoicesGeneratedToday,
      outstandingInvoices,
      paymentsReceivedToday,
      monthlyRevenue,
      yearlyRevenue,
      averageDailyProduction,
    };
  }

  private async getCharts(today: string): Promise<DashboardChart[]> {
    const [attendanceTrend, revenueTrend, washingTrend, warehouseMovementTrend, employeeGrowthTrend, orderStatusChart] = await Promise.all([
      this.getAttendanceTrend(today),
      this.getRevenueTrend(),
      this.getWashingTrend(),
      this.getWarehouseMovementTrend(),
      this.getEmployeeGrowthTrend(),
      this.getOrderStatusChart(),
    ]);

    return [attendanceTrend, revenueTrend, washingTrend, warehouseMovementTrend, employeeGrowthTrend, orderStatusChart];
  }

  private async getAttendanceTrend(today: string): Promise<DashboardChart> {
    const start = new Date();
    start.setDate(start.getDate() - 6);
    const startDate = start.toISOString().slice(0, 10);

    const rows = await this.attendanceRepository
      .createQueryBuilder('attendance')
      .select('attendance.date', 'date')
      .addSelect('COUNT(DISTINCT attendance.employeeId)', 'present')
      .where('attendance.date >= :startDate', { startDate })
      .groupBy('attendance.date')
      .orderBy('attendance.date', 'ASC')
      .getRawMany();

    const values = new Map(rows.map((row) => [row.date, Number(row.present) || 0]));
    const data: DashboardChartPoint[] = [];

    for (let index = 0; index < 7; index += 1) {
      const current = new Date(start);
      current.setDate(start.getDate() + index);
      const label = current.toISOString().slice(0, 10);
      data.push({ label, value: values.get(label) ?? 0 });
    }

    return {
      key: 'attendance-trend',
      title: 'Attendance Trend',
      type: 'line',
      data,
    };
  }

  private async getRevenueTrend(): Promise<DashboardChart> {
    const monthsBack = new Date();
    monthsBack.setMonth(monthsBack.getMonth() - 5);
    const start = monthsBack.toISOString().slice(0, 10);

    const rows = await this.invoicesRepository
      .createQueryBuilder('invoice')
      .select('SUBSTRING(invoice."invoiceDate"::text FROM 1 FOR 7)', 'label')
      .addSelect('COALESCE(SUM(invoice.total), 0)', 'value')
      .where('invoice.invoiceDate >= :start', { start })
      .groupBy('SUBSTRING(invoice."invoiceDate"::text FROM 1 FOR 7)')
      .orderBy('SUBSTRING(invoice."invoiceDate"::text FROM 1 FOR 7)', 'ASC')
      .getRawMany();

    const data = rows.map((row) => ({ label: row.label, value: Number(row.value) || 0 }));
    return {
      key: 'revenue-trend',
      title: 'Revenue Trend',
      type: 'bar',
      data,
    };
  }

  private async getWashingTrend(): Promise<DashboardChart> {
    const start = new Date();
    start.setDate(start.getDate() - 6);
    const startDate = start.toISOString().slice(0, 10);

    const rows = await this.washingRepository
      .createQueryBuilder('washing')
      .select('washing.date', 'label')
      .addSelect('COUNT(washing.id)', 'value')
      .where('washing.date >= :startDate', { startDate })
      .groupBy('washing.date')
      .orderBy('washing.date', 'ASC')
      .getRawMany();

    const map = new Map(rows.map((row) => [row.label, Number(row.value) || 0]));
    const data: DashboardChartPoint[] = [];

    for (let index = 0; index < 7; index += 1) {
      const current = new Date(start);
      current.setDate(start.getDate() + index);
      const label = current.toISOString().slice(0, 10);
      data.push({ label, value: map.get(label) ?? 0 });
    }

    return {
      key: 'washing-production-trend',
      title: 'Washing Production Trend',
      type: 'line',
      data,
    };
  }

  private async getWarehouseMovementTrend(): Promise<DashboardChart> {
    const start = new Date();
    start.setDate(start.getDate() - 6);
    const startDate = start.toISOString().slice(0, 10);

    const rows = await this.stockMovementsRepository
      .createQueryBuilder('movement')
      .select('SUBSTRING(movement."createdAt"::text FROM 1 FOR 10)', 'label')
      .addSelect('COUNT(movement.id)', 'value')
      .where('movement.createdAt >= :startDate', { startDate })
      .groupBy('SUBSTRING(movement."createdAt"::text FROM 1 FOR 10)')
      .orderBy('SUBSTRING(movement."createdAt"::text FROM 1 FOR 10)', 'ASC')
      .getRawMany();

    const map = new Map(rows.map((row) => [row.label, Number(row.value) || 0]));
    const data: DashboardChartPoint[] = [];

    for (let index = 0; index < 7; index += 1) {
      const current = new Date(start);
      current.setDate(start.getDate() + index);
      const label = current.toISOString().slice(0, 10);
      data.push({ label, value: map.get(label) ?? 0 });
    }

    return {
      key: 'warehouse-movement',
      title: 'Warehouse Movement',
      type: 'bar',
      data,
    };
  }

  private async getEmployeeGrowthTrend(): Promise<DashboardChart> {
    const monthsBack = new Date();
    monthsBack.setMonth(monthsBack.getMonth() - 5);
    const start = monthsBack.toISOString().slice(0, 10);

    const rows = await this.employeesRepository
      .createQueryBuilder('employee')
      .select('SUBSTRING(employee."createdAt"::text FROM 1 FOR 7)', 'label')
      .addSelect('COUNT(employee.id)', 'value')
      .where('employee.createdAt >= :start', { start })
      .groupBy('SUBSTRING(employee."createdAt"::text FROM 1 FOR 7)')
      .orderBy('SUBSTRING(employee."createdAt"::text FROM 1 FOR 7)', 'ASC')
      .getRawMany();

    const data = rows.map((row) => ({ label: row.label, value: Number(row.value) || 0 }));
    return {
      key: 'employee-growth',
      title: 'Employee Growth',
      type: 'line',
      data,
    };
  }

  private async getOrderStatusChart(): Promise<DashboardChart> {
    const rows = await this.ordersRepository
      .createQueryBuilder('order')
      .select('order.status', 'label')
      .addSelect('COUNT(order.id)', 'value')
      .groupBy('order.status')
      .getRawMany();

    const data = rows.map((row) => ({ label: row.label, value: Number(row.value) || 0 }));
    return {
      key: 'order-status-pie',
      title: 'Order Status Pie Chart',
      type: 'pie',
      data,
    };
  }

  private async getTopPerformingEmployees(): Promise<DashboardTopEmployee[]> {
    const rows = await this.productionRepository
      .createQueryBuilder('production')
      .leftJoinAndSelect('production.operator', 'operator')
      .select('operator.id', 'id')
      .addSelect('operator.fullName', 'fullName')
      .addSelect('operator.employeeCode', 'employeeCode')
      .addSelect('COALESCE(SUM(production.boxes), 0)', 'boxes')
      .groupBy('operator.id')
      .addGroupBy('operator.fullName')
      .addGroupBy('operator.employeeCode')
      .orderBy('boxes', 'DESC')
      .limit(5)
      .getRawMany();

    return rows.map((row) => ({
      id: row.id,
      fullName: row.fullName,
      employeeCode: row.employeeCode,
      boxes: Number(row.boxes) || 0,
    }));
  }

  private async getRecentActivities(): Promise<DashboardActivity[]> {
    const logs = await this.auditLogsRepository
      .createQueryBuilder('log')
      .leftJoinAndSelect('log.user', 'user')
      .orderBy('log.createdAt', 'DESC')
      .limit(10)
      .getMany();

    return logs.map((log) => ({
      id: log.id,
      action: log.action,
      entityType: log.entityType,
      createdAt: log.createdAt.toISOString(),
      userName: log.user?.fullName ?? log.user?.email ?? undefined,
    }));
  }

  private async getRecentNotifications(): Promise<DashboardNotificationItem[]> {
    const notifications = await this.notificationsRepository
      .createQueryBuilder('notification')
      .leftJoinAndSelect('notification.recipient', 'recipient')
      .orderBy('notification.createdAt', 'DESC')
      .limit(10)
      .getMany();

    return notifications.map((notification) => ({
      id: notification.id,
      message: notification.message,
      type: notification.type,
      createdAt: notification.createdAt.toISOString(),
      isRead: notification.isRead,
    }));
  }

  private async getSystemHealth(today: string): Promise<DashboardSystemHealth> {
    const [inventoryRisk, attendanceRisk] = await Promise.all([
      this.inventoryRepository
        .createQueryBuilder('item')
        .where('item.reorderLevel > 0')
        .andWhere('item.currentStock <= item.reorderLevel')
        .getCount(),
      this.attendanceRepository.count({ where: { date: today } }),
    ]);

    let status: DashboardSystemHealth['status'] = 'healthy';
    if (inventoryRisk > 0 || attendanceRisk === 0) {
      status = 'warning';
    }

    return {
      status,
      updatedAt: new Date().toISOString(),
      checks: {
        database: 'connected',
        inventory: inventoryRisk > 0 ? 'warning' : 'healthy',
        attendance: attendanceRisk > 0 ? 'healthy' : 'warning',
      },
      alerts: inventoryRisk,
    };
  }

}
