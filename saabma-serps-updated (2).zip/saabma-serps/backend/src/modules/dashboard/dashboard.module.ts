import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Employee } from '../employees/entities/employee.entity';
import { AttendanceRecord } from '../attendance/entities/attendance.entity';
import { InventoryItem } from '../inventory/entities/inventory-item.entity';
import { ProductionRecord } from '../production/entities/production-record.entity';
import { WashingRecord } from '../washing/entities/washing-record.entity';
import { Batch } from '../batches/entities/batch.entity';
import { Order } from '../orders/entities/order.entity';
import { Invoice } from '../invoices/entities/invoice.entity';
import { Payment } from '../payments/entities/payment.entity';
import { Notification } from '../notifications/entities/notification.entity';
import { AuditLog } from '../audit/entities/audit-log.entity';
import { StockMovement } from '../warehouse/entities/warehouse.entity';
import { DashboardService } from './dashboard.service';
import { DashboardController } from './dashboard.controller';
import { DashboardStatisticsService } from './dashboard-statistics.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Employee,
      AttendanceRecord,
      InventoryItem,
      ProductionRecord,
      WashingRecord,
      Batch,
      Order,
      Invoice,
      Payment,
      Notification,
      AuditLog,
      StockMovement,
    ]),
  ],
  controllers: [DashboardController],
  providers: [DashboardService, DashboardStatisticsService],
})
export class DashboardModule {}
