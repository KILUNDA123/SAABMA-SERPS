import {
  DashboardActivity,
  DashboardChart,
  DashboardNotificationItem,
  DashboardOverviewPayload,
  DashboardSummary,
  DashboardSystemHealth,
  DashboardTopEmployee,
} from '../interfaces/dashboard.interface';

export class DashboardOverviewResponse implements DashboardOverviewPayload {
  summary: DashboardSummary;
  charts: DashboardChart[];
  topPerformingEmployees: DashboardTopEmployee[];
  recentActivities: DashboardActivity[];
  recentNotifications: DashboardNotificationItem[];
  systemHealth: DashboardSystemHealth;
  generatedAt: string;
}
