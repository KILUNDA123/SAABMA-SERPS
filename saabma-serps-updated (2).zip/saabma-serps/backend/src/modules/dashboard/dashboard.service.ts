import { Injectable } from '@nestjs/common';
import { DashboardStatisticsService } from './dashboard-statistics.service';
import { DashboardOverviewPayload } from './interfaces/dashboard.interface';

@Injectable()
export class DashboardService {
  private readonly overviewCache = new Map<string, { expiresAt: number; payload: DashboardOverviewPayload }>();

  constructor(private readonly statisticsService: DashboardStatisticsService) {}

  async overview(): Promise<DashboardOverviewPayload> {
    const cacheKey = 'dashboard-overview';
    const cached = this.overviewCache.get(cacheKey);
    const now = Date.now();

    if (cached && cached.expiresAt > now) {
      return cached.payload;
    }

    const payload = await this.statisticsService.getOverview();
    this.overviewCache.set(cacheKey, { expiresAt: now + 60_000, payload });
    return payload;
  }

  async cards() {
    const payload = await this.overview();
    return {
      totalEmployees: payload.summary.totalEmployees,
      employeesPresentToday: payload.summary.employeesPresentToday,
      employeesAbsentToday: payload.summary.employeesAbsentToday,
      lateEmployees: payload.summary.lateEmployees,
      warehouseStockCount: payload.summary.warehouseStockCount,
      productsRunningLow: payload.summary.productsRunningLow,
      ordersToday: payload.summary.ordersToday,
      ordersPending: payload.summary.ordersPending,
      ordersCompleted: payload.summary.ordersCompleted,
      boxesReceivedToday: payload.summary.boxesReceivedToday,
      boxesWashedToday: payload.summary.boxesWashedToday,
      boxesReadyForDispatch: payload.summary.boxesReadyForDispatch,
      invoicesGeneratedToday: payload.summary.invoicesGeneratedToday,
      outstandingInvoices: payload.summary.outstandingInvoices,
      paymentsReceivedToday: payload.summary.paymentsReceivedToday,
      monthlyRevenue: payload.summary.monthlyRevenue,
      yearlyRevenue: payload.summary.yearlyRevenue,
      averageDailyProduction: payload.summary.averageDailyProduction,
    };
  }
}
