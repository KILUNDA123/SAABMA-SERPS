export class DashboardSummaryDto {
  totalEmployees: number;
  employeesPresentToday: number;
  employeesAbsentToday: number;
  lateEmployees: number;
  warehouseStockCount: number;
  productsRunningLow: number;
  ordersToday: number;
  ordersPending: number;
  ordersCompleted: number;
  boxesReceivedToday: number;
  boxesWashedToday: number;
  boxesReadyForDispatch: number;
  invoicesGeneratedToday: number;
  outstandingInvoices: number;
  paymentsReceivedToday: number;
  monthlyRevenue: number;
  yearlyRevenue: number;
  averageDailyProduction: number;
}

export class DashboardChartPointDto {
  label: string;
  value: number;
}

export class DashboardChartDto {
  key: string;
  title: string;
  type: 'line' | 'bar' | 'pie';
  data: DashboardChartPointDto[];
}

export class DashboardTopEmployeeDto {
  id: string;
  fullName: string;
  employeeCode: string;
  boxes: number;
}

export class DashboardActivityDto {
  id: string;
  action: string;
  entityType: string;
  createdAt: string;
  userName?: string;
}

export class DashboardNotificationDto {
  id: string;
  message: string;
  type: string;
  createdAt: string;
  isRead: boolean;
}

export class DashboardSystemHealthDto {
  status: 'healthy' | 'warning' | 'critical';
  updatedAt: string;
  checks: {
    database: string;
    inventory: string;
    attendance: string;
  };
  alerts: number;
}

export class DashboardOverviewDto {
  summary: DashboardSummaryDto;
  charts: DashboardChartDto[];
  topPerformingEmployees: DashboardTopEmployeeDto[];
  recentActivities: DashboardActivityDto[];
  recentNotifications: DashboardNotificationDto[];
  systemHealth: DashboardSystemHealthDto;
  generatedAt: string;
}
