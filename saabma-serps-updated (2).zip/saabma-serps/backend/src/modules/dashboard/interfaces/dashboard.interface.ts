export interface DashboardSummary {
  totalEmployees: number;
  employeesPresentToday: number;
  employeesAbsentToday: number;
  lateEmployees: number;
  warehouseStockCount: number;
  productsRunningLow: number;
  ordersToday: number;
  ordersPending: number;
  ordersCompleted: number;
  boxesReceivedToday: number;
  boxesWashedToday: number;
  boxesReadyForDispatch: number;
  invoicesGeneratedToday: number;
  outstandingInvoices: number;
  paymentsReceivedToday: number;
  monthlyRevenue: number;
  yearlyRevenue: number;
  averageDailyProduction: number;
}

export interface DashboardChartPoint {
  label: string;
  value: number;
}

export interface DashboardChart {
  key: string;
  title: string;
  type: 'line' | 'bar' | 'pie';
  data: DashboardChartPoint[];
}

export interface DashboardTopEmployee {
  id: string;
  fullName: string;
  employeeCode: string;
  boxes: number;
}

export interface DashboardActivity {
  id: string;
  action: string;
  entityType: string;
  createdAt: string;
  userName?: string;
}

export interface DashboardNotificationItem {
  id: string;
  message: string;
  type: string;
  createdAt: string;
  isRead: boolean;
}

export interface DashboardSystemHealth {
  status: 'healthy' | 'warning' | 'critical';
  updatedAt: string;
  checks: {
    database: string;
    inventory: string;
    attendance: string;
  };
  alerts: number;
}

export interface DashboardOverviewPayload {
  summary: DashboardSummary;
  charts: DashboardChart[];
  topPerformingEmployees: DashboardTopEmployee[];
  recentActivities: DashboardActivity[];
  recentNotifications: DashboardNotificationItem[];
  systemHealth: DashboardSystemHealth;
  generatedAt: string;
}
