import { Injectable, ConflictException, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcryptjs';
import * as crypto from 'crypto';
import { User, UserRole, AccountStatus } from './entities/user.entity';
import { AuditLog } from '../audit/entities/audit-log.entity';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private readonly usersRepository: Repository<User>,
    @InjectRepository(AuditLog)
    private readonly auditLogRepository: Repository<AuditLog>,
  ) {}

  async findByEmail(email: string): Promise<User | null> {
    return this.usersRepository.findOne({ where: { email } });
  }

  async findByEmployeeId(employeeId: string): Promise<User | null> {
    return this.usersRepository.findOne({ where: { employeeId } });
  }

  async findById(id: string): Promise<User> {
    const user = await this.usersRepository.findOne({ where: { id } });
    if (!user) {
      throw new NotFoundException('User not found');
    }
    return user;
  }

  async create(data: { employeeId: string; email?: string; password: string; fullName: string; role: any }): Promise<User> {
    const existing = await this.findByEmployeeId(data.employeeId);
    if (existing) {
      throw new ConflictException('A user with this employee ID already exists');
    }

    const passwordHash = await bcrypt.hash(data.password, 10);

    const user = this.usersRepository.create({
      employeeId: data.employeeId,
      email: data.email,
      passwordHash,
      fullName: data.fullName,
      role: data.role,
      // Accounts created by HR/CEO start with a temporary password and are
      // forced to change it on first login.
      mustChangePassword: true,
    });

    return this.usersRepository.save(user);
  }

  async findByRole(role: UserRole): Promise<User[]> {
    return this.usersRepository.find({ where: { role, isActive: true } });
  }

  async updateLastLogin(id: string): Promise<void> {
    await this.usersRepository.update(id, { lastLoginAt: new Date() });
  }

  async updateFields(id: string, patch: Partial<User>): Promise<void> {
    await this.usersRepository.update(id, patch);
  }

  // Employees do not reset their own passwords - this is only ever called
  // from an endpoint guarded to CEO/HR/ADMIN. Generates a temporary
  // password, forces a change at next login, and logs who did it.
  async resetPassword(targetUserId: string, performedByUserId: string, ipAddress?: string, userAgent?: string): Promise<{ temporaryPassword: string }> {
    const user = await this.findById(targetUserId);
    // 16 random bytes -> readable base32-ish temp password, still meets the
    // 12+/upper/lower/number/special policy by construction.
    const temporaryPassword = `Sb${crypto.randomBytes(6).toString('hex')}!${Math.floor(10 + Math.random() * 89)}`;
    const passwordHash = await bcrypt.hash(temporaryPassword, 10);

    await this.usersRepository.update(targetUserId, {
      passwordHash,
      mustChangePassword: true,
      failedLoginAttempts: 0,
      lockedUntil: null,
      accountStatus: user.accountStatus === AccountStatus.LOCKED ? AccountStatus.ACTIVE : user.accountStatus,
    });

    await this.auditLogRepository.save(
      this.auditLogRepository.create({
        user: { id: performedByUserId } as User,
        action: 'PASSWORD_RESET',
        entityType: 'User',
        entityId: targetUserId,
        newValue: { resetFor: user.employeeId },
        ipAddress,
        userAgent,
      }),
    );

    return { temporaryPassword };
  }

  // Only authorized administrators may change account status (enforced by
  // guards at the controller). Unlocking clears the failure counter too.
  async changeStatus(targetUserId: string, status: AccountStatus, performedByUserId: string, ipAddress?: string, userAgent?: string): Promise<User> {
    const user = await this.findById(targetUserId);
    const patch: Partial<User> = { accountStatus: status };
    if (status === AccountStatus.ACTIVE) {
      patch.failedLoginAttempts = 0;
      patch.lockedUntil = null;
    }
    await this.usersRepository.update(targetUserId, patch);

    await this.auditLogRepository.save(
      this.auditLogRepository.create({
        user: { id: performedByUserId } as User,
        action: 'ACCOUNT_STATUS_CHANGED',
        entityType: 'User',
        entityId: targetUserId,
        oldValue: { status: user.accountStatus },
        newValue: { status, employeeId: user.employeeId },
        ipAddress,
        userAgent,
      }),
    );

    return this.findById(targetUserId);
  }

  async findAll(): Promise<User[]> {
    return this.usersRepository.find({ order: { createdAt: 'DESC' } });
  }
}
