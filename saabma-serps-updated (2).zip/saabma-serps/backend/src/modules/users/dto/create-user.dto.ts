import { IsEmail, IsString, IsOptional, IsEnum, Matches, Length } from 'class-validator';
import { UserRole } from '../entities/user.entity';

// Enterprise password policy: 12+ chars, at least one uppercase, one
// lowercase, one digit, one special character. bcrypt hashing happens in
// UsersService - this DTO only validates the plaintext shape before it's
// ever hashed.
const PASSWORD_POLICY = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{12,}$/;
const PASSWORD_POLICY_MESSAGE =
  'Password must be at least 12 characters and include an uppercase letter, a lowercase letter, a number, and a special character';

export class CreateUserDto {
  // Company-issued identifier, e.g. SERP/EXE/001 - this is the login
  // credential, not email.
  @IsString()
  @Length(3, 40)
  employeeId: string;

  @IsString()
  @Matches(PASSWORD_POLICY, { message: PASSWORD_POLICY_MESSAGE })
  password: string;

  @IsString()
  fullName: string;

  @IsEnum(UserRole)
  role: UserRole;

  // Contact info only now - no longer the login credential.
  @IsOptional()
  @IsEmail()
  email?: string;
}

export { PASSWORD_POLICY, PASSWORD_POLICY_MESSAGE };
