import { IsEnum } from 'class-validator';
import { AccountStatus } from '../entities/user.entity';

export class ChangeStatusDto {
  @IsEnum(AccountStatus)
  status: AccountStatus;
}
