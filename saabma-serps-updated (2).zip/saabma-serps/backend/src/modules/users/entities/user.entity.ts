import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, OneToOne } from 'typeorm';

export enum UserRole {
  CEO = 'ceo',
  OPERATIONS_MANAGER = 'operations_manager',
  SUPERVISOR = 'supervisor',
  PRODUCTION_OPERATOR = 'production_operator',
  WAREHOUSE = 'warehouse',
  FINANCE = 'finance',
  HR = 'hr',
  SALES = 'sales',
  DRIVER = 'driver',
  SECURITY = 'security',
  ADMIN = 'admin',
  CASUAL_WORKER = 'casual_worker',
}

export enum AccountStatus {
  ACTIVE = 'active',
  SUSPENDED = 'suspended',
  INACTIVE = 'inactive',
  LOCKED = 'locked',
  PENDING_FIRST_LOGIN = 'pending_first_login',
}

@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  // Company-issued login identifier (e.g. SERP/EXE/001) - the actual
  // credential used to sign in. Kept unique and separate from email, which
  // is now just a contact field, per the "do not use email as the primary
  // login credential" policy.
  @Column({ unique: true })
  employeeId: string;

  @Column({ unique: true, nullable: true })
  email: string;

  @Column()
  passwordHash: string;

  @Column()
  fullName: string;

  @Column({ type: 'enum', enum: UserRole })
  role: UserRole;

  @Column({ default: true })
  isActive: boolean;

  @Column({ type: 'enum', enum: AccountStatus, default: AccountStatus.ACTIVE })
  accountStatus: AccountStatus;

  // Set true by HR/CEO when creating an account or resetting a password -
  // the user cannot reach anything else until they change it.
  @Column({ default: false })
  mustChangePassword: boolean;

  @Column({ default: 0 })
  failedLoginAttempts: number;

  // Set when failedLoginAttempts crosses the threshold; login is refused
  // until this timestamp passes, even with the correct password.
  @Column({ type: 'timestamp', nullable: true })
  lockedUntil: Date | null;

  @Column({ type: 'timestamp', nullable: true })
  passwordChangedAt: Date | null;

  // Set fresh on every successful login. A JWT's sessionId must match this
  // exact value to be accepted (see JwtStrategy) - logging in again from
  // anywhere overwrites it, silently invalidating every older token. This
  // is what enforces "single active session per user".
  @Column({ type: 'varchar', nullable: true })
  currentSessionId: string | null;

  @Column({ nullable: true })
  lastLoginAt: Date;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
