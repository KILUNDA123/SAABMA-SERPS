import { Controller, Post, Body, Get, Patch, Param, UseGuards, Request } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { ChangeStatusDto } from './dto/change-status.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from './entities/user.entity';

// Every endpoint here is gated by @Roles() against the real UserRole enum -
// no role name is ever compared as a hardcoded string in the method bodies.
// The set of roles allowed per action mirrors the auth policy doc exactly:
//   - create account, reset password -> CEO, HR, ADMIN
//   - change account status (suspend/lock/unlock/activate) -> CEO, ADMIN only
//   - list accounts -> CEO, HR, ADMIN (needed to pick a target for the above)
@Controller('users')
@UseGuards(JwtAuthGuard, RolesGuard)
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post()
  @Roles(UserRole.CEO, UserRole.HR, UserRole.ADMIN)
  async create(@Body() dto: CreateUserDto) {
    const user = await this.usersService.create(dto);
    const { passwordHash, ...safeUser } = user;
    return safeUser;
  }

  @Get()
  @Roles(UserRole.CEO, UserRole.HR, UserRole.ADMIN)
  async findAll() {
    const users = await this.usersService.findAll();
    return users.map(({ passwordHash, ...safeUser }) => safeUser);
  }

  @Post(':id/reset-password')
  @Roles(UserRole.CEO, UserRole.HR, UserRole.ADMIN)
  @Throttle({ default: { limit: 10, ttl: 60_000 } })
  async resetPassword(@Param('id') id: string, @Request() req: any) {
    return this.usersService.resetPassword(id, req.user.userId, req.ip, req.headers['user-agent']);
  }

  @Patch(':id/status')
  @Roles(UserRole.CEO, UserRole.ADMIN)
  async changeStatus(@Param('id') id: string, @Body() dto: ChangeStatusDto, @Request() req: any) {
    const user = await this.usersService.changeStatus(id, dto.status, req.user.userId, req.ip, req.headers['user-agent']);
    const { passwordHash, ...safeUser } = user;
    return safeUser;
  }
}
