import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, CreateDateColumn } from 'typeorm';
import { User } from '../../users/entities/user.entity';

export enum NotificationType {
  INVOICE_PAID = 'invoice_paid',
  LOW_STOCK = 'low_stock',
  ATTENDANCE_MISSING = 'attendance_missing',
  SHIPMENT_LOADED = 'shipment_loaded',
  APPROVAL_NEEDED = 'approval_needed',
  SECURITY_ALERT = 'security_alert',
  GENERAL = 'general',
}

@Entity('notifications')
export class Notification {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User)
  @JoinColumn()
  recipient: User;

  @Column({ type: 'enum', enum: NotificationType })
  type: NotificationType;

  @Column()
  message: string;

  @Column({ nullable: true })
  linkRef: string; // e.g. '/production/123' so the frontend can deep-link

  @Column({ default: false })
  isRead: boolean;

  @CreateDateColumn()
  createdAt: Date;
}
