import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Notification, NotificationType } from './entities/notification.entity';
import { UsersService } from '../users/users.service';
import { UserRole, User } from '../users/entities/user.entity';

@Injectable()
export class NotificationsService {
  constructor(
    @InjectRepository(Notification)
    private readonly notificationsRepository: Repository<Notification>,
    private readonly usersService: UsersService,
  ) {}

  async notifyUser(
    recipient: User,
    type: NotificationType,
    message: string,
    linkRef?: string,
  ): Promise<Notification> {
    const notification = this.notificationsRepository.create({ recipient, type, message, linkRef });
    return this.notificationsRepository.save(notification);
  }

  // Broadcasts to every active user holding a given role - this is how
  // "Invoice Paid -> CEO notified" or "Low Hydrogen -> Store notified" from
  // the original plan actually gets implemented: no single user is "the
  // CEO", so we notify whoever currently holds that role.
  async notifyRole(
    role: UserRole,
    type: NotificationType,
    message: string,
    linkRef?: string,
  ): Promise<Notification[]> {
    const recipients = await this.usersService.findByRole(role);
    return Promise.all(recipients.map((user) => this.notifyUser(user, type, message, linkRef)));
  }

  async findForUser(userId: string): Promise<Notification[]> {
    return this.notificationsRepository.find({
      where: { recipient: { id: userId } },
      order: { createdAt: 'DESC' },
    });
  }

  async findUnreadForUser(userId: string): Promise<Notification[]> {
    return this.notificationsRepository.find({
      where: { recipient: { id: userId }, isRead: false },
      order: { createdAt: 'DESC' },
    });
  }

  async markRead(id: string, userId: string): Promise<Notification> {
    const notification = await this.notificationsRepository.findOne({
      where: { id },
      relations: ['recipient'],
    });
    if (!notification || notification.recipient.id !== userId) {
      throw new NotFoundException('Notification not found');
    }
    notification.isRead = true;
    return this.notificationsRepository.save(notification);
  }

  async markAllRead(userId: string): Promise<void> {
    await this.notificationsRepository.update({ recipient: { id: userId }, isRead: false }, { isRead: true });
  }
}
