import { Controller, Get, Patch, Param, Request, UseGuards } from '@nestjs/common';
import { NotificationsService } from './notifications.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../permissions/permissions.guard';
import { RequirePermission } from '../permissions/require-permission.decorator';
import { PERMISSIONS } from '../permissions/permissions.constants';

// Every user sees only their OWN notifications - identity comes from the
// JWT (req.user.userId), never from a route parameter, so there is no way
// to request someone else's inbox by guessing an id.
@Controller('notifications')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class NotificationsController {
  constructor(private readonly notificationsService: NotificationsService) {}

  @Get()
  @RequirePermission(PERMISSIONS.NOTIFICATIONS_VIEW)
  findMine(@Request() req: any) {
    return this.notificationsService.findForUser(req.user.userId);
  }

  @Get('unread')
  @RequirePermission(PERMISSIONS.NOTIFICATIONS_VIEW)
  findUnread(@Request() req: any) {
    return this.notificationsService.findUnreadForUser(req.user.userId);
  }

  @Patch('read-all')
  @RequirePermission(PERMISSIONS.NOTIFICATIONS_VIEW)
  markAllRead(@Request() req: any) {
    return this.notificationsService.markAllRead(req.user.userId);
  }

  @Patch(':id/read')
  @RequirePermission(PERMISSIONS.NOTIFICATIONS_VIEW)
  markRead(@Param('id') id: string, @Request() req: any) {
    return this.notificationsService.markRead(id, req.user.userId);
  }
}
