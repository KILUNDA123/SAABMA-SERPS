import { Controller, Post, Get, Patch, Param, Body, UseGuards } from '@nestjs/common';
import { ProductionService } from './production.service';
import { CreateProductionRecordDto } from './dto/create-production-record.dto';
import { ReviewProductionRecordDto } from './dto/review-production-record.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../permissions/permissions.guard';
import { RequirePermission } from '../permissions/require-permission.decorator';
import { PERMISSIONS } from '../permissions/permissions.constants';

@Controller('production')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class ProductionController {
  constructor(private readonly productionService: ProductionService) {}

  @Post()
  @RequirePermission(PERMISSIONS.PRODUCTION_CREATE)
  create(@Body() dto: CreateProductionRecordDto) {
    return this.productionService.create(dto);
  }

  @Get()
  @RequirePermission(PERMISSIONS.PRODUCTION_VIEW)
  findAll() {
    return this.productionService.findAll();
  }

  @Get('pending')
  @RequirePermission(PERMISSIONS.PRODUCTION_VIEW)
  findPending() {
    return this.productionService.findPending();
  }

  @Get(':id')
  @RequirePermission(PERMISSIONS.PRODUCTION_VIEW)
  findOne(@Param('id') id: string) {
    return this.productionService.findOne(id);
  }

  // Approving/rejecting a stage requires production:approve - previously
  // hardcoded to @Roles(SUPERVISOR, OPERATIONS_MANAGER, CEO); now any role
  // granted the permission can do this, without a code change.
  @Patch(':id/review')
  @RequirePermission(PERMISSIONS.PRODUCTION_APPROVE)
  review(@Param('id') id: string, @Body() dto: ReviewProductionRecordDto) {
    return this.productionService.review(id, dto);
  }
}
