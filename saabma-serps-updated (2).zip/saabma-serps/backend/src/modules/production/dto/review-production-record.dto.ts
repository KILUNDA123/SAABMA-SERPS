import { IsEnum, IsOptional, IsString, IsUUID } from 'class-validator';
import { ApprovalStatus } from '../entities/production-record.entity';

export class ReviewProductionRecordDto {
  @IsUUID()
  reviewerEmployeeId: string; // the Employee record of whoever is approving/rejecting

  @IsEnum(ApprovalStatus)
  decision: ApprovalStatus; // APPROVED or REJECTED

  @IsOptional()
  @IsString()
  comment?: string;
}
