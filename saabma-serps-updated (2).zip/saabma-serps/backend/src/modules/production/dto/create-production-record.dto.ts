import { IsUUID, IsString, IsOptional, IsInt, Min, IsNumber } from 'class-validator';

export class CreateProductionRecordDto {
  @IsUUID()
  batchId: string;

  @IsUUID()
  operatorId: string;

  @IsString()
  date: string; // 'YYYY-MM-DD'

  @IsString()
  shift: string;

  @IsOptional()
  @IsString()
  machine?: string;

  @IsInt()
  @Min(0)
  boxes: number;

  @IsNumber()
  @Min(0)
  weightKg: number;

  @IsOptional()
  @IsString()
  remarks?: string;
}
