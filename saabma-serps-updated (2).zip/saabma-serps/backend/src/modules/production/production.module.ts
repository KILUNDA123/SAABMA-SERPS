import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductionRecord } from './entities/production-record.entity';
import { Approval } from '../approvals/entities/approval.entity';
import { ProductionService } from './production.service';
import { ProductionController } from './production.controller';
import { BatchesModule } from '../batches/batches.module';
import { EmployeesModule } from '../employees/employees.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([ProductionRecord, Approval]),
    BatchesModule,
    EmployeesModule,
  ],
  controllers: [ProductionController],
  providers: [ProductionService],
  exports: [ProductionService],
})
export class ProductionModule {}
