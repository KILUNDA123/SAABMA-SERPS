import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Batch } from '../../batches/entities/batch.entity';
import { Employee } from '../../employees/entities/employee.entity';

export enum ApprovalStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected',
}

@Entity('production_records')
export class ProductionRecord {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Batch)
  @JoinColumn()
  batch: Batch;

  @ManyToOne(() => Employee)
  @JoinColumn()
  operator: Employee;

  @Column({ type: 'date' })
  date: string;

  @Column()
  shift: string;

  @Column({ nullable: true })
  machine: string;

  @Column({ default: 0 })
  boxes: number;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  weightKg: number;

  @Column({ nullable: true })
  remarks: string;

  @Column({ type: 'enum', enum: ApprovalStatus, default: ApprovalStatus.PENDING })
  status: ApprovalStatus;

  @ManyToOne(() => Employee, { nullable: true })
  @JoinColumn()
  approvedBy: Employee;

  @Column({ nullable: true })
  approvedAt: Date;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
