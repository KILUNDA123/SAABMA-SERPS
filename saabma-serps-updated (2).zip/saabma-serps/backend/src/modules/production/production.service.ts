import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ProductionRecord, ApprovalStatus } from './entities/production-record.entity';
import { Approval, ApprovableEntityType } from '../approvals/entities/approval.entity';
import { BatchesService } from '../batches/batches.service';
import { EmployeesService } from '../employees/employees.service';

@Injectable()
export class ProductionService {
  constructor(
    @InjectRepository(ProductionRecord)
    private readonly productionRepository: Repository<ProductionRecord>,
    @InjectRepository(Approval)
    private readonly approvalsRepository: Repository<Approval>,
    private readonly batchesService: BatchesService,
    private readonly employeesService: EmployeesService,
  ) {}

  async create(data: {
    batchId: string;
    operatorId: string;
    date: string;
    shift: string;
    machine?: string;
    boxes: number;
    weightKg: number;
    remarks?: string;
  }): Promise<ProductionRecord> {
    const batch = await this.batchesService.findOne(data.batchId);
    const operator = await this.employeesService.findOne(data.operatorId);

    const record = this.productionRepository.create({
      batch,
      operator,
      date: data.date,
      shift: data.shift,
      machine: data.machine,
      boxes: data.boxes,
      weightKg: data.weightKg,
      remarks: data.remarks,
      status: ApprovalStatus.PENDING,
    });

    return this.productionRepository.save(record);
  }

  async findAll(): Promise<ProductionRecord[]> {
    return this.productionRepository.find({
      relations: ['batch', 'operator', 'approvedBy'],
      order: { createdAt: 'DESC' },
    });
  }

  async findPending(): Promise<ProductionRecord[]> {
    return this.productionRepository.find({
      where: { status: ApprovalStatus.PENDING },
      relations: ['batch', 'operator'],
      order: { createdAt: 'ASC' },
    });
  }

  async findOne(id: string): Promise<ProductionRecord> {
    const record = await this.productionRepository.findOne({
      where: { id },
      relations: ['batch', 'operator', 'approvedBy'],
    });
    if (!record) {
      throw new NotFoundException('Production record not found');
    }
    return record;
  }

  // Approve or reject: updates the record's own status column (fast filtering)
  // AND writes a row to the shared `approvals` table (audit trail: who, when, comment).
  async review(
    id: string,
    data: { reviewerEmployeeId: string; decision: ApprovalStatus; comment?: string },
  ): Promise<ProductionRecord> {
    if (data.decision === ApprovalStatus.PENDING) {
      throw new BadRequestException('Decision must be APPROVED or REJECTED');
    }

    const record = await this.findOne(id);
    if (record.status !== ApprovalStatus.PENDING) {
      throw new BadRequestException(`Record has already been ${record.status}`);
    }

    const reviewer = await this.employeesService.findOne(data.reviewerEmployeeId);

    record.status = data.decision;
    record.approvedBy = reviewer;
    record.approvedAt = new Date();
    const saved = await this.productionRepository.save(record);

    const approval = this.approvalsRepository.create({
      entityType: ApprovableEntityType.PRODUCTION,
      entityId: record.id,
      reviewedBy: reviewer,
      decision: data.decision,
      comment: data.comment,
    });
    await this.approvalsRepository.save(approval);

    return saved;
  }
}
