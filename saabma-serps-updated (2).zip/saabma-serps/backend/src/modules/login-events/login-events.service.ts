import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { LoginEvent } from './entities/login-event.entity';
import { parseUserAgent } from '../../common/utils/user-agent.util';

@Injectable()
export class LoginEventsService {
  constructor(
    @InjectRepository(LoginEvent)
    private readonly loginEventsRepository: Repository<LoginEvent>,
  ) {}

  async findAll(limit = 200) {
    const events = await this.loginEventsRepository.find({
      relations: ['user'],
      order: { createdAt: 'DESC' },
      take: limit,
    });

    return events.map((e) => {
      const { deviceType, os, browser } = parseUserAgent(e.userAgent);
      return {
        id: e.id,
        employeeId: e.user?.employeeId,
        fullName: e.user?.fullName,
        role: e.user?.role,
        loginTime: e.createdAt,
        ipAddress: e.ipAddress,
        latitude: e.latitude,
        longitude: e.longitude,
        accuracyMeters: e.accuracyMeters,
        resolvedAddress: e.resolvedAddress,
        deviceType,
        os,
        browser,
      };
    });
  }
}
