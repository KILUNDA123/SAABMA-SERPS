import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, CreateDateColumn } from 'typeorm';
import { User } from '../../users/entities/user.entity';

// Every successful login writes one of these. Location is mandatory at the
// API level (see LoginDto) - a login request with no coordinates is rejected
// before it ever reaches AuthService. This gives a permanent, queryable
// history of where every staff member (including drivers) logged in from -
// useful for security review and, for drivers, as a lightweight location log
// without needing a separate always-on GPS tracking system.
@Entity('login_events')
export class LoginEvent {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User)
  @JoinColumn()
  user: User;

  @Column('decimal', { precision: 10, scale: 7 })
  latitude: number;

  @Column('decimal', { precision: 10, scale: 7 })
  longitude: number;

  @Column({ nullable: true })
  accuracyMeters: number;

  // Reverse-geocoded via Google Maps Geocoding API. Nullable because the
  // lookup can fail (no API key configured, network issue, rate limit) -
  // in that case we still store the raw coordinates so nothing is lost.
  @Column({ nullable: true })
  resolvedAddress: string;

  @Column({ nullable: true })
  ipAddress: string;

  @Column({ nullable: true })
  userAgent: string;

  @CreateDateColumn()
  createdAt: Date;
}
