import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LoginEvent } from './entities/login-event.entity';
import { LoginEventsService } from './login-events.service';
import { LoginEventsController } from './login-events.controller';

@Module({
  imports: [TypeOrmModule.forFeature([LoginEvent])],
  controllers: [LoginEventsController],
  providers: [LoginEventsService],
  exports: [TypeOrmModule],
})
export class LoginEventsModule {}
