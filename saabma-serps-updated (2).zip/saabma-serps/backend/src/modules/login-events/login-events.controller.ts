import { Controller, Get, UseGuards } from '@nestjs/common';
import { LoginEventsService } from './login-events.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../permissions/permissions.guard';
import { RequirePermission } from '../permissions/require-permission.decorator';
import { PERMISSIONS } from '../permissions/permissions.constants';

@Controller('login-events')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class LoginEventsController {
  constructor(private readonly loginEventsService: LoginEventsService) {}

  @Get()
  @RequirePermission(PERMISSIONS.LOCATION_LOGS_VIEW)
  async findAll() {
    return this.loginEventsService.findAll();
  }
}
