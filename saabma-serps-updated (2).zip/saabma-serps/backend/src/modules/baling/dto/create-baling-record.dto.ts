import { IsUUID, IsString, IsOptional, IsInt, Min, IsNumber } from 'class-validator';

export class CreateBalingRecordDto {
  @IsUUID()
  batchId: string;

  @IsUUID()
  operatorId: string;

  @IsString()
  date: string;

  @IsInt()
  @Min(0)
  numberOfBales: number;

  @IsNumber()
  @Min(0)
  totalWeightKg: number;

  @IsOptional()
  @IsString()
  baleTagPrefix?: string;
}
