import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { BalingRecord } from './entities/baling-record.entity';
import { ApprovalStatus } from '../production/entities/production-record.entity';
import { BatchStage } from '../batches/entities/batch.entity';
import { Approval, ApprovableEntityType } from '../approvals/entities/approval.entity';
import { BatchesService } from '../batches/batches.service';
import { EmployeesService } from '../employees/employees.service';
import { WarehouseService } from '../warehouse/warehouse.service';
import { InventoryService } from '../inventory/inventory.service';
import { InventoryCategory } from '../inventory/entities/inventory-item.entity';
import { StockMovementType } from '../warehouse/entities/warehouse.entity';

@Injectable()
export class BalingService {
  constructor(
    @InjectRepository(BalingRecord)
    private readonly balingRepository: Repository<BalingRecord>,
    @InjectRepository(Approval)
    private readonly approvalsRepository: Repository<Approval>,
    private readonly batchesService: BatchesService,
    private readonly employeesService: EmployeesService,
    private readonly warehouseService: WarehouseService,
    private readonly inventoryService: InventoryService,
  ) {}

  async create(data: {
    batchId: string;
    operatorId: string;
    date: string;
    numberOfBales: number;
    totalWeightKg: number;
    baleTagPrefix?: string;
  }): Promise<BalingRecord> {
    const batch = await this.batchesService.findOne(data.batchId);
    const operator = await this.employeesService.findOne(data.operatorId);

    const record = this.balingRepository.create({
      batch,
      operator,
      date: data.date,
      numberOfBales: data.numberOfBales,
      totalWeightKg: data.totalWeightKg,
      baleTagPrefix: data.baleTagPrefix,
      status: ApprovalStatus.PENDING,
    });

    return this.balingRepository.save(record);
  }

  async findAll(): Promise<BalingRecord[]> {
    return this.balingRepository.find({
      relations: ['batch', 'operator', 'approvedBy'],
      order: { createdAt: 'DESC' },
    });
  }

  async findPending(): Promise<BalingRecord[]> {
    return this.balingRepository.find({
      where: { status: ApprovalStatus.PENDING },
      relations: ['batch', 'operator'],
      order: { createdAt: 'ASC' },
    });
  }

  async findOne(id: string): Promise<BalingRecord> {
    const record = await this.balingRepository.findOne({
      where: { id },
      relations: ['batch', 'operator', 'approvedBy'],
    });
    if (!record) {
      throw new NotFoundException('Baling record not found');
    }
    return record;
  }

  async review(
    id: string,
    data: { reviewerEmployeeId: string; decision: ApprovalStatus; comment?: string },
  ): Promise<BalingRecord> {
    if (data.decision === ApprovalStatus.PENDING) {
      throw new BadRequestException('Decision must be APPROVED or REJECTED');
    }

    const record = await this.findOne(id);
    if (record.status !== ApprovalStatus.PENDING) {
      throw new BadRequestException(`Record has already been ${record.status}`);
    }

    const reviewer = await this.employeesService.findOne(data.reviewerEmployeeId);

    record.status = data.decision;
    record.approvedBy = reviewer;
    record.approvedAt = new Date();
    const saved = await this.balingRepository.save(record);

    const approval = this.approvalsRepository.create({
      entityType: ApprovableEntityType.BALING,
      entityId: record.id,
      reviewedBy: reviewer,
      decision: data.decision,
      comment: data.comment,
    });
    await this.approvalsRepository.save(approval);

    // Baling is the last production stage before the warehouse - approving it
    // moves the batch straight to WAREHOUSE (finished, ready for stock/export),
    // AND credits real stock: the baled weight becomes finished-fibre inventory,
    // traceable back to this exact batch via the stock movement's reference.
    if (data.decision === ApprovalStatus.APPROVED) {
      await this.batchesService.updateStage(record.batch.id, BatchStage.WAREHOUSE);

      const warehouse = await this.warehouseService.findOrCreateWarehouse('Main Warehouse');
      const finishedFibreItem = await this.inventoryService.findOrCreate(
        'Finished Sisal Fibre',
        InventoryCategory.FINISHED_FIBRE,
        'kg',
      );

      await this.warehouseService.recordMovement({
        warehouse,
        item: finishedFibreItem,
        type: StockMovementType.IN,
        quantity: Number(record.totalWeightKg),
        reference: record.batch.batchNumber,
        recordedBy: reviewer,
      });
    }

    return saved;
  }
}
