import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Batch } from '../../batches/entities/batch.entity';
import { Employee } from '../../employees/entities/employee.entity';
import { ApprovalStatus } from '../../production/entities/production-record.entity';

@Entity('baling_records')
export class BalingRecord {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Batch)
  @JoinColumn()
  batch: Batch;

  @ManyToOne(() => Employee)
  @JoinColumn()
  operator: Employee;

  @Column({ type: 'date' })
  date: string;

  @Column({ default: 0 })
  numberOfBales: number;

  @Column('decimal', { precision: 10, scale: 2 })
  totalWeightKg: number;

  @Column({ nullable: true })
  baleTagPrefix: string; // links to physical bale tags for warehouse tracking

  @Column({ type: 'enum', enum: ApprovalStatus, default: ApprovalStatus.PENDING })
  status: ApprovalStatus;

  @ManyToOne(() => Employee, { nullable: true })
  @JoinColumn()
  approvedBy: Employee;

  @Column({ nullable: true })
  approvedAt: Date;

  @CreateDateColumn()
  createdAt: Date;
}
