import { Controller, Post, Get, Patch, Param, Body, UseGuards } from '@nestjs/common';
import { BalingService } from './baling.service';
import { CreateBalingRecordDto } from './dto/create-baling-record.dto';
import { ReviewBalingRecordDto } from './dto/review-baling-record.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '../users/entities/user.entity';

@Controller('baling')
@UseGuards(JwtAuthGuard, RolesGuard)
export class BalingController {
  constructor(private readonly balingService: BalingService) {}

  @Post()
  create(@Body() dto: CreateBalingRecordDto) {
    return this.balingService.create(dto);
  }

  @Get()
  findAll() {
    return this.balingService.findAll();
  }

  @Get('pending')
  findPending() {
    return this.balingService.findPending();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.balingService.findOne(id);
  }

  @Patch(':id/review')
  @Roles(UserRole.SUPERVISOR, UserRole.OPERATIONS_MANAGER, UserRole.CEO)
  review(@Param('id') id: string, @Body() dto: ReviewBalingRecordDto) {
    return this.balingService.review(id, dto);
  }
}
