import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BalingRecord } from './entities/baling-record.entity';
import { Approval } from '../approvals/entities/approval.entity';
import { BalingService } from './baling.service';
import { BalingController } from './baling.controller';
import { BatchesModule } from '../batches/batches.module';
import { EmployeesModule } from '../employees/employees.module';
import { WarehouseModule } from '../warehouse/warehouse.module';
import { InventoryModule } from '../inventory/inventory.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([BalingRecord, Approval]),
    BatchesModule,
    EmployeesModule,
    WarehouseModule,
    InventoryModule,
  ],
  controllers: [BalingController],
  providers: [BalingService],
  exports: [BalingService],
})
export class BalingModule {}
