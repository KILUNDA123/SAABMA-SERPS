import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Invoice, InvoiceItem, InvoiceStatus } from './entities/invoice.entity';
import { Payment } from '../payments/entities/payment.entity';
import { CustomersService } from '../customers/customers.service';
import { InventoryService } from '../inventory/inventory.service';
import { WarehouseService } from '../warehouse/warehouse.service';
import { StockMovementType } from '../warehouse/entities/warehouse.entity';
import { NotificationsService } from '../notifications/notifications.service';
import { NotificationType } from '../notifications/entities/notification.entity';
import { UserRole } from '../users/entities/user.entity';

@Injectable()
export class InvoicesService {
  constructor(
    @InjectRepository(Invoice)
    private readonly invoicesRepository: Repository<Invoice>,
    @InjectRepository(InvoiceItem)
    private readonly invoiceItemsRepository: Repository<InvoiceItem>,
    @InjectRepository(Payment)
    private readonly paymentsRepository: Repository<Payment>,
    private readonly customersService: CustomersService,
    private readonly inventoryService: InventoryService,
    private readonly warehouseService: WarehouseService,
    private readonly notificationsService: NotificationsService,
  ) {}

  private async generateInvoiceNumber(): Promise<string> {
    const now = new Date();
    const datePart = `${String(now.getFullYear()).slice(2)}${String(now.getMonth() + 1).padStart(2, '0')}`;
    const prefix = `INV${datePart}`;

    const countThisMonth = await this.invoicesRepository
      .createQueryBuilder('invoice')
      .where('invoice.invoiceNumber LIKE :prefix', { prefix: `${prefix}%` })
      .getCount();

    const sequence = String(countThisMonth + 1).padStart(4, '0');
    return `${prefix}${sequence}`;
  }

  async create(data: {
    customerId: string;
    invoiceDate: string;
    items: { inventoryItemId: string; description: string; quantity: number; unitPrice: number }[];
    discount?: number;
    taxRatePercent?: number;
  }): Promise<Invoice> {
    if (!data.items || data.items.length === 0) {
      throw new BadRequestException('An invoice must have at least one item');
    }

    const customer = await this.customersService.findOne(data.customerId);

    // Verify stock BEFORE committing anything - fail the whole invoice if
    // any single line doesn't have enough stock, rather than partially
    // deducting some items and leaving the invoice half-fulfilled.
    const stockChecks = await Promise.all(
      data.items.map(async (line) => {
        const item = await this.inventoryService.findOne(line.inventoryItemId);
        if (Number(item.currentStock) < line.quantity) {
          throw new BadRequestException(
            `Insufficient stock for "${item.name}": have ${item.currentStock}${item.unit}, invoice requests ${line.quantity}${item.unit}`,
          );
        }
        return item;
      }),
    );

    const subtotal = data.items.reduce((sum, line) => sum + line.quantity * line.unitPrice, 0);
    const discount = data.discount ?? 0;
    const taxableAmount = subtotal - discount;
    const tax = data.taxRatePercent ? (taxableAmount * data.taxRatePercent) / 100 : 0;
    const total = taxableAmount + tax;

    const invoiceNumber = await this.generateInvoiceNumber();

    const invoice = this.invoicesRepository.create({
      invoiceNumber,
      customer,
      invoiceDate: data.invoiceDate,
      subtotal,
      discount,
      tax,
      total,
      status: InvoiceStatus.SENT,
    });
    const savedInvoice = await this.invoicesRepository.save(invoice);

    // Create line items and deduct stock for each, referencing this invoice
    // number - same OUT-movement pattern baling used for its IN movement.
    const warehouse = await this.warehouseService.findOrCreateWarehouse('Main Warehouse');

    for (let i = 0; i < data.items.length; i++) {
      const line = data.items[i];
      const item = stockChecks[i];

      const invoiceItem = this.invoiceItemsRepository.create({
        invoice: savedInvoice,
        description: line.description,
        quantity: line.quantity,
        unitPrice: line.unitPrice,
        lineTotal: line.quantity * line.unitPrice,
      });
      await this.invoiceItemsRepository.save(invoiceItem);

      await this.warehouseService.recordMovement({
        warehouse,
        item,
        type: StockMovementType.OUT,
        quantity: line.quantity,
        reference: invoiceNumber,
      });
    }

    // Customer now owes this invoice's total.
    await this.customersService.adjustOutstandingBalance(customer.id, total);

    return this.findOne(savedInvoice.id);
  }

  async findAll(): Promise<Invoice[]> {
    return this.invoicesRepository.find({
      relations: ['customer', 'items'],
      order: { createdAt: 'DESC' },
    });
  }

  async findOne(id: string): Promise<Invoice> {
    const invoice = await this.invoicesRepository.findOne({
      where: { id },
      relations: ['customer', 'items'],
    });
    if (!invoice) {
      throw new NotFoundException('Invoice not found');
    }
    return invoice;
  }

  // Recording a payment reduces the customer's outstanding balance and, once
  // fully paid, flips the invoice to 'paid' - matching "Invoice Paid -> CEO
  // notified / Supervisor notified" from the original plan (notification
  // wiring itself is a later step; this method is where that event should
  // eventually be emitted from).
  async recordPayment(
    invoiceId: string,
    data: { amount: number; method: string; paidOn: string; reference?: string },
  ): Promise<{ invoice: Invoice; payment: Payment }> {
    const invoice = await this.findOne(invoiceId);

    const payment = this.paymentsRepository.create({
      invoice,
      customer: invoice.customer,
      amount: data.amount,
      method: data.method as any,
      paidOn: data.paidOn,
      reference: data.reference,
    });
    const savedPayment = await this.paymentsRepository.save(payment);

    await this.customersService.adjustOutstandingBalance(invoice.customer.id, -data.amount);

    // Sum all payments made against this invoice so far to decide if it's
    // now fully settled.
    const allPayments = await this.paymentsRepository.find({ where: { invoice: { id: invoiceId } } });
    const totalPaid = allPayments.reduce((sum, p) => sum + Number(p.amount), 0);

    if (totalPaid >= Number(invoice.total)) {
      invoice.status = InvoiceStatus.PAID;
      await this.invoicesRepository.save(invoice);

      // "Invoice Paid -> CEO notified, Supervisor notified" from the plan.
      // No single user IS "the CEO" or "the Supervisor", so we broadcast to
      // everyone currently holding those roles.
      const message = `Invoice ${invoice.invoiceNumber} (${invoice.total}) has been fully paid by ${invoice.customer.name}.`;
      await Promise.all([
        this.notificationsService.notifyRole(UserRole.CEO, NotificationType.INVOICE_PAID, message, `/invoices/${invoice.id}`),
        this.notificationsService.notifyRole(UserRole.FINANCE, NotificationType.INVOICE_PAID, message, `/invoices/${invoice.id}`),
      ]);
    }

    return { invoice: await this.findOne(invoiceId), payment: savedPayment };
  }
}
