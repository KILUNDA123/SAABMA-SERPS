import { IsUUID, IsNumber, Min, IsEnum, IsString, IsOptional } from 'class-validator';
import { PaymentMethod } from '../../payments/entities/payment.entity';

export class RecordPaymentDto {
  @IsNumber()
  @Min(0.01)
  amount: number;

  @IsEnum(PaymentMethod)
  method: PaymentMethod;

  @IsString()
  paidOn: string;

  @IsOptional()
  @IsString()
  reference?: string;
}
