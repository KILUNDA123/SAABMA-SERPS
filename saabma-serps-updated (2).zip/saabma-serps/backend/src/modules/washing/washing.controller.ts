import { Controller, Post, Get, Patch, Param, Body, UseGuards } from '@nestjs/common';
import { WashingService } from './washing.service';
import { CreateWashingRecordDto } from './dto/create-washing-record.dto';
import { ReviewWashingRecordDto } from './dto/review-washing-record.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '../users/entities/user.entity';

@Controller('washing')
@UseGuards(JwtAuthGuard, RolesGuard)
export class WashingController {
  constructor(private readonly washingService: WashingService) {}

  @Post()
  create(@Body() dto: CreateWashingRecordDto) {
    return this.washingService.create(dto);
  }

  @Get()
  findAll() {
    return this.washingService.findAll();
  }

  @Get('pending')
  findPending() {
    return this.washingService.findPending();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.washingService.findOne(id);
  }

  @Patch(':id/review')
  @Roles(UserRole.SUPERVISOR, UserRole.OPERATIONS_MANAGER, UserRole.CEO)
  review(@Param('id') id: string, @Body() dto: ReviewWashingRecordDto) {
    return this.washingService.review(id, dto);
  }
}
