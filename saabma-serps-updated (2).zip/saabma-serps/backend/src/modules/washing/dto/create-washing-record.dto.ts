import { IsUUID, IsString, IsOptional, IsNumber, Min } from 'class-validator';

export class CreateWashingRecordDto {
  @IsUUID()
  batchId: string;

  @IsUUID()
  operatorId: string;

  @IsString()
  date: string;

  @IsNumber()
  @Min(0)
  kg: number;

  @IsNumber()
  @Min(0)
  hydrogenUsedKg: number;

  @IsNumber()
  @Min(0)
  fee: number;

  @IsOptional()
  @IsString()
  remarks?: string;
}
