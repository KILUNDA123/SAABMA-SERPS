import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WashingRecord } from './entities/washing-record.entity';
import { Approval } from '../approvals/entities/approval.entity';
import { WashingService } from './washing.service';
import { WashingController } from './washing.controller';
import { BatchesModule } from '../batches/batches.module';
import { EmployeesModule } from '../employees/employees.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([WashingRecord, Approval]),
    BatchesModule,
    EmployeesModule,
  ],
  controllers: [WashingController],
  providers: [WashingService],
  exports: [WashingService],
})
export class WashingModule {}
