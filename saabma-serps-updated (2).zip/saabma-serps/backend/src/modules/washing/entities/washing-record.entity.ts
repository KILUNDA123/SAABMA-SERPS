import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Batch } from '../../batches/entities/batch.entity';
import { Employee } from '../../employees/entities/employee.entity';
import { ApprovalStatus } from '../../production/entities/production-record.entity';

@Entity('washing_records')
export class WashingRecord {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Batch)
  @JoinColumn()
  batch: Batch;

  @ManyToOne(() => Employee)
  @JoinColumn()
  operator: Employee;

  @Column({ type: 'date' })
  date: string;

  @Column('decimal', { precision: 10, scale: 2 })
  kg: number;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  hydrogenUsedKg: number;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  fee: number;

  @Column({ nullable: true })
  remarks: string;

  @Column({ type: 'enum', enum: ApprovalStatus, default: ApprovalStatus.PENDING })
  status: ApprovalStatus;

  @ManyToOne(() => Employee, { nullable: true })
  @JoinColumn()
  approvedBy: Employee;

  @Column({ nullable: true })
  approvedAt: Date;

  @CreateDateColumn()
  createdAt: Date;
}
