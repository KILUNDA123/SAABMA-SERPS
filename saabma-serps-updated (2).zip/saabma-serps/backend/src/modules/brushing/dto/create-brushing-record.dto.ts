import { IsUUID, IsString, IsOptional, IsInt, Min, IsNumber, IsArray } from 'class-validator';

export class CreateBrushingRecordDto {
  @IsUUID()
  batchId: string;

  @IsString()
  date: string;

  @IsString()
  machine: string;

  @IsInt()
  @Min(0)
  boxes: number;

  @IsNumber()
  @Min(0)
  weightKg: number;

  @IsUUID()
  operatorId: string;

  @IsArray()
  @IsUUID('4', { each: true })
  @IsOptional()
  helperIds?: string[];

  @IsUUID()
  @IsOptional()
  supervisorId?: string;

  @IsString()
  shift: string;
}
