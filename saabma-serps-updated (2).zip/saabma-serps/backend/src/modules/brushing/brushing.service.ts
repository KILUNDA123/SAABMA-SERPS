import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { BrushingRecord } from './entities/brushing-record.entity';
import { ApprovalStatus } from '../production/entities/production-record.entity';
import { BatchStage } from '../batches/entities/batch.entity';
import { Approval, ApprovableEntityType } from '../approvals/entities/approval.entity';
import { BatchesService } from '../batches/batches.service';
import { EmployeesService } from '../employees/employees.service';
import { Employee } from '../employees/entities/employee.entity';

@Injectable()
export class BrushingService {
  constructor(
    @InjectRepository(BrushingRecord)
    private readonly brushingRepository: Repository<BrushingRecord>,
    @InjectRepository(Employee)
    private readonly employeesRepository: Repository<Employee>,
    @InjectRepository(Approval)
    private readonly approvalsRepository: Repository<Approval>,
    private readonly batchesService: BatchesService,
    private readonly employeesService: EmployeesService,
  ) {}

  // Labour cost = operator's daily rate + sum of each helper's daily rate.
  // This replaces manual "2 x 700 + 8 x 500" style calculator math from the
  // original paper process - the system does it from each employee's own rate.
  private calculateLabourCost(operator: Employee, helpers: Employee[]): number {
    const operatorRate = Number(operator.dailyRate);
    const helpersTotal = helpers.reduce((sum, h) => sum + Number(h.dailyRate), 0);
    return operatorRate + helpersTotal;
  }

  async create(data: {
    batchId: string;
    date: string;
    machine: string;
    boxes: number;
    weightKg: number;
    operatorId: string;
    helperIds?: string[];
    supervisorId?: string;
    shift: string;
  }): Promise<BrushingRecord> {
    const batch = await this.batchesService.findOne(data.batchId);
    const operator = await this.employeesService.findOne(data.operatorId);

    let helpers: Employee[] = [];
    if (data.helperIds && data.helperIds.length > 0) {
      helpers = await this.employeesRepository.find({ where: { id: In(data.helperIds) } });
      if (helpers.length !== data.helperIds.length) {
        throw new BadRequestException('One or more helper IDs were not found');
      }
    }

    let supervisor: Employee | undefined;
    if (data.supervisorId) {
      supervisor = await this.employeesService.findOne(data.supervisorId);
    }

    const labourCost = this.calculateLabourCost(operator, helpers);

    const record = this.brushingRepository.create({
      batch,
      date: data.date,
      machine: data.machine,
      boxes: data.boxes,
      weightKg: data.weightKg,
      operator,
      helpers,
      supervisor,
      shift: data.shift,
      labourCost,
      status: ApprovalStatus.PENDING,
    });

    return this.brushingRepository.save(record);
  }

  async findAll(): Promise<BrushingRecord[]> {
    return this.brushingRepository.find({
      relations: ['batch', 'operator', 'helpers', 'supervisor'],
      order: { createdAt: 'DESC' },
    });
  }

  async findPending(): Promise<BrushingRecord[]> {
    return this.brushingRepository.find({
      where: { status: ApprovalStatus.PENDING },
      relations: ['batch', 'operator', 'helpers'],
      order: { createdAt: 'ASC' },
    });
  }

  async findOne(id: string): Promise<BrushingRecord> {
    const record = await this.brushingRepository.findOne({
      where: { id },
      relations: ['batch', 'operator', 'helpers', 'supervisor'],
    });
    if (!record) {
      throw new NotFoundException('Brushing record not found');
    }
    return record;
  }

  async review(
    id: string,
    data: { reviewerEmployeeId: string; decision: ApprovalStatus; comment?: string },
  ): Promise<BrushingRecord> {
    if (data.decision === ApprovalStatus.PENDING) {
      throw new BadRequestException('Decision must be APPROVED or REJECTED');
    }

    const record = await this.findOne(id);
    if (record.status !== ApprovalStatus.PENDING) {
      throw new BadRequestException(`Record has already been ${record.status}`);
    }

    const reviewer = await this.employeesService.findOne(data.reviewerEmployeeId);

    record.status = data.decision;
    record.supervisor = reviewer;
    record.approvedAt = new Date();
    const saved = await this.brushingRepository.save(record);

    const approval = this.approvalsRepository.create({
      entityType: ApprovableEntityType.BRUSHING,
      entityId: record.id,
      reviewedBy: reviewer,
      decision: data.decision,
      comment: data.comment,
    });
    await this.approvalsRepository.save(approval);

    if (data.decision === ApprovalStatus.APPROVED) {
      await this.batchesService.updateStage(record.batch.id, BatchStage.BRUSHING);
    }

    return saved;
  }
}
