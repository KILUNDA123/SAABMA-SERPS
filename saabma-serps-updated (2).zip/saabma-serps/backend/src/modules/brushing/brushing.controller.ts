import { Controller, Post, Get, Patch, Param, Body, UseGuards } from '@nestjs/common';
import { BrushingService } from './brushing.service';
import { CreateBrushingRecordDto } from './dto/create-brushing-record.dto';
import { ReviewBrushingRecordDto } from './dto/review-brushing-record.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '../users/entities/user.entity';

@Controller('brushing')
@UseGuards(JwtAuthGuard, RolesGuard)
export class BrushingController {
  constructor(private readonly brushingService: BrushingService) {}

  @Post()
  create(@Body() dto: CreateBrushingRecordDto) {
    return this.brushingService.create(dto);
  }

  @Get()
  findAll() {
    return this.brushingService.findAll();
  }

  @Get('pending')
  findPending() {
    return this.brushingService.findPending();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.brushingService.findOne(id);
  }

  @Patch(':id/review')
  @Roles(UserRole.SUPERVISOR, UserRole.OPERATIONS_MANAGER, UserRole.CEO)
  review(@Param('id') id: string, @Body() dto: ReviewBrushingRecordDto) {
    return this.brushingService.review(id, dto);
  }
}
