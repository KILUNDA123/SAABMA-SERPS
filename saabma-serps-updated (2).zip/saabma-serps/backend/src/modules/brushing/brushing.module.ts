import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BrushingRecord } from './entities/brushing-record.entity';
import { Employee } from '../employees/entities/employee.entity';
import { Approval } from '../approvals/entities/approval.entity';
import { BrushingService } from './brushing.service';
import { BrushingController } from './brushing.controller';
import { BatchesModule } from '../batches/batches.module';
import { EmployeesModule } from '../employees/employees.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([BrushingRecord, Employee, Approval]),
    BatchesModule,
    EmployeesModule,
  ],
  controllers: [BrushingController],
  providers: [BrushingService],
  exports: [BrushingService],
})
export class BrushingModule {}
