import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn, ManyToMany, JoinTable } from 'typeorm';
import { Batch } from '../../batches/entities/batch.entity';
import { Employee } from '../../employees/entities/employee.entity';
import { ApprovalStatus } from '../../production/entities/production-record.entity';

@Entity('brushing_records')
export class BrushingRecord {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Batch)
  @JoinColumn()
  batch: Batch;

  @Column({ type: 'date' })
  date: string;

  @Column()
  machine: string;

  @Column({ default: 0 })
  boxes: number;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  weightKg: number;

  @ManyToOne(() => Employee)
  @JoinColumn()
  operator: Employee;

  @ManyToMany(() => Employee)
  @JoinTable()
  helpers: Employee[];

  @ManyToOne(() => Employee, { nullable: true })
  @JoinColumn()
  supervisor: Employee;

  @Column()
  shift: string;

  // Calculated in service layer from operator/helper daily rates - stored for audit/history
  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  labourCost: number;

  @Column({ type: 'enum', enum: ApprovalStatus, default: ApprovalStatus.PENDING })
  status: ApprovalStatus;

  @Column({ nullable: true })
  approvedAt: Date;

  @CreateDateColumn()
  createdAt: Date;
}
