import { Controller, Post, Get, Param, Body, UseGuards } from '@nestjs/common';
import { WarehouseService } from './warehouse.service';
import { CreateWarehouseDto } from './dto/create-warehouse.dto';
import { WarehouseTransactionDto } from './dto/warehouse-transaction.dto';
import { WarehouseTransferDto } from './dto/warehouse-transfer.dto';
import { WarehouseAdjustmentDto } from './dto/warehouse-adjustment.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../permissions/permissions.guard';
import { RequirePermission } from '../permissions/require-permission.decorator';
import { PERMISSIONS } from '../permissions/permissions.constants';

@Controller('warehouses')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class WarehouseController {
  constructor(private readonly warehouseService: WarehouseService) {}

  @Post()
  @RequirePermission(PERMISSIONS.WAREHOUSE_MANAGE)
  create(@Body() dto: CreateWarehouseDto) {
    return this.warehouseService.createWarehouse(dto);
  }

  @Get()
  @RequirePermission(PERMISSIONS.WAREHOUSE_VIEW)
  findAll() {
    return this.warehouseService.findAllWarehouses();
  }

  @Post('receive')
  @RequirePermission(PERMISSIONS.WAREHOUSE_MANAGE)
  receive(@Body() dto: WarehouseTransactionDto) {
    return this.warehouseService.receiveStock(dto);
  }

  @Post('inspect')
  @RequirePermission(PERMISSIONS.WAREHOUSE_MANAGE)
  inspect(@Body() dto: WarehouseTransactionDto) {
    return this.warehouseService.inspectStock(dto);
  }

  @Post('store')
  @RequirePermission(PERMISSIONS.WAREHOUSE_MANAGE)
  store(@Body() dto: WarehouseTransactionDto) {
    return this.warehouseService.storeStock(dto);
  }

  @Post('pick')
  @RequirePermission(PERMISSIONS.WAREHOUSE_MANAGE)
  pick(@Body() dto: WarehouseTransactionDto) {
    return this.warehouseService.pickStock(dto);
  }

  @Post('dispatch')
  @RequirePermission(PERMISSIONS.WAREHOUSE_MANAGE)
  dispatch(@Body() dto: WarehouseTransactionDto) {
    return this.warehouseService.dispatchStock(dto);
  }

  @Post('deliver')
  @RequirePermission(PERMISSIONS.WAREHOUSE_MANAGE)
  deliver(@Body() dto: WarehouseTransactionDto) {
    return this.warehouseService.deliverStock(dto);
  }

  @Post('transfer')
  @RequirePermission(PERMISSIONS.WAREHOUSE_MANAGE)
  transfer(@Body() dto: WarehouseTransferDto) {
    return this.warehouseService.transferStock(dto);
  }

  @Post('adjust')
  @RequirePermission(PERMISSIONS.WAREHOUSE_MANAGE)
  adjust(@Body() dto: WarehouseAdjustmentDto) {
    return this.warehouseService.adjustStockLevel(dto);
  }

  @Get('movements/:itemId')
  @RequirePermission(PERMISSIONS.WAREHOUSE_VIEW)
  findMovementsForItem(@Param('itemId') itemId: string) {
    return this.warehouseService.findMovementsForItem(itemId);
  }
}
