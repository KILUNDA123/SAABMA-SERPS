import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, CreateDateColumn } from 'typeorm';
import { InventoryItem } from '../../inventory/entities/inventory-item.entity';
import { Employee } from '../../employees/entities/employee.entity';

@Entity('warehouses')
export class Warehouse {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  name: string;

  @Column({ nullable: true })
  location: string;
}

export enum StockMovementType {
  IN = 'in',
  OUT = 'out',
  ADJUSTMENT = 'adjustment',
}

// Every change to InventoryItem.currentStock should be written here first,
// then applied to the item - gives a full audit trail of stock movement
// (e.g. baled fibre entering warehouse, or stock leaving for a shipment).
@Entity('stock_movements')
export class StockMovement {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Warehouse)
  @JoinColumn()
  warehouse: Warehouse;

  @ManyToOne(() => InventoryItem)
  @JoinColumn()
  item: InventoryItem;

  @Column({ type: 'enum', enum: StockMovementType })
  type: StockMovementType;

  @Column('decimal', { precision: 12, scale: 2 })
  quantity: number;

  @Column({ nullable: true })
  reference: string; // e.g. batch number, invoice number, purchase number

  @ManyToOne(() => Employee, { nullable: true })
  @JoinColumn()
  recordedBy: Employee;

  @CreateDateColumn()
  createdAt: Date;
}
