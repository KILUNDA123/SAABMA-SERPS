import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Warehouse, StockMovement, StockMovementType } from './entities/warehouse.entity';
import { InventoryItem } from '../inventory/entities/inventory-item.entity';
import { Employee } from '../employees/entities/employee.entity';
import { InventoryService } from '../inventory/inventory.service';
import { NotificationsService } from '../notifications/notifications.service';
import { NotificationType } from '../notifications/entities/notification.entity';
import { UserRole } from '../users/entities/user.entity';
import { WarehouseTransactionDto } from './dto/warehouse-transaction.dto';
import { WarehouseTransferDto } from './dto/warehouse-transfer.dto';
import { WarehouseAdjustmentDto } from './dto/warehouse-adjustment.dto';

@Injectable()
export class WarehouseService {
  constructor(
    @InjectRepository(Warehouse)
    private readonly warehousesRepository: Repository<Warehouse>,
    @InjectRepository(StockMovement)
    private readonly stockMovementsRepository: Repository<StockMovement>,
    private readonly inventoryService: InventoryService,
    private readonly notificationsService: NotificationsService,
  ) {}

  async createWarehouse(data: { name: string; location?: string }): Promise<Warehouse> {
    const warehouse = this.warehousesRepository.create(data);
    return this.warehousesRepository.save(warehouse);
  }

  async findAllWarehouses(): Promise<Warehouse[]> {
    return this.warehousesRepository.find({ order: { name: 'ASC' } });
  }

  async findWarehouseByName(name: string): Promise<Warehouse> {
    const warehouse = await this.warehousesRepository.findOne({ where: { name } });
    if (!warehouse) {
      throw new NotFoundException(`Warehouse "${name}" not found`);
    }
    return warehouse;
  }

  // Finds a warehouse by name, or creates it if it doesn't exist - mirrors
  // InventoryService.findOrCreate so upstream modules (e.g. baling) don't
  // need someone to have manually set up a default warehouse first.
  async findOrCreateWarehouse(name: string, location?: string): Promise<Warehouse> {
    let warehouse = await this.warehousesRepository.findOne({ where: { name } });
    if (!warehouse) {
      warehouse = await this.createWarehouse({ name, location });
    }
    return warehouse;
  }

  // The single place stock actually changes: writes a StockMovement row
  // (the permanent, traceable record - "what changed, why, by whom") AND
  // updates InventoryItem.currentStock to match. Every stock change in the
  // system should go through here, not InventoryService.adjustStock directly.
  async recordMovement(data: {
    warehouse: Warehouse;
    item: InventoryItem;
    type: StockMovementType;
    quantity: number;
    reference?: string;
    recordedBy?: Employee;
  }): Promise<StockMovement> {
    const delta = data.type === StockMovementType.OUT ? -Math.abs(data.quantity) : Math.abs(data.quantity);

    const updatedItem = await this.inventoryService.adjustStock(data.item.id, delta);

    const movement = this.stockMovementsRepository.create({
      warehouse: data.warehouse,
      item: data.item,
      type: data.type,
      quantity: data.quantity,
      reference: data.reference,
      recordedBy: data.recordedBy,
    });

    const saved = await this.stockMovementsRepository.save(movement);

    // "Low Hydrogen -> Store notified" from the plan, generalized to any
    // tracked item. reorderLevel of 0 means reorder tracking is off for
    // this item (matches InventoryService.findLowStock's own convention),
    // so we only fire when someone has actually configured a threshold.
    if (Number(updatedItem.reorderLevel) > 0 && Number(updatedItem.currentStock) <= Number(updatedItem.reorderLevel)) {
      await this.notificationsService.notifyRole(
        UserRole.WAREHOUSE,
        NotificationType.LOW_STOCK,
        `${updatedItem.name} is low: ${updatedItem.currentStock}${updatedItem.unit} remaining (reorder level: ${updatedItem.reorderLevel}${updatedItem.unit}).`,
        `/inventory/${updatedItem.id}`,
      );
    }

    return saved;
  }

  private async resolveWarehouse(warehouseId?: string): Promise<Warehouse> {
    if (warehouseId) {
      const warehouse = await this.warehousesRepository.findOne({ where: { id: warehouseId } });
      if (!warehouse) {
        throw new NotFoundException(`Warehouse with id "${warehouseId}" not found`);
      }
      return warehouse;
    }

    return this.findOrCreateWarehouse('Main Warehouse', 'Head Office');
  }

  async inspectStock(dto: WarehouseTransactionDto): Promise<{ stage: string; warehouse: string; item: string; currentStock: number }> {
    const warehouse = await this.resolveWarehouse(dto.warehouseId);
    const item = await this.inventoryService.findOne(dto.itemId);

    return {
      stage: 'inspection',
      warehouse: warehouse.name,
      item: item.name,
      currentStock: Number(item.currentStock || 0),
    };
  }

  async transferStock(dto: WarehouseTransferDto): Promise<{ stage: string; fromWarehouse: string; toWarehouse: string; movement: StockMovement[] }> {
    const item = await this.inventoryService.findOne(dto.itemId);
    const fromWarehouse = await this.warehousesRepository.findOne({ where: { id: dto.fromWarehouseId } });
    const toWarehouse = await this.warehousesRepository.findOne({ where: { id: dto.toWarehouseId } });

    if (!fromWarehouse || !toWarehouse) {
      throw new NotFoundException('Transfer warehouse not found');
    }

    if (fromWarehouse.id === toWarehouse.id) {
      throw new Error('Transfer source and destination warehouses must be different');
    }

    const outMovement = await this.recordMovement({
      warehouse: fromWarehouse,
      item,
      type: StockMovementType.OUT,
      quantity: dto.quantity,
      reference: dto.reference,
    });

    const inMovement = await this.recordMovement({
      warehouse: toWarehouse,
      item,
      type: StockMovementType.IN,
      quantity: dto.quantity,
      reference: dto.reference,
    });

    return {
      stage: 'transfer',
      fromWarehouse: fromWarehouse.name,
      toWarehouse: toWarehouse.name,
      movement: [outMovement, inMovement],
    };
  }

  async adjustStockLevel(dto: WarehouseAdjustmentDto): Promise<{ stage: string; movement: StockMovement }> {
    const warehouse = await this.findOrCreateWarehouse('Main Warehouse', 'Head Office');
    const item = await this.inventoryService.findOne(dto.itemId);

    const movement = await this.recordMovement({
      warehouse,
      item,
      type: StockMovementType.ADJUSTMENT,
      quantity: dto.quantity,
      reference: dto.reference ?? dto.reason,
    });

    return { stage: 'adjustment', movement };
  }

  async receiveStock(dto: WarehouseTransactionDto): Promise<{ stage: string; movement: StockMovement }> {
    const movement = await this.recordMovement({
      warehouse: await this.resolveWarehouse(dto.warehouseId),
      item: await this.inventoryService.findOne(dto.itemId),
      type: StockMovementType.IN,
      quantity: dto.quantity,
      reference: dto.reference,
    });

    return { stage: 'receiving', movement };
  }

  async storeStock(dto: WarehouseTransactionDto): Promise<{ stage: string; movement: StockMovement }> {
    const movement = await this.recordMovement({
      warehouse: await this.resolveWarehouse(dto.warehouseId),
      item: await this.inventoryService.findOne(dto.itemId),
      type: StockMovementType.IN,
      quantity: dto.quantity,
      reference: dto.reference,
    });

    return { stage: 'storage', movement };
  }

  async pickStock(dto: WarehouseTransactionDto): Promise<{ stage: string; movement: StockMovement }> {
    const movement = await this.recordMovement({
      warehouse: await this.resolveWarehouse(dto.warehouseId),
      item: await this.inventoryService.findOne(dto.itemId),
      type: StockMovementType.OUT,
      quantity: dto.quantity,
      reference: dto.reference,
    });

    return { stage: 'picking', movement };
  }

  async dispatchStock(dto: WarehouseTransactionDto): Promise<{ stage: string; movement: StockMovement }> {
    const movement = await this.recordMovement({
      warehouse: await this.resolveWarehouse(dto.warehouseId),
      item: await this.inventoryService.findOne(dto.itemId),
      type: StockMovementType.OUT,
      quantity: dto.quantity,
      reference: dto.reference,
    });

    return { stage: 'dispatch', movement };
  }

  async deliverStock(dto: WarehouseTransactionDto): Promise<{ stage: string; movement: StockMovement }> {
    const movement = await this.recordMovement({
      warehouse: await this.resolveWarehouse(dto.warehouseId),
      item: await this.inventoryService.findOne(dto.itemId),
      type: StockMovementType.OUT,
      quantity: dto.quantity,
      reference: dto.reference,
    });

    return { stage: 'delivery', movement };
  }

  async findMovementsForItem(itemId: string): Promise<StockMovement[]> {
    return this.stockMovementsRepository.find({
      where: { item: { id: itemId } },
      relations: ['warehouse', 'item', 'recordedBy'],
      order: { createdAt: 'DESC' },
    });
  }
}
