import { IsString, IsNumber, Min } from 'class-validator';

export class WarehouseTransferDto {
  @IsString()
  itemId: string;

  @IsString()
  fromWarehouseId: string;

  @IsString()
  toWarehouseId: string;

  @IsNumber()
  @Min(0)
  quantity: number;

  @IsString()
  reference: string;
}
