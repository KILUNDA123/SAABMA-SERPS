import { IsEnum, IsOptional, IsString, IsNumber, Min } from 'class-validator';
import { StockMovementType } from '../entities/warehouse.entity';

export class WarehouseTransactionDto {
  @IsString()
  itemId: string;

  @IsEnum(StockMovementType)
  type: StockMovementType;

  @IsNumber()
  @Min(0)
  quantity: number;

  @IsOptional()
  @IsString()
  reference?: string;

  @IsOptional()
  @IsString()
  warehouseId?: string;
}
