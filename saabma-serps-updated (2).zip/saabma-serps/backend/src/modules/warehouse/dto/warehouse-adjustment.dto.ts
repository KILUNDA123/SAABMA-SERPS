import { IsString, IsNumber, Min, IsOptional } from 'class-validator';

export class WarehouseAdjustmentDto {
  @IsString()
  itemId: string;

  @IsNumber()
  @Min(0)
  quantity: number;

  @IsOptional()
  @IsString()
  reason?: string;

  @IsOptional()
  @IsString()
  reference?: string;
}
