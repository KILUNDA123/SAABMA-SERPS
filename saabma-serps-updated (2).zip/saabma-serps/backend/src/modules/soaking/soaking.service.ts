import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { SoakingRecord } from './entities/soaking-record.entity';
import { ApprovalStatus } from '../production/entities/production-record.entity';
import { BatchStage } from '../batches/entities/batch.entity';
import { Approval, ApprovableEntityType } from '../approvals/entities/approval.entity';
import { BatchesService } from '../batches/batches.service';
import { EmployeesService } from '../employees/employees.service';

@Injectable()
export class SoakingService {
  constructor(
    @InjectRepository(SoakingRecord)
    private readonly soakingRepository: Repository<SoakingRecord>,
    @InjectRepository(Approval)
    private readonly approvalsRepository: Repository<Approval>,
    private readonly batchesService: BatchesService,
    private readonly employeesService: EmployeesService,
  ) {}

  async create(data: {
    batchId: string;
    operatorId: string;
    date: string;
    kg: number;
    soakingDurationHours?: number;
    remarks?: string;
  }): Promise<SoakingRecord> {
    const batch = await this.batchesService.findOne(data.batchId);
    const operator = await this.employeesService.findOne(data.operatorId);

    const record = this.soakingRepository.create({
      batch,
      operator,
      date: data.date,
      kg: data.kg,
      soakingDurationHours: data.soakingDurationHours,
      remarks: data.remarks,
      status: ApprovalStatus.PENDING,
    });

    return this.soakingRepository.save(record);
  }

  async findAll(): Promise<SoakingRecord[]> {
    return this.soakingRepository.find({
      relations: ['batch', 'operator', 'approvedBy'],
      order: { createdAt: 'DESC' },
    });
  }

  async findPending(): Promise<SoakingRecord[]> {
    return this.soakingRepository.find({
      where: { status: ApprovalStatus.PENDING },
      relations: ['batch', 'operator'],
      order: { createdAt: 'ASC' },
    });
  }

  async findOne(id: string): Promise<SoakingRecord> {
    const record = await this.soakingRepository.findOne({
      where: { id },
      relations: ['batch', 'operator', 'approvedBy'],
    });
    if (!record) {
      throw new NotFoundException('Soaking record not found');
    }
    return record;
  }

  async review(
    id: string,
    data: { reviewerEmployeeId: string; decision: ApprovalStatus; comment?: string },
  ): Promise<SoakingRecord> {
    if (data.decision === ApprovalStatus.PENDING) {
      throw new BadRequestException('Decision must be APPROVED or REJECTED');
    }

    const record = await this.findOne(id);
    if (record.status !== ApprovalStatus.PENDING) {
      throw new BadRequestException(`Record has already been ${record.status}`);
    }

    const reviewer = await this.employeesService.findOne(data.reviewerEmployeeId);

    record.status = data.decision;
    record.approvedBy = reviewer;
    record.approvedAt = new Date();
    const saved = await this.soakingRepository.save(record);

    const approval = this.approvalsRepository.create({
      entityType: ApprovableEntityType.SOAKING,
      entityId: record.id,
      reviewedBy: reviewer,
      decision: data.decision,
      comment: data.comment,
    });
    await this.approvalsRepository.save(approval);

    // Approving a soaking record moves the batch into the soaking stage -
    // batch.currentStage always reflects the latest APPROVED processing step.
    if (data.decision === ApprovalStatus.APPROVED) {
      await this.batchesService.updateStage(record.batch.id, BatchStage.SOAKING);
    }

    return saved;
  }
}
