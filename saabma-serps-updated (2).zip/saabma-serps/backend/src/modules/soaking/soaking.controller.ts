import { Controller, Post, Get, Patch, Param, Body, UseGuards } from '@nestjs/common';
import { SoakingService } from './soaking.service';
import { CreateSoakingRecordDto } from './dto/create-soaking-record.dto';
import { ReviewSoakingRecordDto } from './dto/review-soaking-record.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '../users/entities/user.entity';

@Controller('soaking')
@UseGuards(JwtAuthGuard, RolesGuard)
export class SoakingController {
  constructor(private readonly soakingService: SoakingService) {}

  @Post()
  create(@Body() dto: CreateSoakingRecordDto) {
    return this.soakingService.create(dto);
  }

  @Get()
  findAll() {
    return this.soakingService.findAll();
  }

  @Get('pending')
  findPending() {
    return this.soakingService.findPending();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.soakingService.findOne(id);
  }

  @Patch(':id/review')
  @Roles(UserRole.SUPERVISOR, UserRole.OPERATIONS_MANAGER, UserRole.CEO)
  review(@Param('id') id: string, @Body() dto: ReviewSoakingRecordDto) {
    return this.soakingService.review(id, dto);
  }
}
