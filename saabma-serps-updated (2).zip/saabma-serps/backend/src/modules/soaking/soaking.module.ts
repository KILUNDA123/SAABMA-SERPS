import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SoakingRecord } from './entities/soaking-record.entity';
import { Approval } from '../approvals/entities/approval.entity';
import { SoakingService } from './soaking.service';
import { SoakingController } from './soaking.controller';
import { BatchesModule } from '../batches/batches.module';
import { EmployeesModule } from '../employees/employees.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([SoakingRecord, Approval]),
    BatchesModule,
    EmployeesModule,
  ],
  controllers: [SoakingController],
  providers: [SoakingService],
  exports: [SoakingService],
})
export class SoakingModule {}
