import { IsEnum, IsOptional, IsString, IsUUID } from 'class-validator';
import { ApprovalStatus } from '../../production/entities/production-record.entity';

export class ReviewSoakingRecordDto {
  @IsUUID()
  reviewerEmployeeId: string;

  @IsEnum(ApprovalStatus)
  decision: ApprovalStatus;

  @IsOptional()
  @IsString()
  comment?: string;
}
