import { IsUUID, IsString, IsOptional, IsNumber, Min } from 'class-validator';

export class CreateSoakingRecordDto {
  @IsUUID()
  batchId: string;

  @IsUUID()
  operatorId: string;

  @IsString()
  date: string;

  @IsNumber()
  @Min(0)
  kg: number;

  @IsOptional()
  @IsNumber()
  @Min(0)
  soakingDurationHours?: number;

  @IsOptional()
  @IsString()
  remarks?: string;
}
