import { IsNumber, Min } from 'class-validator';

export class UpdateReorderLevelDto {
  @IsNumber()
  @Min(0)
  reorderLevel: number;
}
