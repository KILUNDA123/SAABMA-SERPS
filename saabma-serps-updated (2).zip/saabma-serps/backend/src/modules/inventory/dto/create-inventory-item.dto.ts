import { IsEnum, IsString, IsNumber, Min, IsOptional } from 'class-validator';
import { InventoryCategory } from '../entities/inventory-item.entity';

export class CreateInventoryItemDto {
  @IsString()
  name: string;

  @IsEnum(InventoryCategory)
  category: InventoryCategory;

  @IsString()
  unit: string;

  @IsOptional()
  @IsNumber()
  @Min(0)
  currentStock?: number;

  @IsOptional()
  @IsNumber()
  @Min(0)
  reorderLevel?: number;
}
