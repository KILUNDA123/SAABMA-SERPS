import { Entity, PrimaryGeneratedColumn, Column, UpdateDateColumn } from 'typeorm';

export enum InventoryCategory {
  RAW_SISAL = 'raw_sisal',
  SEMI_PROCESSED = 'semi_processed',
  FINISHED_FIBRE = 'finished_fibre',
  CHEMICAL = 'chemical',
  PACKAGING = 'packaging',
}

@Entity('inventory_items')
export class InventoryItem {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column({ type: 'enum', enum: InventoryCategory })
  category: InventoryCategory;

  @Column()
  unit: string; // kg, litres, pieces, bales

  @Column('decimal', { precision: 12, scale: 2, default: 0 })
  currentStock: number;

  @Column('decimal', { precision: 12, scale: 2, default: 0 })
  reorderLevel: number;

  @UpdateDateColumn()
  updatedAt: Date;
}
