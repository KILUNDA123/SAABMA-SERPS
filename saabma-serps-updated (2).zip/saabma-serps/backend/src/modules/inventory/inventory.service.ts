import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { InventoryItem, InventoryCategory } from './entities/inventory-item.entity';

@Injectable()
export class InventoryService {
  constructor(
    @InjectRepository(InventoryItem)
    private readonly inventoryRepository: Repository<InventoryItem>,
  ) {}

  async create(data: {
    name: string;
    category: InventoryCategory;
    unit: string;
    currentStock?: number;
    reorderLevel?: number;
  }): Promise<InventoryItem> {
    const item = this.inventoryRepository.create({
      name: data.name,
      category: data.category,
      unit: data.unit,
      currentStock: data.currentStock ?? 0,
      reorderLevel: data.reorderLevel ?? 0,
    });
    return this.inventoryRepository.save(item);
  }

  async findAll(): Promise<InventoryItem[]> {
    return this.inventoryRepository.find({ order: { name: 'ASC' } });
  }

  async findLowStock(): Promise<InventoryItem[]> {
    // reorderLevel of 0 means "no reorder tracking configured" - skip those
    return this.inventoryRepository
      .createQueryBuilder('item')
      .where('item.reorderLevel > 0')
      .andWhere('item.currentStock <= item.reorderLevel')
      .getMany();
  }

  async findOne(id: string): Promise<InventoryItem> {
    const item = await this.inventoryRepository.findOne({ where: { id } });
    if (!item) {
      throw new NotFoundException('Inventory item not found');
    }
    return item;
  }

  // Finds an item by name+category, or creates it with zero stock if it
  // doesn't exist yet. Used by upstream modules (e.g. baling) that need to
  // credit stock without requiring someone to have pre-created the item.
  async findOrCreate(name: string, category: InventoryCategory, unit: string): Promise<InventoryItem> {
    let item = await this.inventoryRepository.findOne({ where: { name, category } });
    if (!item) {
      item = await this.create({ name, category, unit });
    }
    return item;
  }

  async updateReorderLevel(id: string, reorderLevel: number): Promise<InventoryItem> {
    const item = await this.findOne(id);
    item.reorderLevel = reorderLevel;
    return this.inventoryRepository.save(item);
  }

  // Directly mutates currentStock. Callers that need traceability (a
  // reference to what caused the change) should go through
  // WarehouseService.recordMovement instead, which calls this AND writes
  // a stock_movements row.
  async adjustStock(id: string, delta: number): Promise<InventoryItem> {
    const item = await this.findOne(id);
    const newStock = Number(item.currentStock) + delta;
    if (newStock < 0) {
      throw new BadRequestException('Adjustment would result in negative stock');
    }
    item.currentStock = newStock;
    return this.inventoryRepository.save(item);
  }
}
