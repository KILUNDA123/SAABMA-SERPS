import { Controller, Post, Get, Patch, Param, Body, UseGuards } from '@nestjs/common';
import { InventoryService } from './inventory.service';
import { CreateInventoryItemDto } from './dto/create-inventory-item.dto';
import { UpdateReorderLevelDto } from './dto/update-reorder-level.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../permissions/permissions.guard';
import { RequirePermission } from '../permissions/require-permission.decorator';
import { PERMISSIONS } from '../permissions/permissions.constants';

@Controller('inventory')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class InventoryController {
  constructor(private readonly inventoryService: InventoryService) {}

  @Post()
  @RequirePermission(PERMISSIONS.WAREHOUSE_MANAGE)
  create(@Body() dto: CreateInventoryItemDto) {
    return this.inventoryService.create(dto);
  }

  @Get()
  @RequirePermission(PERMISSIONS.WAREHOUSE_VIEW)
  findAll() {
    return this.inventoryService.findAll();
  }

  @Get('low-stock')
  @RequirePermission(PERMISSIONS.WAREHOUSE_VIEW)
  findLowStock() {
    return this.inventoryService.findLowStock();
  }

  @Get(':id')
  @RequirePermission(PERMISSIONS.WAREHOUSE_VIEW)
  findOne(@Param('id') id: string) {
    return this.inventoryService.findOne(id);
  }

  @Patch(':id/reorder-level')
  @RequirePermission(PERMISSIONS.WAREHOUSE_MANAGE)
  updateReorderLevel(@Param('id') id: string, @Body() dto: UpdateReorderLevelDto) {
    return this.inventoryService.updateReorderLevel(id, dto.reorderLevel);
  }
}
