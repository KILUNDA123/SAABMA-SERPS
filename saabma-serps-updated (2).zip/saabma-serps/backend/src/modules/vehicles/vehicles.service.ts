import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Driver, Vehicle } from './entities/vehicle.entity';
import { UsersService } from '../users/users.service';

@Injectable()
export class VehiclesService {
  constructor(
    @InjectRepository(Driver)
    private readonly driversRepository: Repository<Driver>,
    @InjectRepository(Vehicle)
    private readonly vehiclesRepository: Repository<Vehicle>,
    private readonly usersService: UsersService,
  ) {}

  async createDriver(data: { fullName: string; licenseNumber?: string; phone?: string; userId?: string }): Promise<Driver> {
    let user;
    if (data.userId) {
      user = await this.usersService.findById(data.userId);
    }
    const driver = this.driversRepository.create({
      fullName: data.fullName,
      licenseNumber: data.licenseNumber,
      phone: data.phone,
      user,
    });
    return this.driversRepository.save(driver);
  }

  async findAllDrivers(): Promise<Driver[]> {
    return this.driversRepository.find({ order: { fullName: 'ASC' } });
  }

  async findDriver(id: string): Promise<Driver> {
    const driver = await this.driversRepository.findOne({ where: { id }, relations: ['user'] });
    if (!driver) {
      throw new NotFoundException('Driver not found');
    }
    return driver;
  }

  async createVehicle(data: { plateNumber: string; type?: string; capacityKg?: number }): Promise<Vehicle> {
    const vehicle = this.vehiclesRepository.create(data);
    return this.vehiclesRepository.save(vehicle);
  }

  async findAllVehicles(): Promise<Vehicle[]> {
    return this.vehiclesRepository.find({ order: { plateNumber: 'ASC' } });
  }
}
