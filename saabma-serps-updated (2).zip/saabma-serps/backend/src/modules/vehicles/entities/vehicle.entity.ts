import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, OneToOne, JoinColumn } from 'typeorm';
import { User } from '../../users/entities/user.entity';

@Entity('drivers')
export class Driver {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  // Optional link to a login account (role: DRIVER). Drivers who only ever
  // ride along don't need one; drivers who use the app (checking in via
  // fingerprint at the gate, or the location-tracked login) do.
  @OneToOne(() => User, { nullable: true })
  @JoinColumn()
  user: User;

  @Column()
  fullName: string;

  @Column({ nullable: true })
  licenseNumber: string;

  @Column({ nullable: true })
  phone: string;

  @CreateDateColumn()
  createdAt: Date;
}

@Entity('vehicles')
export class Vehicle {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  plateNumber: string;

  @Column({ nullable: true })
  type: string; // truck, container-trailer, etc.

  @Column({ nullable: true })
  capacityKg: number;

  @CreateDateColumn()
  createdAt: Date;
}
