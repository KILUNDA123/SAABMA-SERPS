import { Controller, Post, Get, Param, Body, UseGuards } from '@nestjs/common';
import { VehiclesService } from './vehicles.service';
import { CreateDriverDto } from './dto/create-driver.dto';
import { CreateVehicleDto } from './dto/create-vehicle.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../permissions/permissions.guard';
import { RequirePermission } from '../permissions/require-permission.decorator';
import { PERMISSIONS } from '../permissions/permissions.constants';

@Controller()
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class VehiclesController {
  constructor(private readonly vehiclesService: VehiclesService) {}

  @Post('drivers')
  @RequirePermission(PERMISSIONS.FLEET_MANAGE)
  createDriver(@Body() dto: CreateDriverDto) {
    return this.vehiclesService.createDriver(dto);
  }

  @Get('drivers')
  @RequirePermission(PERMISSIONS.FLEET_VIEW)
  findAllDrivers() {
    return this.vehiclesService.findAllDrivers();
  }

  @Get('drivers/:id')
  @RequirePermission(PERMISSIONS.FLEET_VIEW)
  findDriver(@Param('id') id: string) {
    return this.vehiclesService.findDriver(id);
  }

  @Post('vehicles')
  @RequirePermission(PERMISSIONS.FLEET_MANAGE)
  createVehicle(@Body() dto: CreateVehicleDto) {
    return this.vehiclesService.createVehicle(dto);
  }

  @Get('vehicles')
  @RequirePermission(PERMISSIONS.FLEET_VIEW)
  findAllVehicles() {
    return this.vehiclesService.findAllVehicles();
  }
}
