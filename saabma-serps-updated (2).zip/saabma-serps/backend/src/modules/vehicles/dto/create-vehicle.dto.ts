import { IsString, IsOptional, IsNumber, Min } from 'class-validator';

export class CreateVehicleDto {
  @IsString()
  plateNumber: string;

  @IsOptional()
  @IsString()
  type?: string;

  @IsOptional()
  @IsNumber()
  @Min(0)
  capacityKg?: number;
}
