import { IsString, IsOptional, IsUUID } from 'class-validator';

export class CreateDriverDto {
  @IsString()
  fullName: string;

  @IsOptional()
  @IsString()
  licenseNumber?: string;

  @IsOptional()
  @IsString()
  phone?: string;

  // If provided, links this driver profile to an existing User account
  // (created via POST /users with role: 'driver') so they can log in.
  @IsOptional()
  @IsUUID()
  userId?: string;
}
