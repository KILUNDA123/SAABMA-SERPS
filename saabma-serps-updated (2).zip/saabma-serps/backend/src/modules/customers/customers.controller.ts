import { Controller, Post, Get, Param, Body, UseGuards } from '@nestjs/common';
import { CustomersService } from './customers.service';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../permissions/permissions.guard';
import { RequirePermission } from '../permissions/require-permission.decorator';
import { PERMISSIONS } from '../permissions/permissions.constants';

@Controller('customers')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class CustomersController {
  constructor(private readonly customersService: CustomersService) {}

  @Post()
  @RequirePermission(PERMISSIONS.SALES_CREATE)
  create(@Body() dto: CreateCustomerDto) {
    return this.customersService.create(dto);
  }

  @Get()
  @RequirePermission(PERMISSIONS.SALES_VIEW)
  findAll() {
    return this.customersService.findAll();
  }

  @Get(':id')
  @RequirePermission(PERMISSIONS.SALES_VIEW)
  findOne(@Param('id') id: string) {
    return this.customersService.findOne(id);
  }
}
