import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Customer } from './entities/customer.entity';

@Injectable()
export class CustomersService {
  constructor(
    @InjectRepository(Customer)
    private readonly customersRepository: Repository<Customer>,
  ) {}

  async create(data: { name: string; country?: string; email?: string; phone?: string }): Promise<Customer> {
    const customer = this.customersRepository.create(data);
    return this.customersRepository.save(customer);
  }

  async findAll(): Promise<Customer[]> {
    return this.customersRepository.find({ order: { name: 'ASC' } });
  }

  async findOne(id: string): Promise<Customer> {
    const customer = await this.customersRepository.findOne({ where: { id } });
    if (!customer) {
      throw new NotFoundException('Customer not found');
    }
    return customer;
  }

  async adjustOutstandingBalance(id: string, delta: number): Promise<Customer> {
    const customer = await this.findOne(id);
    customer.outstandingBalance = Number(customer.outstandingBalance) + delta;
    return this.customersRepository.save(customer);
  }
}
