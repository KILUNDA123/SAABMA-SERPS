import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, CreateDateColumn } from 'typeorm';
import { Invoice } from '../../invoices/entities/invoice.entity';
import { Customer } from '../../customers/entities/customer.entity';

export enum PaymentMethod {
  BANK_TRANSFER = 'bank_transfer',
  CASH = 'cash',
  MOBILE_MONEY = 'mobile_money',
  CHEQUE = 'cheque',
  LETTER_OF_CREDIT = 'letter_of_credit',
}

// Recording a payment here (partial or full) is what should trigger:
// invoice.status -> 'paid' once fully covered, customer.outstandingBalance update,
// and the "Invoice Paid -> CEO/Supervisor notified" flow from the plan.
@Entity('payments')
export class Payment {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Invoice)
  @JoinColumn()
  invoice: Invoice;

  @ManyToOne(() => Customer)
  @JoinColumn()
  customer: Customer;

  @Column('decimal', { precision: 12, scale: 2 })
  amount: number;

  @Column({ type: 'enum', enum: PaymentMethod })
  method: PaymentMethod;

  @Column({ type: 'date' })
  paidOn: string;

  @Column({ nullable: true })
  reference: string; // bank ref, transaction id, etc.

  @CreateDateColumn()
  createdAt: Date;
}
