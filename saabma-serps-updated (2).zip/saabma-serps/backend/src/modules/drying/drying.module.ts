import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DryingRecord } from './entities/drying-record.entity';
import { Approval } from '../approvals/entities/approval.entity';
import { DryingService } from './drying.service';
import { DryingController } from './drying.controller';
import { BatchesModule } from '../batches/batches.module';
import { EmployeesModule } from '../employees/employees.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([DryingRecord, Approval]),
    BatchesModule,
    EmployeesModule,
  ],
  controllers: [DryingController],
  providers: [DryingService],
  exports: [DryingService],
})
export class DryingModule {}
