import { IsUUID, IsString, IsOptional, IsNumber, Min } from 'class-validator';

export class CreateDryingRecordDto {
  @IsUUID()
  batchId: string;

  @IsUUID()
  operatorId: string;

  @IsString()
  date: string;

  @IsNumber()
  @Min(0)
  weightBeforeKg: number;

  @IsOptional()
  @IsNumber()
  @Min(0)
  weightAfterKg?: number;

  @IsOptional()
  @IsString()
  method?: string;

  @IsOptional()
  @IsString()
  remarks?: string;
}
