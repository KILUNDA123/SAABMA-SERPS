import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { DryingRecord } from './entities/drying-record.entity';
import { ApprovalStatus } from '../production/entities/production-record.entity';
import { BatchStage } from '../batches/entities/batch.entity';
import { Approval, ApprovableEntityType } from '../approvals/entities/approval.entity';
import { BatchesService } from '../batches/batches.service';
import { EmployeesService } from '../employees/employees.service';

@Injectable()
export class DryingService {
  constructor(
    @InjectRepository(DryingRecord)
    private readonly dryingRepository: Repository<DryingRecord>,
    @InjectRepository(Approval)
    private readonly approvalsRepository: Repository<Approval>,
    private readonly batchesService: BatchesService,
    private readonly employeesService: EmployeesService,
  ) {}

  async create(data: {
    batchId: string;
    operatorId: string;
    date: string;
    weightBeforeKg: number;
    weightAfterKg?: number;
    method?: string;
    remarks?: string;
  }): Promise<DryingRecord> {
    const batch = await this.batchesService.findOne(data.batchId);
    const operator = await this.employeesService.findOne(data.operatorId);

    const record = this.dryingRepository.create({
      batch,
      operator,
      date: data.date,
      weightBeforeKg: data.weightBeforeKg,
      weightAfterKg: data.weightAfterKg,
      method: data.method,
      remarks: data.remarks,
      status: ApprovalStatus.PENDING,
    });

    return this.dryingRepository.save(record);
  }

  async findAll(): Promise<DryingRecord[]> {
    return this.dryingRepository.find({
      relations: ['batch', 'operator', 'approvedBy'],
      order: { createdAt: 'DESC' },
    });
  }

  async findPending(): Promise<DryingRecord[]> {
    return this.dryingRepository.find({
      where: { status: ApprovalStatus.PENDING },
      relations: ['batch', 'operator'],
      order: { createdAt: 'ASC' },
    });
  }

  async findOne(id: string): Promise<DryingRecord> {
    const record = await this.dryingRepository.findOne({
      where: { id },
      relations: ['batch', 'operator', 'approvedBy'],
    });
    if (!record) {
      throw new NotFoundException('Drying record not found');
    }
    return record;
  }

  async review(
    id: string,
    data: { reviewerEmployeeId: string; decision: ApprovalStatus; comment?: string },
  ): Promise<DryingRecord> {
    if (data.decision === ApprovalStatus.PENDING) {
      throw new BadRequestException('Decision must be APPROVED or REJECTED');
    }

    const record = await this.findOne(id);
    if (record.status !== ApprovalStatus.PENDING) {
      throw new BadRequestException(`Record has already been ${record.status}`);
    }

    const reviewer = await this.employeesService.findOne(data.reviewerEmployeeId);

    record.status = data.decision;
    record.approvedBy = reviewer;
    record.approvedAt = new Date();
    const saved = await this.dryingRepository.save(record);

    const approval = this.approvalsRepository.create({
      entityType: ApprovableEntityType.DRYING,
      entityId: record.id,
      reviewedBy: reviewer,
      decision: data.decision,
      comment: data.comment,
    });
    await this.approvalsRepository.save(approval);

    if (data.decision === ApprovalStatus.APPROVED) {
      await this.batchesService.updateStage(record.batch.id, BatchStage.DRYING);
    }

    return saved;
  }
}
