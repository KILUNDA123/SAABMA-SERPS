import { Controller, Post, Get, Patch, Param, Body, UseGuards } from '@nestjs/common';
import { DryingService } from './drying.service';
import { CreateDryingRecordDto } from './dto/create-drying-record.dto';
import { ReviewDryingRecordDto } from './dto/review-drying-record.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '../users/entities/user.entity';

@Controller('drying')
@UseGuards(JwtAuthGuard, RolesGuard)
export class DryingController {
  constructor(private readonly dryingService: DryingService) {}

  @Post()
  create(@Body() dto: CreateDryingRecordDto) {
    return this.dryingService.create(dto);
  }

  @Get()
  findAll() {
    return this.dryingService.findAll();
  }

  @Get('pending')
  findPending() {
    return this.dryingService.findPending();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.dryingService.findOne(id);
  }

  @Patch(':id/review')
  @Roles(UserRole.SUPERVISOR, UserRole.OPERATIONS_MANAGER, UserRole.CEO)
  review(@Param('id') id: string, @Body() dto: ReviewDryingRecordDto) {
    return this.dryingService.review(id, dto);
  }
}
