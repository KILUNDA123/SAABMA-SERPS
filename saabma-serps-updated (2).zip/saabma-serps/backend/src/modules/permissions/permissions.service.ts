import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Role, Permission } from '../roles/entities/role.entity';

@Injectable()
export class PermissionsService {
  constructor(
    @InjectRepository(Role)
    private readonly rolesRepository: Repository<Role>,
    @InjectRepository(Permission)
    private readonly permissionsRepository: Repository<Permission>,
  ) {}

  async findOrCreateRole(name: string): Promise<Role> {
    let role = await this.rolesRepository.findOne({ where: { name }, relations: ['permissions'] });
    if (!role) {
      role = this.rolesRepository.create({ name, permissions: [] });
      role = await this.rolesRepository.save(role);
    }
    return role;
  }

  async findOrCreatePermission(code: string, description?: string): Promise<Permission> {
    let permission = await this.permissionsRepository.findOne({ where: { code } });
    if (!permission) {
      permission = this.permissionsRepository.create({ code, description });
      permission = await this.permissionsRepository.save(permission);
    }
    return permission;
  }

  async grant(roleName: string, code: string): Promise<Role> {
    const role = await this.findOrCreateRole(roleName);
    const permission = await this.findOrCreatePermission(code);

    const alreadyGranted = role.permissions.some((p) => p.code === code);
    if (!alreadyGranted) {
      role.permissions.push(permission);
      await this.rolesRepository.save(role);
    }
    return this.findOrCreateRole(roleName);
  }

  async revoke(roleName: string, code: string): Promise<Role> {
    const role = await this.rolesRepository.findOne({ where: { name: roleName }, relations: ['permissions'] });
    if (!role) {
      throw new NotFoundException(`Role "${roleName}" not found`);
    }
    role.permissions = role.permissions.filter((p) => p.code !== code);
    return this.rolesRepository.save(role);
  }

  async listPermissionsForRole(roleName: string): Promise<Permission[]> {
    const role = await this.rolesRepository.findOne({ where: { name: roleName }, relations: ['permissions'] });
    return role?.permissions ?? [];
  }

  // The actual enforcement check, used by PermissionsGuard. A role with no
  // row in the `roles` table at all (never configured) has no fine-grained
  // permissions - falls through to false rather than throwing, so a route
  // protected only by @RequirePermission (no @Roles) fails closed by default.
  async roleHasPermission(roleName: string, code: string): Promise<boolean> {
    const role = await this.rolesRepository.findOne({ where: { name: roleName }, relations: ['permissions'] });
    if (!role) return false;
    return role.permissions.some((p) => p.code === code);
  }

  async listAllPermissions(): Promise<Permission[]> {
    return this.permissionsRepository.find({ order: { code: 'ASC' } });
  }
}
