import { SetMetadata } from '@nestjs/common';
import { PermissionCode } from './permissions.constants';

export const PERMISSION_KEY = 'permission';

// Usage: @RequirePermission(PERMISSIONS.REPORTS_VIEW) above a controller
// method. This is now the PRIMARY authorization mechanism across the app -
// what a user can do is determined by which permission codes their role has
// been granted (see permissions.constants.ts and the Role/Permission
// tables), not by hardcoded `if (user.role === 'operations_manager')`
// checks. @Roles() is only kept on a small number of routes where the
// action is inherently role-identity-bound rather than permission-bound
// (e.g. an admin-only endpoint that must never be delegable via a
// permission grant, like changing another user's account status).
export const RequirePermission = (code: PermissionCode) => SetMetadata(PERMISSION_KEY, code);
