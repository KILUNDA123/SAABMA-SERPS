import { UserRole } from '../users/entities/user.entity';
import { PERMISSIONS, PermissionCode } from './permissions.constants';

// Default permission grants per role, reflecting the 6-tier authority
// model:
//   Tier 1 CEO/Executive          -> UserRole.CEO
//   Tier 2 Executive Management   -> UserRole.ADMIN
//   Tier 3 Middle-Level Management-> OPERATIONS_MANAGER, HR, FINANCE
//   Tier 4 Supervisors             -> SUPERVISOR
//   Tier 5 Permanent Employees     -> PRODUCTION_OPERATOR, WAREHOUSE, SALES, DRIVER, SECURITY
//   Tier 6 Casual Workers          -> CASUAL_WORKER
//
// This is a SEED, not the authorization mechanism itself - it's what gets
// written into the Role/Permission tables the first time the system boots.
// A CEO or admin can grant/revoke any of these afterwards from the
// Permissions screen without touching code (see permissions:manage),
// which is what makes this "add a new permission without rewriting the
// application": add the code to permissions.constants.ts, decorate the
// route with it, and grant it to whichever roles need it - no guard logic
// changes required.
//
// Explicit authority, not inherited hierarchy: a Middle-Level Manager does
// NOT automatically get everything a Supervisor has "beneath" them - HR
// has no production:approve, Finance has no warehouse:manage. Each tier's
// permissions are listed in full, on purpose.
export const ROLE_DEFAULT_PERMISSIONS: Record<UserRole, PermissionCode[]> = {
  [UserRole.CEO]: Object.values(PERMISSIONS), // Tier 1 - full access, every code

  [UserRole.ADMIN]: [
    // Tier 2 - broad oversight and system administration, not day-to-day
    // operational actions (no production:approve, no sales:create).
    PERMISSIONS.DASHBOARD_VIEW,
    PERMISSIONS.EMPLOYEES_VIEW,
    PERMISSIONS.EMPLOYEES_CREATE,
    PERMISSIONS.EMPLOYEES_EDIT,
    PERMISSIONS.EMPLOYEES_SUSPEND,
    PERMISSIONS.EMPLOYEES_REACTIVATE,
    PERMISSIONS.PRODUCTION_VIEW,
    PERMISSIONS.WAREHOUSE_VIEW,
    PERMISSIONS.SALES_VIEW,
    PERMISSIONS.SHIPMENTS_VIEW,
    PERMISSIONS.FLEET_VIEW,
    PERMISSIONS.ATTENDANCE_VIEW,
    PERMISSIONS.REPORTS_VIEW,
    PERMISSIONS.PERMISSIONS_VIEW,
    PERMISSIONS.PERMISSIONS_MANAGE,
    PERMISSIONS.NOTIFICATIONS_VIEW,
    PERMISSIONS.DOCUMENTS_VIEW,
    PERMISSIONS.DOCUMENTS_DOWNLOAD,
    PERMISSIONS.AUDIT_LOGS_VIEW,
    PERMISSIONS.LOCATION_LOGS_VIEW,
  ],

  [UserRole.OPERATIONS_MANAGER]: [
    // Tier 3 - cross-functional operations oversight.
    PERMISSIONS.DASHBOARD_VIEW,
    PERMISSIONS.EMPLOYEES_VIEW,
    PERMISSIONS.PRODUCTION_VIEW,
    PERMISSIONS.PRODUCTION_CREATE,
    PERMISSIONS.PRODUCTION_APPROVE,
    PERMISSIONS.WAREHOUSE_VIEW,
    PERMISSIONS.WAREHOUSE_MANAGE,
    PERMISSIONS.SALES_VIEW,
    PERMISSIONS.SHIPMENTS_VIEW,
    PERMISSIONS.SHIPMENTS_MANAGE,
    PERMISSIONS.FLEET_VIEW,
    PERMISSIONS.FLEET_MANAGE,
    PERMISSIONS.ATTENDANCE_VIEW,
    PERMISSIONS.ATTENDANCE_MANAGE,
    PERMISSIONS.REPORTS_VIEW,
    PERMISSIONS.NOTIFICATIONS_VIEW,
    PERMISSIONS.DOCUMENTS_VIEW,
    PERMISSIONS.DOCUMENTS_DOWNLOAD,
  ],

  [UserRole.HR]: [
    // Tier 3 - HR-specific middle management.
    PERMISSIONS.DASHBOARD_VIEW,
    PERMISSIONS.EMPLOYEES_VIEW,
    PERMISSIONS.EMPLOYEES_CREATE,
    PERMISSIONS.EMPLOYEES_EDIT,
    PERMISSIONS.EMPLOYEES_SUSPEND,
    PERMISSIONS.EMPLOYEES_REACTIVATE,
    PERMISSIONS.ATTENDANCE_VIEW,
    PERMISSIONS.ATTENDANCE_MANAGE,
    PERMISSIONS.REPORTS_VIEW,
    PERMISSIONS.NOTIFICATIONS_VIEW,
    PERMISSIONS.DOCUMENTS_VIEW,
  ],

  [UserRole.FINANCE]: [
    // Tier 3 - finance-specific middle management. sales:create covers
    // recording invoice payments and creating orders/invoices, which
    // Finance could already do under the old @Roles(FINANCE, ...) checks.
    PERMISSIONS.DASHBOARD_VIEW,
    PERMISSIONS.SALES_VIEW,
    PERMISSIONS.SALES_CREATE,
    PERMISSIONS.REPORTS_VIEW,
    PERMISSIONS.REPORTS_EXPORT,
    PERMISSIONS.NOTIFICATIONS_VIEW,
    PERMISSIONS.DOCUMENTS_VIEW,
    PERMISSIONS.DOCUMENTS_DOWNLOAD,
  ],

  [UserRole.SUPERVISOR]: [
    // Tier 4 - shop-floor supervision and approval authority.
    PERMISSIONS.DASHBOARD_VIEW,
    PERMISSIONS.PRODUCTION_VIEW,
    PERMISSIONS.PRODUCTION_CREATE,
    PERMISSIONS.PRODUCTION_APPROVE,
    PERMISSIONS.WAREHOUSE_VIEW,
    PERMISSIONS.ATTENDANCE_VIEW,
    PERMISSIONS.NOTIFICATIONS_VIEW,
  ],

  [UserRole.PRODUCTION_OPERATOR]: [
    // Tier 5 - permanent employee, production line.
    PERMISSIONS.PRODUCTION_VIEW,
    PERMISSIONS.PRODUCTION_CREATE,
    PERMISSIONS.ATTENDANCE_VIEW,
    PERMISSIONS.NOTIFICATIONS_VIEW,
  ],

  [UserRole.WAREHOUSE]: [
    // Tier 5 - permanent employee, warehouse.
    PERMISSIONS.WAREHOUSE_VIEW,
    PERMISSIONS.WAREHOUSE_MANAGE,
    PERMISSIONS.NOTIFICATIONS_VIEW,
  ],

  [UserRole.SALES]: [
    // Tier 5 - permanent employee, sales.
    PERMISSIONS.SALES_VIEW,
    PERMISSIONS.SALES_CREATE,
    PERMISSIONS.SHIPMENTS_VIEW,
    PERMISSIONS.NOTIFICATIONS_VIEW,
    PERMISSIONS.DOCUMENTS_VIEW,
    PERMISSIONS.DOCUMENTS_DOWNLOAD,
  ],

  [UserRole.DRIVER]: [
    // Tier 5 - permanent employee, fleet/logistics.
    PERMISSIONS.FLEET_VIEW,
    PERMISSIONS.SHIPMENTS_VIEW,
    PERMISSIONS.ATTENDANCE_VIEW,
    PERMISSIONS.NOTIFICATIONS_VIEW,
  ],

  [UserRole.SECURITY]: [
    // Tier 5 - permanent employee, gate/security.
    PERMISSIONS.ATTENDANCE_VIEW,
    PERMISSIONS.ATTENDANCE_MANAGE,
    PERMISSIONS.NOTIFICATIONS_VIEW,
  ],

  [UserRole.CASUAL_WORKER]: [
    // Tier 6 - highly restricted: only their own duties, attendance, and
    // work-record-relevant notifications.
    PERMISSIONS.ATTENDANCE_VIEW,
    PERMISSIONS.NOTIFICATIONS_VIEW,
  ],
};
