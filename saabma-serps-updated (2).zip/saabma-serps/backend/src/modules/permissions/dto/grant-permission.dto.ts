import { IsString, IsOptional } from 'class-validator';

export class GrantPermissionDto {
  @IsString()
  role: string; // matches UserRole enum value, e.g. 'supervisor'

  @IsString()
  code: string; // e.g. 'reports.view'

  @IsOptional()
  @IsString()
  description?: string;
}
