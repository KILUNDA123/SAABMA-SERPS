// Centralized permission definition system.
//
// This is the ONLY place permission code strings are allowed to be
// hand-typed as literals - every controller, every seed, and the frontend
// nav config all reference PERMISSIONS.X rather than typing 'employees:view'
// by hand, so a typo or a renamed module can't silently create a permission
// nobody can ever be granted.
//
// Format is always "resource:action" (colon, not dot - `reports.view` from
// the first pass of this module is being replaced with `reports:view`).

export const PERMISSIONS = {
  DASHBOARD_VIEW: 'dashboard:view',

  EMPLOYEES_VIEW: 'employees:view',
  EMPLOYEES_CREATE: 'employees:create',
  EMPLOYEES_EDIT: 'employees:edit',
  EMPLOYEES_SUSPEND: 'employees:suspend',
  EMPLOYEES_REACTIVATE: 'employees:reactivate',

  PRODUCTION_VIEW: 'production:view',
  PRODUCTION_CREATE: 'production:create',
  PRODUCTION_APPROVE: 'production:approve',

  WAREHOUSE_VIEW: 'warehouse:view',
  WAREHOUSE_MANAGE: 'warehouse:manage',

  SALES_VIEW: 'sales:view',
  SALES_CREATE: 'sales:create',

  SHIPMENTS_VIEW: 'shipments:view',
  SHIPMENTS_MANAGE: 'shipments:manage',

  FLEET_VIEW: 'fleet:view',
  FLEET_MANAGE: 'fleet:manage',

  ATTENDANCE_VIEW: 'attendance:view',
  ATTENDANCE_MANAGE: 'attendance:manage',

  REPORTS_VIEW: 'reports:view',
  REPORTS_EXPORT: 'reports:export',

  PERMISSIONS_VIEW: 'permissions:view',
  PERMISSIONS_MANAGE: 'permissions:manage',

  NOTIFICATIONS_VIEW: 'notifications:view',

  DOCUMENTS_VIEW: 'documents:view',
  DOCUMENTS_DOWNLOAD: 'documents:download',

  AUDIT_LOGS_VIEW: 'audit_logs:view',
  LOCATION_LOGS_VIEW: 'location_logs:view',
} as const;

export type PermissionCode = (typeof PERMISSIONS)[keyof typeof PERMISSIONS];

export const ALL_PERMISSION_CODES: PermissionCode[] = Object.values(PERMISSIONS);

// Human-readable descriptions, shown in the Permissions admin screen - kept
// next to the codes so the two can't drift out of sync.
export const PERMISSION_DESCRIPTIONS: Record<PermissionCode, string> = {
  [PERMISSIONS.DASHBOARD_VIEW]: 'View the executive dashboard',
  [PERMISSIONS.EMPLOYEES_VIEW]: 'View employee records',
  [PERMISSIONS.EMPLOYEES_CREATE]: 'Create new employee records',
  [PERMISSIONS.EMPLOYEES_EDIT]: 'Edit employee records',
  [PERMISSIONS.EMPLOYEES_SUSPEND]: 'Suspend an employee account',
  [PERMISSIONS.EMPLOYEES_REACTIVATE]: 'Reactivate a suspended employee account',
  [PERMISSIONS.PRODUCTION_VIEW]: 'View production batches and stages',
  [PERMISSIONS.PRODUCTION_CREATE]: 'Log new production records',
  [PERMISSIONS.PRODUCTION_APPROVE]: 'Approve production stage records',
  [PERMISSIONS.WAREHOUSE_VIEW]: 'View warehouse stock and movements',
  [PERMISSIONS.WAREHOUSE_MANAGE]: 'Receive, dispatch, and transfer stock',
  [PERMISSIONS.SALES_VIEW]: 'View customers, orders, and invoices',
  [PERMISSIONS.SALES_CREATE]: 'Create orders and invoices',
  [PERMISSIONS.SHIPMENTS_VIEW]: 'View shipments and containers',
  [PERMISSIONS.SHIPMENTS_MANAGE]: 'Manage shipment and container status',
  [PERMISSIONS.FLEET_VIEW]: 'View vehicles and drivers',
  [PERMISSIONS.FLEET_MANAGE]: 'Register vehicles and drivers',
  [PERMISSIONS.ATTENDANCE_VIEW]: 'View attendance records',
  [PERMISSIONS.ATTENDANCE_MANAGE]: 'Notify missing employees, manage attendance',
  [PERMISSIONS.REPORTS_VIEW]: 'View operational and financial reports',
  [PERMISSIONS.REPORTS_EXPORT]: 'Export reports',
  [PERMISSIONS.PERMISSIONS_VIEW]: 'View role permission grants',
  [PERMISSIONS.PERMISSIONS_MANAGE]: 'Grant or revoke role permissions',
  [PERMISSIONS.NOTIFICATIONS_VIEW]: 'View the notifications inbox',
  [PERMISSIONS.DOCUMENTS_VIEW]: 'View generated documents',
  [PERMISSIONS.DOCUMENTS_DOWNLOAD]: 'Download generated documents',
  [PERMISSIONS.AUDIT_LOGS_VIEW]: 'View the system audit trail',
  [PERMISSIONS.LOCATION_LOGS_VIEW]: 'View login IP addresses and GPS coordinates',
};
