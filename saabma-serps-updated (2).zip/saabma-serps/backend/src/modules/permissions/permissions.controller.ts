import { Controller, Post, Delete, Get, Param, Body, UseGuards, Request } from '@nestjs/common';
import { PermissionsService } from './permissions.service';
import { GrantPermissionDto } from './dto/grant-permission.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '../users/entities/user.entity';
import { PermissionsGuard } from './permissions.guard';
import { RequirePermission } from './require-permission.decorator';
import { PERMISSIONS } from './permissions.constants';

// Managing permissions is the one module that keeps @Roles(ADMIN, CEO) as
// a hard backstop IN ADDITION TO @RequirePermission(), rather than relying
// on the permission system alone - granting/revoking permissions.manage
// itself would otherwise be circular (whoever holds permissions:manage
// could grant themselves anything, including to a role that shouldn't have
// this module at all). Every other controller in the app uses
// @RequirePermission() alone.
@Controller('permissions')
export class PermissionsController {
  constructor(private readonly permissionsService: PermissionsService) {}

  // Any authenticated user can see their OWN permission set - this is what
  // the frontend calls right after login to decide what to render in the
  // sidebar. It only ever returns the caller's own role's grants, so there
  // is nothing here to restrict.
  @Get('mine')
  @UseGuards(JwtAuthGuard)
  async mine(@Request() req: any) {
    const permissions = await this.permissionsService.listPermissionsForRole(req.user.role);
    return { role: req.user.role, permissions: permissions.map((p) => p.code) };
  }

  @Post('grant')
  @UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
  @Roles(UserRole.ADMIN, UserRole.CEO)
  @RequirePermission(PERMISSIONS.PERMISSIONS_MANAGE)
  grant(@Body() dto: GrantPermissionDto) {
    return this.permissionsService.grant(dto.role, dto.code);
  }

  @Delete('revoke/:role/:code')
  @UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
  @Roles(UserRole.ADMIN, UserRole.CEO)
  @RequirePermission(PERMISSIONS.PERMISSIONS_MANAGE)
  revoke(@Param('role') role: string, @Param('code') code: string) {
    return this.permissionsService.revoke(role, code);
  }

  @Get('role/:role')
  @UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
  @Roles(UserRole.ADMIN, UserRole.CEO)
  @RequirePermission(PERMISSIONS.PERMISSIONS_VIEW)
  listForRole(@Param('role') role: string) {
    return this.permissionsService.listPermissionsForRole(role);
  }

  @Get()
  @UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
  @Roles(UserRole.ADMIN, UserRole.CEO)
  @RequirePermission(PERMISSIONS.PERMISSIONS_VIEW)
  listAll() {
    return this.permissionsService.listAllPermissions();
  }
}
