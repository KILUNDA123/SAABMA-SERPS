import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

export enum BatchStage {
  RECEIVED = 'received',
  SOAKING = 'soaking',
  WASHING = 'washing',
  DRYING = 'drying',
  BRUSHING = 'brushing',
  BALING = 'baling',
  WAREHOUSE = 'warehouse',
  SHIPPED = 'shipped',
}

@Entity('batches')
export class Batch {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  batchNumber: string; // e.g. SBM2507010001

  @Column({ type: 'enum', enum: BatchStage, default: BatchStage.RECEIVED })
  currentStage: BatchStage;

  @Column('decimal', { precision: 10, scale: 2 })
  rawWeightKg: number;

  @Column({ nullable: true })
  notes: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
