import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Batch, BatchStage } from './entities/batch.entity';

@Injectable()
export class BatchesService {
  constructor(
    @InjectRepository(Batch)
    private readonly batchesRepository: Repository<Batch>,
  ) {}

  // Generates batch numbers like SBM2507070001 - SBM + YY + MM + DD + 4-digit
  // daily sequence, matching the format used in the original plan.
  private async generateBatchNumber(): Promise<string> {
    const now = new Date();
    const datePart = `${String(now.getFullYear()).slice(2)}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
    const prefix = `SBM${datePart}`;

    const countToday = await this.batchesRepository
      .createQueryBuilder('batch')
      .where('batch.batchNumber LIKE :prefix', { prefix: `${prefix}%` })
      .getCount();

    const sequence = String(countToday + 1).padStart(4, '0');
    return `${prefix}${sequence}`;
  }

  async create(data: { rawWeightKg: number; notes?: string }): Promise<Batch> {
    const batchNumber = await this.generateBatchNumber();
    const batch = this.batchesRepository.create({
      batchNumber,
      rawWeightKg: data.rawWeightKg,
      notes: data.notes,
      currentStage: BatchStage.RECEIVED,
    });
    return this.batchesRepository.save(batch);
  }

  async findAll(): Promise<Batch[]> {
    return this.batchesRepository.find({ order: { createdAt: 'DESC' } });
  }

  async findOne(id: string): Promise<Batch> {
    const batch = await this.batchesRepository.findOne({ where: { id } });
    if (!batch) {
      throw new NotFoundException('Batch not found');
    }
    return batch;
  }

  async updateStage(id: string, stage: BatchStage): Promise<Batch> {
    const batch = await this.findOne(id);
    batch.currentStage = stage;
    return this.batchesRepository.save(batch);
  }
}
