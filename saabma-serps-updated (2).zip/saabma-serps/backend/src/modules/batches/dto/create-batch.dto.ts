import { IsNumber, IsOptional, IsString, Min } from 'class-validator';

export class CreateBatchDto {
  @IsNumber()
  @Min(0)
  rawWeightKg: number;

  @IsOptional()
  @IsString()
  notes?: string;
}
