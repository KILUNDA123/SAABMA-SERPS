import { Module } from '@nestjs/common';
import { BiometricsController } from './biometrics.controller';
import { EmployeesModule } from '../employees/employees.module';
import { AttendanceModule } from '../attendance/attendance.module';

@Module({
  imports: [EmployeesModule, AttendanceModule],
  controllers: [BiometricsController],
})
export class BiometricsModule {}
