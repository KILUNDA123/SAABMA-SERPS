import { Controller, Post, Body, UseGuards } from '@nestjs/common';
import { EmployeesService } from '../employees/employees.service';
import { AttendanceService } from '../attendance/attendance.service';
import { EnrollFingerprintDto } from './dto/enroll-fingerprint.dto';
import { ScanDto } from './dto/scan.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '../users/entities/user.entity';

@Controller('biometrics')
export class BiometricsController {
  constructor(
    private readonly employeesService: EmployeesService,
    private readonly attendanceService: AttendanceService,
  ) {}

  // Only HR/Admin/CEO can enroll a fingerprint against an employee record -
  // this is a security-sensitive action (it grants door/system access).
  @Post('enroll')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.HR, UserRole.ADMIN, UserRole.CEO)
  enroll(@Body() dto: EnrollFingerprintDto) {
    return this.employeesService.enrollFingerprint(dto.employeeId, dto.fingerprintTemplateId);
  }

  // Called by the door controller/scanner itself, not by a person typing
  // into the app - so it is NOT behind JwtAuthGuard. Instead it is secured
  // by requiring a valid, enrolled fingerprint template: an unrecognized
  // template is rejected with 404 by AttendanceService. In production this
  // endpoint should additionally be restricted to the door controller's own
  // IP/network (e.g. via a reverse-proxy allowlist), since it is a physical
  // device integration point, not a general user-facing API.
  @Post('scan')
  scan(@Body() dto: ScanDto) {
    return this.attendanceService.recordScan(dto.fingerprintTemplateId, dto.scanRef);
  }
}
