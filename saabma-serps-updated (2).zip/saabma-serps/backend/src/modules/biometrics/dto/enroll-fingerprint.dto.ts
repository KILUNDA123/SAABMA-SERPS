import { IsUUID, IsString, MinLength } from 'class-validator';

export class EnrollFingerprintDto {
  @IsUUID()
  employeeId: string;

  // The actual biometric template (a mathematical representation of the
  // fingerprint, NOT an image) comes from the scanner vendor's SDK - e.g.
  // ZKTeco, Suprema, DigitalPersona all provide one. This field stores
  // whatever opaque template string/hash that SDK produces; this backend
  // never sees or stores a raw fingerprint image.
  @IsString()
  @MinLength(8)
  fingerprintTemplateId: string;
}
