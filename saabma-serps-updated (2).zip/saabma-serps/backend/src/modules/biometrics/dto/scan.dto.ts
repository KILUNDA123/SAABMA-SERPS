import { IsString, MinLength, IsOptional } from 'class-validator';

export class ScanDto {
  @IsString()
  @MinLength(8)
  fingerprintTemplateId: string;

  @IsOptional()
  @IsString()
  scanRef?: string; // raw event id from the door controller, for traceability
}
