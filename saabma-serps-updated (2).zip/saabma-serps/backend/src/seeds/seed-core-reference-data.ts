import { EntityManager } from 'typeorm';
import { Department } from '../modules/departments/entities/department.entity';
import { Permission, Role } from '../modules/roles/entities/role.entity';
import { Shift } from '../modules/shifts/entities/shift.entity';
import * as bcrypt from 'bcryptjs';
import { User, UserRole } from '../modules/users/entities/user.entity';
import { ALL_PERMISSION_CODES, PERMISSION_DESCRIPTIONS } from '../modules/permissions/permissions.constants';
import { ROLE_DEFAULT_PERMISSIONS } from '../modules/permissions/role-default-permissions';

export async function seedCoreReferenceData(manager: EntityManager): Promise<void> {
  await manager.createQueryBuilder().delete().from(Department).execute();
  await manager.createQueryBuilder().delete().from(Permission).execute();
  await manager.createQueryBuilder().delete().from(Role).execute();
  await manager.createQueryBuilder().delete().from(Shift).execute();
  await manager.createQueryBuilder().delete().from(User).execute();

  const departments = await manager.save(
    Department,
    [
      { name: 'Production', description: 'Washing, drying, and packing operations' },
      { name: 'Warehouse', description: 'Storage and stock movement' },
      { name: 'Finance', description: 'Invoicing and revenue' },
      { name: 'HR', description: 'People operations' },
      { name: 'Sales', description: 'Customer orders and negotiations' },
      { name: 'Logistics', description: 'Dispatch and transport' },
    ].map((dept) => manager.create(Department, dept)),
  );

  const permissionEntities = await manager.save(
    Permission,
    ALL_PERMISSION_CODES.map((code) =>
      manager.create(Permission, { code, description: PERMISSION_DESCRIPTIONS[code] }),
    ),
  );
  const permissionByCode = new Map(permissionEntities.map((p) => [p.code, p]));

  const roles = await manager.save(
    Role,
    // Role.name must match UserRole enum values exactly - roleHasPermission()
    // looks up Role by the JWT's user.role string (e.g. 'ceo',
    // 'operations_manager'), not a human-readable display name.
    Object.entries(ROLE_DEFAULT_PERMISSIONS).map(([roleName, codes]) =>
      manager.create(Role, {
        name: roleName,
        permissions: codes.map((code) => permissionByCode.get(code)!),
      }),
    ),
  );

  const shifts = await manager.save(
    Shift,
    [
      { name: 'Morning', startTime: '07:00:00', endTime: '15:00:00' },
      { name: 'Afternoon', startTime: '15:00:00', endTime: '23:00:00' },
      { name: 'Night', startTime: '23:00:00', endTime: '07:00:00' },
    ].map((shift) => manager.create(Shift, shift)),
  );

  const passwordHash = await bcrypt.hash('Passw0rd!2026', 10);
  await manager.save(
    User,
    [
      { employeeId: 'SERP/EXE/001', email: 'ceo@saabma.co.ke', passwordHash, fullName: 'Cynthia Mwangi', role: UserRole.CEO, isActive: true },
      { employeeId: 'SERP/EXE/002', email: 'ops@saabma.co.ke', passwordHash, fullName: 'Daniel Otieno', role: UserRole.OPERATIONS_MANAGER, isActive: true },
      { employeeId: 'SERP/EXE/003', email: 'admin@saabma.co.ke', passwordHash, fullName: 'Brian Otundo', role: UserRole.ADMIN, isActive: true },
      { employeeId: 'SERP/EMP/001', email: 'hr@saabma.co.ke', passwordHash, fullName: 'Asha Njeri', role: UserRole.HR, isActive: true },
      { employeeId: 'SERP/EMP/002', email: 'finance@saabma.co.ke', passwordHash, fullName: 'Kevin Wekesa', role: UserRole.FINANCE, isActive: true },
      { employeeId: 'SERP/EMP/003', email: 'warehouse@saabma.co.ke', passwordHash, fullName: 'Salim Kibet', role: UserRole.WAREHOUSE, isActive: true },
      { employeeId: 'SERP/EMP/004', email: 'sales@saabma.co.ke', passwordHash, fullName: 'Wanjiru Kamau', role: UserRole.SALES, isActive: true },
      { employeeId: 'SERP/EMP/005', email: 'driver@saabma.co.ke', passwordHash, fullName: 'Peter Mwangi', role: UserRole.DRIVER, isActive: true },
      { employeeId: 'SERP/EMP/006', email: 'supervisor@saabma.co.ke', passwordHash, fullName: 'Grace Muthoni', role: UserRole.SUPERVISOR, isActive: true },
      { employeeId: 'SERP/EMP/007', email: 'operator@saabma.co.ke', passwordHash, fullName: 'Samuel Otieno', role: UserRole.PRODUCTION_OPERATOR, isActive: true },
      { employeeId: 'SERP/EMP/008', email: 'security@saabma.co.ke', passwordHash, fullName: 'John Kamau', role: UserRole.SECURITY, isActive: true },
      { employeeId: 'SERP/CW/214', passwordHash, fullName: 'Faith Nyambura', role: UserRole.CASUAL_WORKER, isActive: true },
    ].map((user) => manager.create(User, user)),
  );

  return undefined;
}
