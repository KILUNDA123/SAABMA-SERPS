import { EntityManager } from 'typeorm';
import { AuditLog } from '../modules/audit/entities/audit-log.entity';
import { RevenueHistory } from '../modules/reports/entities/revenue-history.entity';
import { User } from '../modules/users/entities/user.entity';

export async function seedAuditAndRevenue(manager: EntityManager): Promise<void> {
  await manager.createQueryBuilder().delete().from(AuditLog).execute();
  await manager.createQueryBuilder().delete().from(RevenueHistory).execute();

  const users = await manager.find(User, { order: { fullName: 'ASC' } });
  const auditLogs: Partial<AuditLog>[] = [];

  for (let index = 0; index < 250; index += 1) {
    const user = users[index % users.length];
    const createdAt = new Date();
    createdAt.setDate(createdAt.getDate() - (index % 60));
    auditLogs.push({
      user,
      action: index % 3 === 0 ? 'CREATE' : index % 3 === 1 ? 'UPDATE' : 'DELETE',
      entityType: index % 4 === 0 ? 'Invoice' : index % 4 === 1 ? 'Order' : index % 4 === 2 ? 'AttendanceRecord' : 'Employee',
      entityId: `entity-${index + 1}`,
      oldValue: { snapshot: 'before' },
      newValue: { snapshot: 'after' },
      ipAddress: '192.168.1.10',
      userAgent: 'Seed Script',
      createdAt,
    });
  }

  await manager.save(AuditLog, auditLogs.map((auditLog) => manager.create(AuditLog, auditLog)));

  const revenueHistoryRows: Partial<RevenueHistory>[] = [];
  const start = new Date();
  start.setMonth(start.getMonth() - 11);
  for (let index = 0; index < 12; index += 1) {
    const period = new Date(start.getFullYear(), start.getMonth() + index, 1);
    revenueHistoryRows.push({
      period: period.toISOString().slice(0, 10),
      revenue: Number((700000 + index * 120000 + (index % 3) * 35000).toFixed(2)),
      collections: Number((620000 + index * 90000 + (index % 2) * 20000).toFixed(2)),
      outstanding: Number((80000 + index * 20000).toFixed(2)),
    });
  }

  await manager.save(RevenueHistory, revenueHistoryRows.map((row) => manager.create(RevenueHistory, row)));
}
