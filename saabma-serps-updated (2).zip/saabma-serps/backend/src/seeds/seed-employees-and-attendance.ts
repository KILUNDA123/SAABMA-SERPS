import { EntityManager } from 'typeorm';
import { Department } from '../modules/departments/entities/department.entity';
import { Employee } from '../modules/employees/entities/employee.entity';
import { AttendanceRecord } from '../modules/attendance/entities/attendance.entity';
import { Shift } from '../modules/shifts/entities/shift.entity';

const firstNames = ['Akinyi', 'Brian', 'Catherine', 'Daniel', 'Esther', 'Faith', 'George', 'Hellen', 'Isaac', 'Jane', 'Kevin', 'Lilian', 'Moses', 'Naomi', 'Oscar', 'Penny', 'Quincy', 'Ruth', 'Sam', 'Tina', 'Uche', 'Victor', 'Winnie', 'Xavier', 'Yvonne', 'Zachary'];
const lastNames = ['Achieng', 'Kimani', 'Mutua', 'Kiprotich', 'Njeri', 'Odhiambo', 'Wanjiku', 'Otieno', 'Mwangi', 'Kariuki', 'Mugo', 'Kibet', 'Njoroge', 'Abdalla', 'Chepchirchir', 'Kamau', 'Mumo', 'Wambui', 'Kilonzo', 'Sang'];
const departments = ['Production', 'Warehouse', 'Finance', 'HR', 'Sales', 'Logistics'];
const positions = ['Operator', 'Supervisor', 'Clerk', 'Officer', 'Manager', 'Assistant'];

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pick<T>(values: T[]): T {
  return values[Math.floor(Math.random() * values.length)];
}

export async function seedEmployeesAndAttendance(manager: EntityManager): Promise<void> {
  await manager.createQueryBuilder().delete().from(Employee).execute();
  await manager.createQueryBuilder().delete().from(AttendanceRecord).execute();

  const departmentRows = await manager.find(Department, { order: { name: 'ASC' } });
  const shiftRows = await manager.find(Shift, { order: { name: 'ASC' } });

  const employeesToCreate: Partial<Employee>[] = [];
  for (let index = 1; index <= 150; index += 1) {
    const firstName = pick(firstNames);
    const lastName = pick(lastNames);
    const fullName = `${firstName} ${lastName}`;
    employeesToCreate.push({
      employeeCode: `EMP-${String(index).padStart(4, '0')}`,
      fullName,
      department: departmentRows.find((department) => department.name === pick(departments)) ?? departmentRows[0],
      defaultShift: shiftRows[randomInt(0, shiftRows.length - 1)],
      position: pick(positions),
      dailyRate: Number((randomInt(2500, 8000) / 100).toFixed(2)),
      isActive: true,
    });
  }

  const employees = await manager.save(Employee, employeesToCreate.map((employee) => manager.create(Employee, employee)));

  const attendanceRecords: Partial<AttendanceRecord>[] = [];
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - 30);

  for (let index = 0; index < 700; index += 1) {
    const employee = employees[index % employees.length];
    const currentDate = new Date(startDate);
    currentDate.setDate(startDate.getDate() + Math.floor(index / 5));
    const date = currentDate.toISOString().slice(0, 10);
    const timeIn = new Date(`${date}T${String(randomInt(6, 8)).padStart(2, '0')}:${String(randomInt(0, 59)).padStart(2, '0')}:00Z`);
    const timeOut = new Date(timeIn.getTime() + 8 * 60 * 60 * 1000);
    attendanceRecords.push({
      employee,
      shift: employee.defaultShift,
      date,
      timeIn,
      timeOut,
      hoursWorked: 8,
      isLate: Math.random() > 0.8,
      overtimeHours: Math.random() > 0.92 ? 1 : 0,
    });
  }

  await manager.save(AttendanceRecord, attendanceRecords.map((record) => manager.create(AttendanceRecord, record)));
}
