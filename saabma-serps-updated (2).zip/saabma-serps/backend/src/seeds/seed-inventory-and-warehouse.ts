import { EntityManager } from 'typeorm';
import { InventoryItem, InventoryCategory } from '../modules/inventory/entities/inventory-item.entity';
import { Warehouse, StockMovement, StockMovementType } from '../modules/warehouse/entities/warehouse.entity';
import { Employee } from '../modules/employees/entities/employee.entity';

export async function seedInventoryAndWarehouse(manager: EntityManager): Promise<void> {
  await manager.createQueryBuilder().delete().from(StockMovement).execute();
  await manager.createQueryBuilder().delete().from(Warehouse).execute();
  await manager.createQueryBuilder().delete().from(InventoryItem).execute();

  const warehouse = await manager.save(Warehouse, manager.create(Warehouse, { name: 'Main Warehouse', location: 'Mombasa' }));
  const employees = await manager.find(Employee, { take: 20 });

  const inventoryItems = await manager.save(
    InventoryItem,
    [
      { name: 'Sisal Fibre', category: InventoryCategory.FINISHED_FIBRE, unit: 'kg', currentStock: 1250, reorderLevel: 300 },
      { name: 'Raw Sisal', category: InventoryCategory.RAW_SISAL, unit: 'kg', currentStock: 4000, reorderLevel: 1000 },
      { name: 'Hydrogen Peroxide', category: InventoryCategory.CHEMICAL, unit: 'litres', currentStock: 250, reorderLevel: 100 },
      { name: 'Packaging Bags', category: InventoryCategory.PACKAGING, unit: 'pieces', currentStock: 600, reorderLevel: 200 },
      { name: 'Semi Processed Fibre', category: InventoryCategory.SEMI_PROCESSED, unit: 'kg', currentStock: 780, reorderLevel: 250 },
      { name: 'Detergent', category: InventoryCategory.CHEMICAL, unit: 'litres', currentStock: 120, reorderLevel: 80 },
    ].map((item) => manager.create(InventoryItem, item)),
  );

  const movements: Partial<StockMovement>[] = [];
  for (let index = 0; index < 500; index += 1) {
    const item = inventoryItems[index % inventoryItems.length];
    const type = index % 3 === 0 ? StockMovementType.IN : index % 5 === 0 ? StockMovementType.OUT : StockMovementType.ADJUSTMENT;
    const quantity = type === StockMovementType.OUT ? 10 + (index % 5) * 4 : 12 + (index % 6) * 3;
    const createdAt = new Date();
    createdAt.setDate(createdAt.getDate() - (index % 30));
    movements.push({
      warehouse,
      item,
      type,
      quantity,
      reference: `TX-${String(index + 1).padStart(4, '0')}`,
      recordedBy: employees[index % employees.length],
      createdAt,
    });
  }

  await manager.save(StockMovement, movements.map((movement) => manager.create(StockMovement, movement)));
}
