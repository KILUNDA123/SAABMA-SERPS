import 'reflect-metadata';
import { DataSource } from 'typeorm';
import { config } from 'dotenv';
import { allEntities } from '../config/database.config';
import { seedCoreReferenceData } from './seed-core-reference-data';
import { seedEmployeesAndAttendance } from './seed-employees-and-attendance';
import { seedInventoryAndWarehouse } from './seed-inventory-and-warehouse';
import { seedCustomersSuppliersAndOrders } from './seed-customers-suppliers-orders';
import { seedInvoicesPaymentsAndNotifications } from './seed-invoices-payments-notifications';
import { seedAuditAndRevenue } from './seed-audit-and-revenue';

config();

async function bootstrap() {
  const dataSource = new DataSource({
    type: 'postgres',
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432', 10),
    username: process.env.DB_USER || 'saabma',
    password: process.env.DB_PASSWORD || 'changeme',
    database: process.env.DB_NAME || 'saabma_serps',
    entities: allEntities,
    synchronize: false,
    logging: false,
  });

  await dataSource.initialize();
  console.log('Connected to database');

  try {
    await dataSource.transaction(async (manager) => {
      // Full reset first: TRUNCATE ... CASCADE sidesteps FK-ordering issues
      // that plain DELETEs run in the wrong order (e.g. deleting
      // Department/Shift/User before the Employee rows that reference
      // them). Each seed file's own delete() calls become no-ops on the
      // now-empty tables, which is harmless.
      const tables: { tablename: string }[] = await manager.query(
        `SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tablename != 'migrations'`,
      );
      if (tables.length > 0) {
        const quoted = tables.map((t) => `"${t.tablename}"`).join(', ');
        await manager.query(`TRUNCATE TABLE ${quoted} RESTART IDENTITY CASCADE`);
      }

      await seedCoreReferenceData(manager);
      await seedEmployeesAndAttendance(manager);
      await seedInventoryAndWarehouse(manager);
      await seedCustomersSuppliersAndOrders(manager);
      await seedInvoicesPaymentsAndNotifications(manager);
      await seedAuditAndRevenue(manager);
    });

    console.log('Seeding completed successfully');
  } catch (error) {
    console.error('Seeding failed', error);
    process.exitCode = 1;
  } finally {
    await dataSource.destroy();
  }
}

bootstrap();
