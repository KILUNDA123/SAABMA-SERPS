import { EntityManager } from 'typeorm';
import { Customer } from '../modules/customers/entities/customer.entity';
import { Supplier } from '../modules/suppliers/entities/supplier.entity';
import { Order, OrderItem, OrderStatus } from '../modules/orders/entities/order.entity';
import { InventoryItem } from '../modules/inventory/entities/inventory-item.entity';

const customerNames = ['Nairobi Fibre Traders', 'Mombasa Export Hub', 'Kisumu Logistics Ltd', 'Athi River Industries', 'Rift Valley Cargo', 'Greenline Exports', 'Lamu Shipping Co', 'Bungoma Agro Supplies', 'Juja Packaging Group', 'Meru Textiles'];
const supplierNames = ['Coastal Chemicals Ltd', 'Highland Packaging Co', 'Sisal Growers Cooperative', 'Nakuru Logistics Supplies', 'Kisii Industrial Products', 'Maua Fibre Works'];

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export async function seedCustomersSuppliersAndOrders(manager: EntityManager): Promise<void> {
  await manager.createQueryBuilder().delete().from(OrderItem).execute();
  await manager.createQueryBuilder().delete().from(Order).execute();
  await manager.createQueryBuilder().delete().from(Customer).execute();
  await manager.createQueryBuilder().delete().from(Supplier).execute();

  const inventoryItems = await manager.find(InventoryItem, { order: { name: 'ASC' } });

  const customers = await manager.save(
    Customer,
    Array.from({ length: 40 }, (_, index) =>
      manager.create(Customer, {
        name: `${customerNames[index % customerNames.length]} ${index + 1}`,
        country: 'Kenya',
        email: `customer${index + 1}@example.co.ke`,
        phone: `+2547${String(randomInt(10000000, 99999999)).slice(0, 8)}`,
        outstandingBalance: Number((Math.random() * 500000).toFixed(2)),
      }),
    ),
  );

  const suppliers = await manager.save(
    Supplier,
    Array.from({ length: 25 }, (_, index) =>
      manager.create(Supplier, {
        name: `${supplierNames[index % supplierNames.length]} ${index + 1}`,
        contactPerson: `Contact ${index + 1}`,
        phone: `+2547${String(randomInt(10000000, 99999999)).slice(0, 8)}`,
        email: `supplier${index + 1}@example.co.ke`,
      }),
    ),
  );

  const orders: Partial<Order>[] = [];
  for (let index = 0; index < 300; index += 1) {
    const customer = customers[index % customers.length];
    const subtotal = randomInt(500000, 2500000);
    const order = manager.create(Order, {
      orderNumber: `ORD-${String(index + 1).padStart(5, '0')}`,
      customer,
      status: index % 4 === 0 ? OrderStatus.DRAFT : index % 4 === 1 ? OrderStatus.CONFIRMED : index % 4 === 2 ? OrderStatus.INVOICED : OrderStatus.CANCELLED,
      total: Number(subtotal.toFixed(2)),
      createdAt: new Date(Date.now() - randomInt(1, 45) * 24 * 60 * 60 * 1000),
    });
    orders.push(order);
  }

  const savedOrders = await manager.save(Order, orders);

  const orderItems: Partial<OrderItem>[] = [];
  savedOrders.forEach((order, index) => {
    const item = inventoryItems[index % inventoryItems.length];
    orderItems.push({
      order,
      inventoryItem: item,
      description: `${item.name} order line`,
      quantity: randomInt(5, 40),
      unitPrice: Number((randomInt(1000, 4000) / 100).toFixed(2)),
      lineTotal: Number((randomInt(1000, 4000) * randomInt(5, 40) / 100).toFixed(2)),
    });
  });

  await manager.save(OrderItem, orderItems.map((line) => manager.create(OrderItem, line)));
}
