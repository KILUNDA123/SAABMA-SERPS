import { EntityManager } from 'typeorm';
import { Invoice, InvoiceItem, InvoiceStatus } from '../modules/invoices/entities/invoice.entity';
import { Payment, PaymentMethod } from '../modules/payments/entities/payment.entity';
import { Customer } from '../modules/customers/entities/customer.entity';
import { InventoryItem } from '../modules/inventory/entities/inventory-item.entity';
import { Notification, NotificationType } from '../modules/notifications/entities/notification.entity';
import { User } from '../modules/users/entities/user.entity';

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export async function seedInvoicesPaymentsAndNotifications(manager: EntityManager): Promise<void> {
  await manager.createQueryBuilder().delete().from(InvoiceItem).execute();
  await manager.createQueryBuilder().delete().from(Payment).execute();
  await manager.createQueryBuilder().delete().from(Invoice).execute();
  await manager.createQueryBuilder().delete().from(Notification).execute();

  const customers = await manager.find(Customer, { order: { name: 'ASC' } });
  const inventoryItems = await manager.find(InventoryItem, { order: { name: 'ASC' } });
  const users = await manager.find(User, { order: { fullName: 'ASC' } });

  const invoicesToSave: Partial<Invoice>[] = [];
  for (let index = 0; index < 400; index += 1) {
    const customer = customers[index % customers.length];
    const invoiceDate = new Date();
    invoiceDate.setDate(invoiceDate.getDate() - randomInt(0, 90));
    invoicesToSave.push({
      invoiceNumber: `INV-${String(index + 1).padStart(5, '0')}`,
      customer,
      invoiceDate: invoiceDate.toISOString().slice(0, 10),
      subtotal: Number((randomInt(100000, 3000000) / 100).toFixed(2)),
      discount: Number((randomInt(0, 10000) / 100).toFixed(2)),
      tax: Number((randomInt(10000, 150000) / 100).toFixed(2)),
      total: Number((randomInt(150000, 3500000) / 100).toFixed(2)),
      status: index % 4 === 0 ? InvoiceStatus.SENT : index % 4 === 1 ? InvoiceStatus.PAID : index % 4 === 2 ? InvoiceStatus.OVERDUE : InvoiceStatus.DRAFT,
    });
  }

  const invoices = await manager.save(Invoice, invoicesToSave.map((invoice) => manager.create(Invoice, invoice)));

  const invoiceItems: Partial<InvoiceItem>[] = [];
  invoices.forEach((invoice, index) => {
    const item = inventoryItems[index % inventoryItems.length];
    invoiceItems.push({
      invoice,
      description: `${item.name} invoice line`,
      inventoryItem: item,
      quantity: randomInt(2, 25),
      unitPrice: Number((randomInt(1000, 5500) / 100).toFixed(2)),
      lineTotal: Number((randomInt(2000, 120000) / 100).toFixed(2)),
    });
  });
  await manager.save(InvoiceItem, invoiceItems.map((line) => manager.create(InvoiceItem, line)));

  const payments: Partial<Payment>[] = [];
  for (let index = 0; index < 350; index += 1) {
    const invoice = invoices[index % invoices.length];
    const paidOn = new Date();
    paidOn.setDate(paidOn.getDate() - randomInt(0, 60));
    payments.push({
      invoice,
      customer: invoice.customer,
      amount: Number((randomInt(10000, 500000) / 100).toFixed(2)),
      method: index % 4 === 0 ? PaymentMethod.CASH : index % 4 === 1 ? PaymentMethod.BANK_TRANSFER : index % 4 === 2 ? PaymentMethod.MOBILE_MONEY : PaymentMethod.CHEQUE,
      paidOn: paidOn.toISOString().slice(0, 10),
      reference: `REF-${String(index + 1).padStart(5, '0')}`,
    });
  }
  await manager.save(Payment, payments.map((payment) => manager.create(Payment, payment)));

  const notifications: Partial<Notification>[] = [];
  for (let index = 0; index < 80; index += 1) {
    const user = users[index % users.length];
    notifications.push({
      recipient: user,
      type: index % 4 === 0 ? NotificationType.LOW_STOCK : index % 4 === 1 ? NotificationType.ATTENDANCE_MISSING : index % 4 === 2 ? NotificationType.APPROVAL_NEEDED : NotificationType.GENERAL,
      message: `Automated notification ${index + 1} generated for ${user.fullName}`,
      linkRef: '/dashboard',
      isRead: Math.random() > 0.5,
    });
  }
  await manager.save(Notification, notifications.map((notification) => manager.create(Notification, notification)));
}
