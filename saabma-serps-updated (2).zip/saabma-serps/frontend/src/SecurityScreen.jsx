import React, { useEffect, useState } from "react";
import { Loader2, ShieldAlert, Monitor, Smartphone, Tablet, HelpCircle, KeyRound, Lock, Unlock, Ban, CheckCircle2 } from "lucide-react";
import { apiGet, apiPost, apiPatch } from "./api";

/* ------------------------------------------------------------------
   Mirrors the real backend exactly (CEO/ADMIN only for all of this):
     GET   /login-events               login monitoring dashboard
     GET   /users                      account list
     POST  /users/:id/reset-password   generates a temp password
     PATCH /users/:id/status           active | suspended | inactive | locked

   No "current session status" or logout time here - the backend issues
   stateless JWTs with no session table, so there's no real signal for
   "is this person online right now" to show. Showing one would be
   fabricated. Login time, IP, device, and location are all real.
------------------------------------------------------------------- */

const DEVICE_ICON = { Mobile: Smartphone, Tablet: Tablet, Desktop: Monitor, Unknown: HelpCircle };

const STATUS_TONE = {
  active: { bg: "rgba(47,107,60,0.12)", color: "var(--plantation)" },
  suspended: { bg: "rgba(165,78,42,0.12)", color: "var(--danger)" },
  inactive: { bg: "var(--divider)", color: "var(--slate)" },
  locked: { bg: "rgba(226,163,61,0.15)", color: "#9C6A1E" },
  pending_first_login: { bg: "rgba(11,53,88,0.10)", color: "var(--ocean-navy)" },
};

export default function SecurityScreen({ token }) {
  const [tab, setTab] = useState("monitoring");
  const [events, setEvents] = useState(null);
  const [users, setUsers] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [actionFor, setActionFor] = useState(null);
  const [resetResult, setResetResult] = useState(null);
  const [err, setErr] = useState("");

  async function load() {
    try {
      const [ev, us] = await Promise.all([apiGet("/login-events", token), apiGet("/users", token)]);
      setEvents(ev);
      setUsers(us);
      setUsingDemo(false);
    } catch {
      setEvents(MOCK_EVENTS);
      setUsers(MOCK_USERS);
      setUsingDemo(true);
    }
  }

  useEffect(() => { load(); }, []);

  async function handleReset(id) {
    setErr("");
    try {
      const result = await apiPost(`/users/${id}/reset-password`, {}, token);
      setResetResult({ id, temporaryPassword: result.temporaryPassword });
    } catch (e) {
      setErr(e.message || "Could not reset password");
    }
  }

  async function handleStatus(id, status) {
    setErr("");
    try {
      await apiPatch(`/users/${id}/status`, { status }, token);
      setActionFor(null);
      load();
    } catch (e) {
      setErr(e.message || "Could not update account status");
    }
  }

  if (!events || !users) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="animate-spin" size={20} style={{ color: "var(--sisal)" }} />
      </div>
    );
  }

  return (
    <div>
      <div className="mb-5">
        <h1 className="font-display font-semibold text-xl flex items-center gap-2">
          <ShieldAlert size={19} style={{ color: "var(--neutral-gray)" }} /> Security
        </h1>
        <p className="text-sm mt-0.5" style={{ color: "var(--slate)" }}>
          Login monitoring and account access control
          {usingDemo && <span className="font-mono text-[10px] px-2 py-0.5 rounded-full ml-2" style={{ background: "rgba(226,163,61,0.15)", color: "#9C6A1E" }}>DEMO DATA</span>}
        </p>
      </div>

      {err && <p className="text-sm mb-3" style={{ color: "var(--danger)" }}>{err}</p>}

      <div className="flex gap-1.5 mb-5 border-b" style={{ borderColor: "var(--border)" }}>
        {[{ key: "monitoring", label: `Login activity (${events.length})` }, { key: "accounts", label: `Accounts (${users.length})` }].map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className="px-3 py-2 text-sm font-medium border-b-2 -mb-px"
            style={{ borderColor: tab === t.key ? "var(--sisal)" : "transparent", color: tab === t.key ? "var(--ink)" : "var(--slate)" }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "monitoring" ? (
        <div className="rounded-xl overflow-hidden" style={{ border: "1px solid var(--border)", background: "#FFFFFF" }}>
          <table className="w-full text-sm">
            <thead>
              <tr style={{ background: "var(--surface-tint)" }}>
                {["Employee", "Role", "Login time", "IP", "Location", "Device"].map((h) => (
                  <th key={h} className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {events.map((e) => {
                const DevIcon = DEVICE_ICON[e.deviceType] || HelpCircle;
                return (
                  <tr key={e.id} style={{ borderTop: "1px solid var(--divider)" }}>
                    <td className="px-4 py-2.5">
                      <div className="font-medium">{e.fullName}</div>
                      <div className="font-mono text-[11px]" style={{ color: "var(--slate)" }}>{e.employeeId}</div>
                    </td>
                    <td className="px-4 py-2.5 capitalize" style={{ color: "var(--slate)" }}>{(e.role || "").replace(/_/g, " ")}</td>
                    <td className="px-4 py-2.5" style={{ color: "var(--slate)" }}>{new Date(e.loginTime).toLocaleString("en-KE")}</td>
                    <td className="px-4 py-2.5 font-mono text-xs">{e.ipAddress || "—"}</td>
                    <td className="px-4 py-2.5 text-xs" style={{ color: "var(--slate)" }}>
                      {e.resolvedAddress || `${Number(e.latitude).toFixed(3)}, ${Number(e.longitude).toFixed(3)}`}
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-1.5 text-xs" style={{ color: "var(--slate)" }}>
                        <DevIcon size={13} /> {e.deviceType} · {e.browser}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="rounded-xl overflow-hidden" style={{ border: "1px solid var(--border)", background: "#FFFFFF" }}>
          <table className="w-full text-sm">
            <thead>
              <tr style={{ background: "var(--surface-tint)" }}>
                {["Employee", "Role", "Status", "Failed attempts", ""].map((h) => (
                  <th key={h} className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {users.map((u) => {
                const tone = STATUS_TONE[u.accountStatus] || STATUS_TONE.active;
                return (
                  <React.Fragment key={u.id}>
                    <tr style={{ borderTop: "1px solid var(--divider)" }}>
                      <td className="px-4 py-2.5">
                        <div className="font-medium">{u.fullName}</div>
                        <div className="font-mono text-[11px]" style={{ color: "var(--slate)" }}>{u.employeeId}</div>
                      </td>
                      <td className="px-4 py-2.5 capitalize" style={{ color: "var(--slate)" }}>{(u.role || "").replace(/_/g, " ")}</td>
                      <td className="px-4 py-2.5">
                        <span className="font-mono text-[10px] px-2 py-0.5 rounded-full uppercase" style={{ background: tone.bg, color: tone.color }}>
                          {u.accountStatus.replace(/_/g, " ")}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 font-mono">{u.failedLoginAttempts}</td>
                      <td className="px-4 py-2.5 text-right">
                        <button onClick={() => setActionFor(actionFor === u.id ? null : u.id)} className="text-xs font-medium" style={{ color: "var(--ocean-navy)" }}>
                          Manage
                        </button>
                      </td>
                    </tr>
                    {actionFor === u.id && (
                      <tr style={{ background: "var(--surface-tint)" }}>
                        <td colSpan={5} className="px-4 py-3">
                          <div className="flex flex-wrap items-center gap-2">
                            <button onClick={() => handleReset(u.id)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white" style={{ background: "var(--ocean-navy)" }}>
                              <KeyRound size={13} /> Reset password
                            </button>
                            <button onClick={() => handleStatus(u.id, "active")} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium" style={{ background: "rgba(47,107,60,0.12)", color: "var(--plantation)" }}>
                              <CheckCircle2 size={13} /> Activate / unlock
                            </button>
                            <button onClick={() => handleStatus(u.id, "suspended")} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium" style={{ background: "rgba(165,78,42,0.12)", color: "var(--danger)" }}>
                              <Ban size={13} /> Suspend
                            </button>
                            <button onClick={() => handleStatus(u.id, "inactive")} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium" style={{ background: "var(--divider)", color: "var(--slate)" }}>
                              <Lock size={13} /> Mark inactive
                            </button>
                          </div>
                          {resetResult?.id === u.id && (
                            <div className="mt-2.5 px-3 py-2 rounded-lg text-xs" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
                              Temporary password (share securely, shown once): <span className="font-mono font-medium">{resetResult.temporaryPassword}</span>
                            </div>
                          )}
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

const MOCK_EVENTS = [
  { id: "l1", employeeId: "SERP/EXE/001", fullName: "Cynthia Mwangi", role: "ceo", loginTime: new Date().toISOString(), ipAddress: "41.90.64.12", latitude: -1.2864, longitude: 36.8172, resolvedAddress: null, deviceType: "Desktop", os: "macOS", browser: "Chrome" },
  { id: "l2", employeeId: "SERP/EMP/003", fullName: "Salim Kibet", role: "warehouse", loginTime: new Date(Date.now() - 3600000).toISOString(), ipAddress: "41.90.64.44", latitude: -1.29, longitude: 36.82, resolvedAddress: null, deviceType: "Mobile", os: "Android", browser: "Chrome" },
];

const MOCK_USERS = [
  { id: "u1", employeeId: "SERP/EXE/001", fullName: "Cynthia Mwangi", role: "ceo", accountStatus: "active", failedLoginAttempts: 0 },
  { id: "u2", employeeId: "SERP/EMP/003", fullName: "Salim Kibet", role: "warehouse", accountStatus: "locked", failedLoginAttempts: 5 },
];
