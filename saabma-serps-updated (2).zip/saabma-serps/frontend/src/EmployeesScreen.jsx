import React, { useEffect, useState } from "react";
import { UserPlus, Fingerprint, Loader2, X } from "lucide-react";
import { apiGet, apiPost, apiPatch } from "./api";

/* ------------------------------------------------------------------
   Mirrors backend/src/modules/employees exactly:
     GET  /employees
     GET  /employees/:id
     POST /employees              { employeeCode, fullName, position?, dailyRate }
     PATCH /employees/:id/fingerprint  { fingerprintTemplateId }
   NOTE: CreateEmployeeDto has no department/shift field yet — the
   Employee entity supports both (via Department/Shift relations) but
   there's no /departments or /shifts controller exposing IDs to pick
   from, and the DTO doesn't accept them. Until that's added on the
   backend, department/shift assignment isn't wireable from here — it
   isn't included in this form so as not to fake a field that does
   nothing.
------------------------------------------------------------------- */

const MOCK_EMPLOYEES = [
  { id: "e1", employeeCode: "EMP-014", fullName: "Peter Kiptoo", position: "Baling operator", dailyRate: 850, isActive: true, fingerprintTemplateId: "FP-2291" },
  { id: "e2", employeeCode: "EMP-028", fullName: "Grace Muthoni", position: "Washing supervisor", dailyRate: 1100, isActive: true, fingerprintTemplateId: null },
  { id: "e3", employeeCode: "EMP-007", fullName: "Samuel Otieno", position: "Drying operator", dailyRate: 850, isActive: true, fingerprintTemplateId: "FP-1187" },
  { id: "e4", employeeCode: "EMP-041", fullName: "Faith Nyambura", position: "Warehouse clerk", dailyRate: 900, isActive: false, fingerprintTemplateId: null },
];

function Badge({ children, tone = "neutral" }) {
  const tones = {
    neutral: { bg: "var(--divider)", color: "var(--slate)" },
    approved: { bg: "rgba(47,107,60,0.15)", color: "var(--sisal-deep)" },
    pending: { bg: "rgba(226,163,61,0.15)", color: "#9C6A1E" },
    rejected: { bg: "rgba(165,78,42,0.12)", color: "var(--danger)" },
  };
  const t = tones[tone] || tones.neutral;
  return (
    <span className="font-mono text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wide" style={{ background: t.bg, color: t.color }}>
      {children}
    </span>
  );
}

export default function EmployeesScreen({ token }) {
  const [employees, setEmployees] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ employeeCode: "", fullName: "", position: "", dailyRate: "" });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");
  const [enrollingFor, setEnrollingFor] = useState(null);
  const [fpValue, setFpValue] = useState("");

  async function load() {
    try {
      const list = await apiGet("/employees", token);
      setEmployees(list);
      setUsingDemo(false);
    } catch {
      setEmployees(MOCK_EMPLOYEES);
      setUsingDemo(true);
    }
  }

  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    setErr("");
    try {
      await apiPost("/employees", {
        employeeCode: form.employeeCode,
        fullName: form.fullName,
        position: form.position || undefined,
        dailyRate: Number(form.dailyRate) || 0,
      }, token);
      setForm({ employeeCode: "", fullName: "", position: "", dailyRate: "" });
      setShowForm(false);
      load();
    } catch (e2) {
      setErr(e2.message || "Could not save employee");
    } finally {
      setSaving(false);
    }
  }

  async function handleEnroll(id) {
    if (!fpValue.trim()) return;
    try {
      await apiPatch(`/employees/${id}/fingerprint`, { fingerprintTemplateId: fpValue.trim() }, token);
      setEnrollingFor(null);
      setFpValue("");
      load();
    } catch (e2) {
      setErr(e2.message || "Could not enroll fingerprint");
    }
  }

  if (!employees) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="animate-spin" size={20} style={{ color: "var(--sisal)" }} />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="font-display font-semibold text-xl">Employees</h1>
          <p className="text-sm mt-0.5" style={{ color: "var(--slate)" }}>
            {employees.length} on record
            {usingDemo && <span className="font-mono text-[10px] px-2 py-0.5 rounded-full ml-2" style={{ background: "rgba(226,163,61,0.15)", color: "#9C6A1E" }}>DEMO DATA</span>}
          </p>
        </div>
        <button
          onClick={() => setShowForm((v) => !v)}
          className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium text-white"
          style={{ background: "var(--fibre-black)" }}
        >
          <UserPlus size={15} /> New employee
        </button>
      </div>

      {err && <p className="text-sm mb-3" style={{ color: "var(--danger)" }}>{err}</p>}

      {showForm && (
        <form onSubmit={handleCreate} className="rounded-xl p-5 mb-5 flex flex-col gap-3.5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
          <div className="grid grid-cols-2 gap-3">
            <input required placeholder="Employee code (EMP-0042)" value={form.employeeCode}
              onChange={(e) => setForm({ ...form, employeeCode: e.target.value })}
              className="px-3 py-2 rounded-lg text-sm" style={{ border: "1px solid var(--border)" }} />
            <input required placeholder="Full name" value={form.fullName}
              onChange={(e) => setForm({ ...form, fullName: e.target.value })}
              className="px-3 py-2 rounded-lg text-sm" style={{ border: "1px solid var(--border)" }} />
            <input placeholder="Position" value={form.position}
              onChange={(e) => setForm({ ...form, position: e.target.value })}
              className="px-3 py-2 rounded-lg text-sm" style={{ border: "1px solid var(--border)" }} />
            <input required type="number" min="0" placeholder="Daily rate (KES)" value={form.dailyRate}
              onChange={(e) => setForm({ ...form, dailyRate: e.target.value })}
              className="px-3 py-2 rounded-lg text-sm" style={{ border: "1px solid var(--border)" }} />
          </div>
          <div className="flex gap-2">
            <button disabled={saving} type="submit" className="px-3.5 py-2 rounded-lg text-sm font-medium text-white" style={{ background: "var(--sisal-deep)" }}>
              {saving ? "Saving…" : "Save employee"}
            </button>
            <button type="button" onClick={() => setShowForm(false)} className="px-3.5 py-2 rounded-lg text-sm font-medium" style={{ color: "var(--slate)" }}>
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="rounded-xl overflow-hidden" style={{ border: "1px solid var(--border)", background: "#FFFFFF" }}>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: "var(--surface-tint)" }}>
              {["Code", "Name", "Position", "Daily rate", "Status", "Fingerprint", ""].map((h) => (
                <th key={h} className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {employees.map((emp) => (
              <React.Fragment key={emp.id}>
                <tr style={{ borderTop: "1px solid var(--divider)" }}>
                  <td className="px-4 py-2.5 font-mono text-xs">{emp.employeeCode}</td>
                  <td className="px-4 py-2.5 font-medium">{emp.fullName}</td>
                  <td className="px-4 py-2.5" style={{ color: "var(--slate)" }}>{emp.position || "—"}</td>
                  <td className="px-4 py-2.5 font-mono">{new Intl.NumberFormat("en-KE").format(emp.dailyRate)}</td>
                  <td className="px-4 py-2.5"><Badge tone={emp.isActive ? "approved" : "neutral"}>{emp.isActive ? "Active" : "Inactive"}</Badge></td>
                  <td className="px-4 py-2.5">
                    <Badge tone={emp.fingerprintTemplateId ? "approved" : "pending"}>
                      {emp.fingerprintTemplateId ? "Enrolled" : "Not enrolled"}
                    </Badge>
                  </td>
                  <td className="px-4 py-2.5 text-right">
                    <button
                      onClick={() => { setEnrollingFor(enrollingFor === emp.id ? null : emp.id); setFpValue(""); }}
                      className="inline-flex items-center gap-1.5 text-xs font-medium"
                      style={{ color: "var(--sisal-deep)" }}
                    >
                      <Fingerprint size={13} /> {emp.fingerprintTemplateId ? "Re-enroll" : "Enroll"}
                    </button>
                  </td>
                </tr>
                {enrollingFor === emp.id && (
                  <tr style={{ background: "var(--surface-tint)" }}>
                    <td colSpan={7} className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <input
                          autoFocus
                          placeholder="Fingerprint template ID from scanner (e.g. FP-3391)"
                          value={fpValue}
                          onChange={(e) => setFpValue(e.target.value)}
                          className="px-3 py-1.5 rounded-lg text-sm flex-1"
                          style={{ border: "1px solid var(--border)" }}
                        />
                        <button onClick={() => handleEnroll(emp.id)} className="px-3 py-1.5 rounded-lg text-xs font-medium text-white" style={{ background: "var(--sisal-deep)" }}>
                          Save
                        </button>
                        <button onClick={() => setEnrollingFor(null)} style={{ color: "var(--slate)" }}><X size={16} /></button>
                      </div>
                      <p className="text-[11px] mt-1.5" style={{ color: "var(--paper-dim)" }}>
                        This links the ID your fingerprint device already assigned this person — it doesn't capture a scan itself (that needs the physical enrollment reader wired to the door controller).
                      </p>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
