import React, { useEffect, useState } from "react";
import { Truck, UserRound, Plus, Loader2 } from "lucide-react";
import { apiGet, apiPost } from "./api";

/* ------------------------------------------------------------------
   Mirrors backend/src/modules/vehicles exactly:
     POST /vehicles   { plateNumber, type?, capacityKg? }
     GET  /vehicles
     POST /drivers     { fullName, licenseNumber?, phone?, userId? }
     GET  /drivers
     GET  /drivers/:id

   No GPS tracking here — there's no device/telemetry integration on the
   backend yet (Vehicle/Driver entities carry no location fields), so
   this is a registry, not a live tracking map. Building a map for
   coordinates that don't exist would just be a decoration.
------------------------------------------------------------------- */

const MOCK_VEHICLES = [
  { id: "v1", plateNumber: "KDA 221F", type: "Truck", capacityKg: 12000, createdAt: new Date().toISOString() },
  { id: "v2", plateNumber: "KDB 884T", type: "Container trailer", capacityKg: 28000, createdAt: new Date().toISOString() },
];

const MOCK_DRIVERS = [
  { id: "d1", fullName: "James Mutua", licenseNumber: "DL-88213", phone: "+254 712 334 210" },
  { id: "d2", fullName: "Esther Wambui", licenseNumber: "DL-77401", phone: "+254 733 908 442" },
];

function Field({ children }) {
  return <div className="px-3 py-2 rounded-lg text-sm flex-1" style={{ border: "1px solid var(--border)" }}>{children}</div>;
}

export default function FleetScreen({ token }) {
  const [tab, setTab] = useState("vehicles");
  const [vehicles, setVehicles] = useState(null);
  const [drivers, setDrivers] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [vForm, setVForm] = useState({ plateNumber: "", type: "", capacityKg: "" });
  const [dForm, setDForm] = useState({ fullName: "", licenseNumber: "", phone: "" });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  async function load() {
    try {
      const [v, d] = await Promise.all([apiGet("/vehicles", token), apiGet("/drivers", token)]);
      setVehicles(v);
      setDrivers(d);
      setUsingDemo(false);
    } catch {
      setVehicles(MOCK_VEHICLES);
      setDrivers(MOCK_DRIVERS);
      setUsingDemo(true);
    }
  }

  useEffect(() => { load(); }, []);

  async function handleAddVehicle(e) {
    e.preventDefault();
    setSaving(true);
    setErr("");
    try {
      await apiPost("/vehicles", {
        plateNumber: vForm.plateNumber,
        type: vForm.type || undefined,
        capacityKg: vForm.capacityKg ? Number(vForm.capacityKg) : undefined,
      }, token);
      setVForm({ plateNumber: "", type: "", capacityKg: "" });
      setShowForm(false);
      load();
    } catch (e2) {
      setErr(e2.message || "Could not save vehicle");
    } finally {
      setSaving(false);
    }
  }

  async function handleAddDriver(e) {
    e.preventDefault();
    setSaving(true);
    setErr("");
    try {
      await apiPost("/drivers", {
        fullName: dForm.fullName,
        licenseNumber: dForm.licenseNumber || undefined,
        phone: dForm.phone || undefined,
      }, token);
      setDForm({ fullName: "", licenseNumber: "", phone: "" });
      setShowForm(false);
      load();
    } catch (e2) {
      setErr(e2.message || "Could not save driver");
    } finally {
      setSaving(false);
    }
  }

  if (!vehicles || !drivers) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="animate-spin" size={20} style={{ color: "var(--sisal)" }} />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="font-display font-semibold text-xl">Fleet</h1>
          <p className="text-sm mt-0.5" style={{ color: "var(--slate)" }}>
            {vehicles.length} vehicles · {drivers.length} drivers
            {usingDemo && <span className="font-mono text-[10px] px-2 py-0.5 rounded-full ml-2" style={{ background: "rgba(226,163,61,0.15)", color: "#9C6A1E" }}>DEMO DATA</span>}
          </p>
        </div>
        <button
          onClick={() => setShowForm((v) => !v)}
          className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium text-white"
          style={{ background: "var(--fibre-black)" }}
        >
          <Plus size={15} /> {tab === "vehicles" ? "New vehicle" : "New driver"}
        </button>
      </div>

      {err && <p className="text-sm mb-3" style={{ color: "var(--danger)" }}>{err}</p>}

      <div className="flex gap-1.5 mb-5 border-b" style={{ borderColor: "var(--border)" }}>
        {[{ key: "vehicles", label: `Vehicles (${vehicles.length})`, icon: Truck }, { key: "drivers", label: `Drivers (${drivers.length})`, icon: UserRound }].map((t) => (
          <button
            key={t.key}
            onClick={() => { setTab(t.key); setShowForm(false); }}
            className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium border-b-2 -mb-px"
            style={{ borderColor: tab === t.key ? "var(--sisal)" : "transparent", color: tab === t.key ? "var(--ink)" : "var(--slate)" }}
          >
            <t.icon size={14} /> {t.label}
          </button>
        ))}
      </div>

      {showForm && tab === "vehicles" && (
        <form onSubmit={handleAddVehicle} className="rounded-xl p-5 mb-5 flex flex-col gap-3.5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
          <div className="grid grid-cols-3 gap-3">
            <input required placeholder="Plate number (KDA 221F)" value={vForm.plateNumber}
              onChange={(e) => setVForm({ ...vForm, plateNumber: e.target.value })}
              className="px-3 py-2 rounded-lg text-sm" style={{ border: "1px solid var(--border)" }} />
            <input placeholder="Type (truck, trailer…)" value={vForm.type}
              onChange={(e) => setVForm({ ...vForm, type: e.target.value })}
              className="px-3 py-2 rounded-lg text-sm" style={{ border: "1px solid var(--border)" }} />
            <input type="number" min="0" placeholder="Capacity (kg)" value={vForm.capacityKg}
              onChange={(e) => setVForm({ ...vForm, capacityKg: e.target.value })}
              className="px-3 py-2 rounded-lg text-sm" style={{ border: "1px solid var(--border)" }} />
          </div>
          <div className="flex gap-2">
            <button disabled={saving} type="submit" className="px-3.5 py-2 rounded-lg text-sm font-medium text-white" style={{ background: "var(--sisal-deep)" }}>
              {saving ? "Saving…" : "Save vehicle"}
            </button>
            <button type="button" onClick={() => setShowForm(false)} className="px-3.5 py-2 rounded-lg text-sm font-medium" style={{ color: "var(--slate)" }}>Cancel</button>
          </div>
        </form>
      )}

      {showForm && tab === "drivers" && (
        <form onSubmit={handleAddDriver} className="rounded-xl p-5 mb-5 flex flex-col gap-3.5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
          <div className="grid grid-cols-3 gap-3">
            <input required placeholder="Full name" value={dForm.fullName}
              onChange={(e) => setDForm({ ...dForm, fullName: e.target.value })}
              className="px-3 py-2 rounded-lg text-sm" style={{ border: "1px solid var(--border)" }} />
            <input placeholder="License number" value={dForm.licenseNumber}
              onChange={(e) => setDForm({ ...dForm, licenseNumber: e.target.value })}
              className="px-3 py-2 rounded-lg text-sm" style={{ border: "1px solid var(--border)" }} />
            <input placeholder="Phone" value={dForm.phone}
              onChange={(e) => setDForm({ ...dForm, phone: e.target.value })}
              className="px-3 py-2 rounded-lg text-sm" style={{ border: "1px solid var(--border)" }} />
          </div>
          <div className="flex gap-2">
            <button disabled={saving} type="submit" className="px-3.5 py-2 rounded-lg text-sm font-medium text-white" style={{ background: "var(--sisal-deep)" }}>
              {saving ? "Saving…" : "Save driver"}
            </button>
            <button type="button" onClick={() => setShowForm(false)} className="px-3.5 py-2 rounded-lg text-sm font-medium" style={{ color: "var(--slate)" }}>Cancel</button>
          </div>
        </form>
      )}

      <div className="rounded-xl overflow-hidden" style={{ border: "1px solid var(--border)", background: "#FFFFFF" }}>
        {tab === "vehicles" ? (
          <table className="w-full text-sm">
            <thead>
              <tr style={{ background: "var(--surface-tint)" }}>
                {["Plate", "Type", "Capacity", "Added"].map((h) => (
                  <th key={h} className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {vehicles.map((v) => (
                <tr key={v.id} style={{ borderTop: "1px solid var(--divider)" }}>
                  <td className="px-4 py-2.5 font-mono text-xs font-medium">{v.plateNumber}</td>
                  <td className="px-4 py-2.5" style={{ color: "var(--slate)" }}>{v.type || "—"}</td>
                  <td className="px-4 py-2.5 font-mono">{v.capacityKg ? `${new Intl.NumberFormat("en-KE").format(v.capacityKg)} kg` : "—"}</td>
                  <td className="px-4 py-2.5" style={{ color: "var(--paper-dim)" }}>{new Date(v.createdAt).toLocaleDateString("en-KE")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr style={{ background: "var(--surface-tint)" }}>
                {["Name", "License", "Phone"].map((h) => (
                  <th key={h} className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {drivers.map((d) => (
                <tr key={d.id} style={{ borderTop: "1px solid var(--divider)" }}>
                  <td className="px-4 py-2.5 font-medium">{d.fullName}</td>
                  <td className="px-4 py-2.5 font-mono text-xs" style={{ color: "var(--slate)" }}>{d.licenseNumber || "—"}</td>
                  <td className="px-4 py-2.5" style={{ color: "var(--slate)" }}>{d.phone || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
