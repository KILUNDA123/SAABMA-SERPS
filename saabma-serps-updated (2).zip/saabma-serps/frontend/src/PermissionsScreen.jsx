import React, { useEffect, useState } from "react";
import { Loader2, X, Plus, ShieldCheck } from "lucide-react";
import { apiGet, apiPost } from "./api";
import { API_BASE_URL } from "./api";

/* ------------------------------------------------------------------
   Mirrors backend/src/modules/permissions exactly (admin/CEO only):
     GET    /permissions                list every permission that exists
     GET    /permissions/role/:role      permissions granted to one role
     POST   /permissions/grant           { role, code, description? }
     DELETE /permissions/revoke/:role/:code

   This is the fine-grained layer *on top of* the 11 broad UserRole
   values (ceo, operations_manager, supervisor, production_operator,
   warehouse, finance, hr, sales, driver, security, admin) — for cases
   where the broad role isn't specific enough (e.g. "can approve
   production" vs "can view finance").
------------------------------------------------------------------- */

const ROLES = [
  "ceo", "operations_manager", "supervisor", "production_operator",
  "warehouse", "finance", "hr", "sales", "driver", "security", "admin", "casual_worker",
];

const MOCK_ALL_PERMISSIONS = [
  { id: "p1", code: "production.approve", description: "Approve production stage records" },
  { id: "p2", code: "finance.view", description: "View finance figures and invoices" },
  { id: "p3", code: "warehouse.dispatch", description: "Dispatch stock from warehouse" },
  { id: "p4", code: "reports.export", description: "Export reports as CSV/Excel/PDF" },
];

const MOCK_ROLE_PERMISSIONS = {
  supervisor: [MOCK_ALL_PERMISSIONS[0]],
  finance: [MOCK_ALL_PERMISSIONS[1], MOCK_ALL_PERMISSIONS[3]],
};

// DELETE requests aren't in api.js's helper set (only GET/POST/PATCH), so
// this screen makes the one DELETE call directly against the same base URL.
async function apiDelete(path, token) {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${token || ""}` },
  });
  if (!res.ok) {
    const payload = await res.json().catch(() => null);
    throw new Error(payload?.message || `Request failed (${res.status})`);
  }
  return res.json().catch(() => null);
}

export default function PermissionsScreen({ token }) {
  const [allPermissions, setAllPermissions] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [selectedRole, setSelectedRole] = useState("supervisor");
  const [rolePermissions, setRolePermissions] = useState(null);
  const [newCode, setNewCode] = useState("");
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  async function loadAll() {
    try {
      const list = await apiGet("/permissions", token);
      setAllPermissions(list);
      setUsingDemo(false);
    } catch {
      setAllPermissions(MOCK_ALL_PERMISSIONS);
      setUsingDemo(true);
    }
  }

  async function loadRole(role) {
    setRolePermissions(null);
    try {
      const list = await apiGet(`/permissions/role/${role}`, token);
      setRolePermissions(list);
    } catch {
      setRolePermissions(MOCK_ROLE_PERMISSIONS[role] || []);
    }
  }

  useEffect(() => { loadAll(); }, []);
  useEffect(() => { loadRole(selectedRole); }, [selectedRole]);

  async function handleGrant(e) {
    e.preventDefault();
    if (!newCode.trim()) return;
    setSaving(true);
    setErr("");
    try {
      await apiPost("/permissions/grant", { role: selectedRole, code: newCode.trim() }, token);
      setNewCode("");
      await Promise.all([loadAll(), loadRole(selectedRole)]);
    } catch (e2) {
      setErr(e2.message || "Could not grant permission");
    } finally {
      setSaving(false);
    }
  }

  async function handleRevoke(code) {
    try {
      await apiDelete(`/permissions/revoke/${selectedRole}/${code}`, token);
      loadRole(selectedRole);
    } catch (e2) {
      setErr(e2.message || "Could not revoke permission");
    }
  }

  if (!allPermissions) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="animate-spin" size={20} style={{ color: "var(--sisal)" }} />
      </div>
    );
  }

  const grantedCodes = new Set((rolePermissions || []).map((p) => p.code));

  return (
    <div>
      <div className="mb-5">
        <h1 className="font-display font-semibold text-xl flex items-center gap-2">
          <ShieldCheck size={19} style={{ color: "var(--neutral-gray)" }} /> Permissions
        </h1>
        <p className="text-sm mt-0.5" style={{ color: "var(--slate)" }}>
          Fine-grained access on top of each user's role
          {usingDemo && <span className="font-mono text-[10px] px-2 py-0.5 rounded-full ml-2" style={{ background: "rgba(226,163,61,0.15)", color: "#9C6A1E" }}>DEMO DATA</span>}
        </p>
      </div>

      {err && <p className="text-sm mb-3" style={{ color: "var(--danger)" }}>{err}</p>}

      <div className="flex gap-1.5 mb-5 flex-wrap">
        {ROLES.map((r) => (
          <button
            key={r}
            onClick={() => setSelectedRole(r)}
            className="px-3 py-1.5 rounded-full text-xs font-medium capitalize"
            style={{
              background: selectedRole === r ? "var(--fibre-black)" : "var(--divider)",
              color: selectedRole === r ? "#FFFFFF" : "var(--slate)",
            }}
          >
            {r.replace(/_/g, " ")}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-5">
        <div className="rounded-xl p-5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
          <p className="font-display font-semibold text-sm mb-3 capitalize">
            Granted to {selectedRole.replace(/_/g, " ")}
          </p>
          {!rolePermissions ? (
            <Loader2 className="animate-spin" size={16} style={{ color: "var(--sisal)" }} />
          ) : rolePermissions.length === 0 ? (
            <p className="text-sm" style={{ color: "var(--slate)" }}>No fine-grained permissions granted yet — this role relies on its broad access level only.</p>
          ) : (
            <div className="flex flex-col gap-2">
              {rolePermissions.map((p) => (
                <div key={p.code} className="flex items-center justify-between px-3 py-2 rounded-lg" style={{ background: "var(--surface-tint)" }}>
                  <div>
                    <p className="font-mono text-xs font-medium">{p.code}</p>
                    {p.description && <p className="text-[11px] mt-0.5" style={{ color: "var(--slate)" }}>{p.description}</p>}
                  </div>
                  <button onClick={() => handleRevoke(p.code)} style={{ color: "var(--danger)" }} aria-label="Revoke">
                    <X size={15} />
                  </button>
                </div>
              ))}
            </div>
          )}

          <form onSubmit={handleGrant} className="flex gap-2 mt-4">
            <input
              placeholder="e.g. production.approve"
              value={newCode}
              onChange={(e) => setNewCode(e.target.value)}
              className="px-3 py-2 rounded-lg text-sm flex-1 font-mono"
              style={{ border: "1px solid var(--border)" }}
            />
            <button disabled={saving} type="submit" className="px-3 py-2 rounded-lg text-sm font-medium text-white flex items-center gap-1.5" style={{ background: "var(--sisal-deep)" }}>
              <Plus size={14} /> Grant
            </button>
          </form>
        </div>

        <div className="rounded-xl p-5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
          <p className="font-display font-semibold text-sm mb-3">All permission codes in use</p>
          <div className="flex flex-col gap-2 max-h-96 overflow-y-auto">
            {allPermissions.map((p) => (
              <div key={p.id || p.code} className="px-3 py-2 rounded-lg" style={{ background: grantedCodes.has(p.code) ? "rgba(47,107,60,0.08)" : "var(--surface-tint)" }}>
                <p className="font-mono text-xs font-medium">{p.code}</p>
                {p.description && <p className="text-[11px] mt-0.5" style={{ color: "var(--slate)" }}>{p.description}</p>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
