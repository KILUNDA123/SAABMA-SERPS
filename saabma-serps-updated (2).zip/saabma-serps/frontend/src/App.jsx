import React, { useEffect, useMemo, useState } from "react";
import ProductionScreen from "./ProductionScreen";
import ShipmentsScreen from "./ShipmentsScreen";
import WarehouseScreen from "./WarehouseScreen";
import SalesScreen from "./SalesScreen";
import EmployeesScreen from "./EmployeesScreen";
import AttendanceScreen from "./AttendanceScreen";
import NotificationsScreen from "./NotificationsScreen";
import PermissionsScreen from "./PermissionsScreen";
import FleetScreen from "./FleetScreen";
import ReportsScreen from "./ReportsScreen";
import SecurityScreen from "./SecurityScreen";
import { apiGet, onUnauthorized } from "./api";
import {
  MapPin,
  Loader2,
  Eye,
  EyeOff,
  Bell,
  LayoutGrid,
  Factory,
  Warehouse,
  Receipt,
  Truck,
  BarChart3,
  Users,
  AlertTriangle,
  CircleCheck,
  Package,
  Wallet,
  ClipboardList,
  Activity,
  ChevronRight,
  LogOut,
  ShieldCheck,
  ShieldAlert,
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";

/* ------------------------------------------------------------------
   API CONFIG
   Point this at your running backend. Every call below matches the
   real NestJS contract (LoginDto, DashboardOverviewPayload) exactly,
   so swapping out the mock fallback for a live server needs no
   other changes.
------------------------------------------------------------------- */
const API_BASE_URL = "http://localhost:3000";

const MOCK_USER = { employeeId: "SERP/EXE/002", fullName: "Amina Wanjiru", role: "operations_manager" };

const MOCK_DASHBOARD = {
  summary: {
    totalEmployees: 84,
    employeesPresentToday: 71,
    employeesAbsentToday: 13,
    lateEmployees: 4,
    warehouseStockCount: 12,
    productsRunningLow: 2,
    ordersToday: 6,
    ordersPending: 9,
    ordersCompleted: 118,
    boxesReceivedToday: 34,
    boxesWashedToday: 28,
    boxesReadyForDispatch: 15,
    invoicesGeneratedToday: 4,
    outstandingInvoices: 7,
    paymentsReceivedToday: 3,
    monthlyRevenue: 4820000,
    yearlyRevenue: 51230000,
    averageDailyProduction: 940,
  },
  charts: [
    {
      key: "production_30d",
      title: "Daily production, last 30 days (kg)",
      type: "line",
      data: Array.from({ length: 30 }).map((_, i) => ({
        label: `${i + 1}`,
        value: Math.round(700 + Math.sin(i / 3) * 180 + (i % 7 === 0 ? 220 : 0) + i * 6),
      })),
    },
  ],
  topPerformingEmployees: [
    { id: "1", fullName: "Peter Kiptoo", employeeCode: "EMP-014", boxes: 41 },
    { id: "2", fullName: "Grace Muthoni", employeeCode: "EMP-028", boxes: 37 },
    { id: "3", fullName: "Samuel Otieno", employeeCode: "EMP-007", boxes: 33 },
  ],
  recentActivities: [
    { id: "1", action: "Approved baling record", entityType: "baling_record", userName: "Amina Wanjiru", createdAt: new Date(Date.now() - 1000 * 60 * 12).toISOString() },
    { id: "2", action: "Invoiced order #4021", entityType: "invoice", userName: "David Mwangi", createdAt: new Date(Date.now() - 1000 * 60 * 47).toISOString() },
    { id: "3", action: "Recorded payment", entityType: "payment", userName: "Front Office", createdAt: new Date(Date.now() - 1000 * 60 * 90).toISOString() },
  ],
  systemHealth: { status: "healthy", alerts: 2 },
};

const numberFmt = (n) => new Intl.NumberFormat("en-KE").format(n);
const kes = (n) => `KES ${new Intl.NumberFormat("en-KE").format(n)}`;

/* ------------------------------------------------------------------
   Signature element: the strand meter — a bundle of vertical fibre
   lines whose count/height encodes a value. Used on stat cards and
   as the loading state, echoing the batch traceability theme.
------------------------------------------------------------------- */
function StrandMeter({ value, max, count = 7, tone = "var(--sisal)" }) {
  const ratio = Math.max(0.08, Math.min(1, value / max));
  return (
    <div className="flex items-end gap-[3px] h-9">
      {Array.from({ length: count }).map((_, i) => {
        const wobble = 0.55 + 0.45 * Math.abs(Math.sin(i * 1.7));
        const h = Math.max(6, ratio * 36 * wobble);
        return (
          <div
            key={i}
            style={{
              height: `${h}px`,
              width: "3px",
              background: tone,
              opacity: 0.35 + 0.65 * (h / 36),
              borderRadius: "2px",
            }}
          />
        );
      })}
    </div>
  );
}

function StrandSpinner({ label }) {
  return (
    <div className="flex flex-col items-center gap-3">
      <div className="flex items-end gap-[4px] h-10">
        {Array.from({ length: 5 }).map((_, i) => (
          <div
            key={i}
            className="w-[3px] rounded-full"
            style={{
              background: "var(--sisal)",
              animation: `strandPulse 1.1s ease-in-out ${i * 0.12}s infinite`,
            }}
          />
        ))}
      </div>
      {label && <p className="text-xs tracking-wide" style={{ color: "var(--paper-dim)" }}>{label}</p>}
    </div>
  );
}

/* ------------------------------------------------------------------
   LOGIN
------------------------------------------------------------------- */
function LoginScreen({ onLogin, sessionMessage }) {
  const [employeeId, setEmployeeId] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [coords, setCoords] = useState(null);
  const [locStatus, setLocStatus] = useState("locating"); // locating | ok | denied
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!navigator.geolocation) {
      setLocStatus("denied");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracyMeters: Math.round(pos.coords.accuracy),
        });
        setLocStatus("ok");
      },
      () => setLocStatus("denied"),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!coords) return;
    setSubmitting(true);
    setError("");

    // These two failure modes must be handled differently: a reachable
    // server saying "no" (wrong password, locked, suspended) is a real
    // answer and must be shown to the user, never silently swallowed into
    // a demo session. Only a genuinely unreachable backend (network error,
    // fetch itself throwing) falls back to demo mode.
    let res;
    try {
      res = await fetch(`${API_BASE_URL}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ employeeId, password, ...coords }),
      });
    } catch {
      await new Promise((r) => setTimeout(r, 400));
      onLogin(MOCK_USER, null, false);
      setSubmitting(false);
      return;
    }

    try {
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        setError(data?.message || "Login failed. Check your employee ID and password.");
        return;
      }
      onLogin(data.user ?? MOCK_USER, data.accessToken ?? null, Boolean(data.mustChangePassword));
    } finally {
      setSubmitting(false);
    }
  }

  const canSubmit = coords && employeeId && password && !submitting;

  return (
    <div className="min-h-screen w-full flex" style={{ background: "var(--paper)" }}>
      {/* Left panel */}
      <div
        className="hidden lg:flex lg:w-[46%] relative flex-col justify-between p-12 strand-bg"
        style={{ background: "var(--fibre-black)" }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-md flex items-center justify-center font-display font-bold text-sm"
            style={{ background: "var(--sisal)", color: "var(--fibre-black)" }}
          >
            S
          </div>
          <span className="font-display font-semibold tracking-wide text-white text-lg">SAABMA</span>
        </div>

        <div className="max-w-md">
          <div className="flex items-end gap-[4px] h-10 mb-8">
            {Array.from({ length: 24 }).map((_, i) => {
              const h = 8 + Math.abs(Math.sin(i * 0.6)) * 30;
              return (
                <div
                  key={i}
                  style={{
                    height: `${h}px`,
                    width: "3px",
                    background: i % 5 === 0 ? "var(--sisal)" : "rgba(246,244,236,0.25)",
                    borderRadius: "2px",
                  }}
                />
              );
            })}
          </div>
          <h1 className="font-display font-semibold text-3xl text-white leading-tight mb-4">
            Every strand,<br />accounted for.
          </h1>
          <p className="font-body text-sm leading-relaxed" style={{ color: "var(--paper-dim)" }}>
            From soaking to bale to bill of lading — Serps tracks every batch of fibre
            your operation touches, and every person who touched it.
          </p>
        </div>

        <p className="font-mono text-xs" style={{ color: "var(--slate)" }}>
          SERPS · SISAL ERP &amp; EXPORT PLATFORM
        </p>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <div className="lg:hidden flex items-center gap-3 mb-10">
            <div
              className="w-9 h-9 rounded-md flex items-center justify-center font-display font-bold text-sm"
              style={{ background: "var(--sisal)", color: "var(--fibre-black)" }}
            >
              S
            </div>
            <span className="font-display font-semibold tracking-wide text-lg" style={{ color: "var(--ink)" }}>
              SAABMA
            </span>
          </div>

          <h2 className="font-display font-semibold text-2xl mb-1" style={{ color: "var(--ink)" }}>
            Sign in
          </h2>
          <p className="font-body text-sm mb-8" style={{ color: "var(--slate)" }}>
            Use your Saabma staff account to continue.
          </p>

          {sessionMessage && (
            <div className="rounded-lg px-3.5 py-2.5 mb-5 font-body text-xs" style={{ background: "rgba(226,163,61,0.12)", color: "#9C6A1E", border: "1px solid var(--border)" }}>
              {sessionMessage}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="font-body text-xs font-medium block mb-1.5" style={{ color: "var(--slate)" }}>
                Employee ID
              </label>
              <input
                type="text"
                required
                autoCapitalize="characters"
                value={employeeId}
                onChange={(e) => setEmployeeId(e.target.value)}
                placeholder="SERP/EXE/001"
                className="w-full font-body text-sm rounded-lg px-3.5 py-2.5 outline-none border transition-colors font-mono"
                style={{ borderColor: "var(--border)", background: "#FFFFFF", color: "var(--ink)" }}
                onFocus={(e) => (e.target.style.borderColor = "var(--sisal)")}
                onBlur={(e) => (e.target.style.borderColor = "var(--border)")}
              />
            </div>

            <div>
              <label className="font-body text-xs font-medium block mb-1.5" style={{ color: "var(--slate)" }}>
                Password
              </label>
              <div className="relative">
                <input
                  type={showPw ? "text" : "password"}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full font-body text-sm rounded-lg px-3.5 py-2.5 pr-10 outline-none border transition-colors"
                  style={{ borderColor: "var(--border)", background: "#FFFFFF", color: "var(--ink)" }}
                  onFocus={(e) => (e.target.style.borderColor = "var(--sisal)")}
                  onBlur={(e) => (e.target.style.borderColor = "var(--border)")}
                />
                <button
                  type="button"
                  onClick={() => setShowPw((s) => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{ color: "var(--slate)" }}
                  aria-label={showPw ? "Hide password" : "Show password"}
                >
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Forced-location status */}
            <div
              className="flex items-center gap-2.5 rounded-lg px-3.5 py-2.5 border font-body text-xs"
              style={{
                borderColor: locStatus === "denied" ? "var(--danger-border)" : "var(--border)",
                background: locStatus === "ok" ? "rgba(47,107,60,0.08)" : "#FFFFFF",
                color: locStatus === "denied" ? "var(--danger)" : "var(--slate)",
              }}
            >
              {locStatus === "locating" && <Loader2 size={14} className="animate-spin" style={{ color: "var(--sisal-deep)" }} />}
              {locStatus === "ok" && <MapPin size={14} style={{ color: "var(--sisal-deep)" }} />}
              {locStatus === "denied" && <MapPin size={14} />}
              <span>
                {locStatus === "locating" && "Confirming device location…"}
                {locStatus === "ok" && `Location confirmed · accuracy ±${coords.accuracyMeters}m`}
                {locStatus === "denied" && "Location is required — enable it to sign in."}
              </span>
            </div>

            {error && <p className="text-xs font-body" style={{ color: "var(--danger)" }}>{error}</p>}

            <button
              type="submit"
              disabled={!canSubmit}
              className="w-full font-display font-semibold text-sm rounded-lg py-2.5 mt-2 transition-opacity flex items-center justify-center gap-2"
              style={{
                background: "var(--fibre-black)",
                color: "var(--sisal)",
                opacity: canSubmit ? 1 : 0.4,
                cursor: canSubmit ? "pointer" : "not-allowed",
              }}
            >
              {submitting ? <Loader2 size={15} className="animate-spin" /> : null}
              {submitting ? "Signing in" : "Sign in"}
            </button>
          </form>

          <p className="font-body text-xs mt-8 text-center" style={{ color: "var(--paper-dim)" }}>
            This system records login information for operational security and audit purposes.
          </p>
          <p className="font-body text-xs mt-2 text-center" style={{ color: "var(--paper-dim)" }}>
            Forgotten your password? Only HR or the CEO can reset it — passwords are never self-service.
          </p>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------
   FORCED PASSWORD CHANGE — shown when the backend login response
   returns mustChangePassword: true (new account or admin-triggered
   reset). Blocks access to everything else until changed, matching
   the "do not allow access until the password is successfully
   changed" policy. Mirrors the backend's real policy: 12+ chars,
   upper/lower/number/special — checked client-side for fast feedback,
   but the backend re-validates and is the real enforcement point.
------------------------------------------------------------------- */
const PASSWORD_POLICY_RE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{12,}$/;

function ForceChangePasswordScreen({ token, onDone, onLogout }) {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const policyOk = PASSWORD_POLICY_RE.test(newPassword);
  const matches = newPassword.length > 0 && newPassword === confirmPassword;
  const canSubmit = currentPassword && policyOk && matches && !submitting;

  async function handleSubmit(e) {
    e.preventDefault();
    if (!canSubmit) return;
    setSubmitting(true);
    setError("");
    try {
      const res = await fetch(`${API_BASE_URL}/auth/change-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token || ""}` },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        setError(data?.message || "Could not change password");
        return;
      }
      onDone();
    } catch {
      setError("Could not reach the server. Try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-8" style={{ background: "var(--paper)" }}>
      <div className="w-full max-w-sm">
        <h2 className="font-display font-semibold text-2xl mb-1" style={{ color: "var(--ink)" }}>
          Set a new password
        </h2>
        <p className="font-body text-sm mb-8" style={{ color: "var(--slate)" }}>
          Your password was reset by an administrator. Choose a new one before continuing.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="font-body text-xs font-medium block mb-1.5" style={{ color: "var(--slate)" }}>
              Temporary password
            </label>
            <input
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              className="w-full font-body text-sm rounded-lg px-3.5 py-2.5 outline-none border"
              style={{ borderColor: "var(--border)", background: "#FFFFFF", color: "var(--ink)" }}
            />
          </div>
          <div>
            <label className="font-body text-xs font-medium block mb-1.5" style={{ color: "var(--slate)" }}>
              New password
            </label>
            <input
              type="password"
              required
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full font-body text-sm rounded-lg px-3.5 py-2.5 outline-none border"
              style={{ borderColor: newPassword && !policyOk ? "var(--danger-border)" : "var(--border)", background: "#FFFFFF", color: "var(--ink)" }}
            />
            <p className="text-[11px] mt-1.5" style={{ color: newPassword && !policyOk ? "var(--danger)" : "var(--paper-dim)" }}>
              At least 12 characters, with an uppercase letter, a lowercase letter, a number, and a special character.
            </p>
          </div>
          <div>
            <label className="font-body text-xs font-medium block mb-1.5" style={{ color: "var(--slate)" }}>
              Confirm new password
            </label>
            <input
              type="password"
              required
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full font-body text-sm rounded-lg px-3.5 py-2.5 outline-none border"
              style={{ borderColor: confirmPassword && !matches ? "var(--danger-border)" : "var(--border)", background: "#FFFFFF", color: "var(--ink)" }}
            />
          </div>

          {error && <p className="text-xs font-body" style={{ color: "var(--danger)" }}>{error}</p>}

          <button
            type="submit"
            disabled={!canSubmit}
            className="w-full font-display font-semibold text-sm rounded-lg py-2.5 mt-2 transition-opacity"
            style={{ background: "var(--fibre-black)", color: "var(--sisal)", opacity: canSubmit ? 1 : 0.4, cursor: canSubmit ? "pointer" : "not-allowed" }}
          >
            {submitting ? "Updating…" : "Update password and continue"}
          </button>
          <button type="button" onClick={onLogout} className="w-full text-xs font-body text-center" style={{ color: "var(--slate)" }}>
            Sign out instead
          </button>
        </form>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------
   DASHBOARD
------------------------------------------------------------------- */
function StatCard({ icon: Icon, label, value, sub, strandValue, strandMax, tone }) {
  return (
    <div
      className="rounded-xl p-5 flex flex-col gap-4"
      style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}
    >
      <div className="flex items-start justify-between">
        <div
          className="w-9 h-9 rounded-lg flex items-center justify-center"
          style={{ background: "rgba(47,107,60,0.12)" }}
        >
          <Icon size={16} style={{ color: "var(--sisal-deep)" }} />
        </div>
        <StrandMeter value={strandValue} max={strandMax} tone={tone || "var(--sisal)"} />
      </div>
      <div>
        <p className="font-mono text-2xl font-medium" style={{ color: "var(--ink)" }}>{value}</p>
        <p className="font-body text-xs mt-0.5" style={{ color: "var(--slate)" }}>{label}</p>
        {sub && <p className="font-body text-[11px] mt-1" style={{ color: "var(--paper-dim)" }}>{sub}</p>}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------
   Nav visibility mirrors the real backend @Roles() guards exactly, so
   nobody sees a menu item that would just 403 underneath them. Where a
   controller has no @Roles() decorator (RolesGuard lets any
   authenticated user through), `roles` is left undefined = visible to
   everyone. This is a UX convenience only, not a security boundary —
   the backend guards are still what actually enforce access.

   Source of truth checked directly against each controller:
     /dashboard   -> @Roles(CEO, OPERATIONS_MANAGER)
     /production  -> open (one POST endpoint restricted, GETs are open)
     /warehouses  -> open
     /orders,/invoices (Sales screen) -> @Roles(SALES, FINANCE, CEO)
     /shipments   -> @Roles(SALES, OPERATIONS_MANAGER, CEO)
     /vehicles,/drivers (Fleet) -> open
     /employees   -> open (no restriction — see note to Dennis)
     /attendance  -> @Roles(HR, CEO, OPERATIONS_MANAGER)
     /permissions -> @Roles(ADMIN, CEO)
     /reports     -> @Roles(CEO, OPERATIONS_MANAGER, FINANCE)
------------------------------------------------------------------- */
// Every nav item is gated by exactly one permission code, matching the
// centralized backend list (permissions.constants.ts) - never a role name.
// Whether a role can see a module is entirely a function of which
// permission codes that role has been granted (fetched fresh from
// GET /permissions/mine after login), not an `if (user.role === ...)`
// check baked into the frontend.
const NAV_ITEMS = [
  { key: "dashboard", icon: LayoutGrid, label: "Dashboard", ready: true, permission: "dashboard:view", accent: "var(--sisal-deep)" },
  { key: "production", icon: Factory, label: "Production", ready: true, permission: "production:view", accent: "var(--plantation)" },
  { key: "warehouse", icon: Warehouse, label: "Warehouse", ready: true, permission: "warehouse:view", accent: "var(--earth-brown)" },
  { key: "sales", icon: Receipt, label: "Sales", ready: true, permission: "sales:view", accent: "var(--ocean-navy)" },
  { key: "shipments", icon: Truck, label: "Shipments", ready: true, permission: "shipments:view", accent: "var(--ocean-navy)" },
  { key: "fleet", icon: Truck, label: "Fleet", ready: true, permission: "fleet:view", accent: "var(--container-rust)" },
  { key: "employees", icon: Users, label: "Employees", ready: true, permission: "employees:view", accent: "var(--plantation)" },
  // The Attendance *screen* calls the company-wide roster endpoints
  // (GET /attendance, /missing-today), which the backend gates behind
  // attendance:manage, not the more broadly-granted attendance:view - so
  // the nav item must match, or holders of attendance:view-only (most
  // tiers, down to casual workers) would see a menu item that just 403s.
  { key: "attendance", icon: ClipboardList, label: "Attendance", ready: true, permission: "attendance:manage", accent: "var(--plantation)" },
  { key: "permissions", icon: ShieldCheck, label: "Permissions", ready: true, permission: "permissions:view", accent: "var(--neutral-gray)" },
  { key: "reports", icon: BarChart3, label: "Reports", ready: true, permission: "reports:view", accent: "var(--ocean-navy)" },
  { key: "security", icon: ShieldAlert, label: "Security", ready: true, permission: "location_logs:view", accent: "var(--neutral-gray)" },
];

function navItemsForPermissions(permissionSet) {
  return NAV_ITEMS.filter((item) => permissionSet.has(item.permission));
}

const ACCENT_TINT = {
  "var(--sisal-deep)": "rgba(30,77,43,0.12)",
  "var(--plantation)": "rgba(47,107,60,0.12)",
  "var(--ocean-navy)": "rgba(11,53,88,0.10)",
  "var(--container-rust)": "rgba(165,78,42,0.12)",
  "var(--earth-brown)": "rgba(122,90,47,0.12)",
  "var(--neutral-gray)": "rgba(95,103,114,0.12)",
};

function timeAgo(iso) {
  const mins = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  return `${hrs}h ago`;
}

function ComingSoon({ label }) {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <p className="font-display font-semibold text-lg mb-1.5">{label} isn't built yet</p>
      <p className="text-sm max-w-xs" style={{ color: "var(--slate)" }}>
        The backend already supports this module — the screen for it just hasn't been built.
      </p>
    </div>
  );
}

function decodeJwtExp(token) {
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    return typeof payload.exp === "number" ? payload.exp * 1000 : null;
  } catch {
    return null;
  }
}

/* ------------------------------------------------------------------
   ACCESS DENIED — the frontend hides nav items the user's permission
   set doesn't include, but this is what renders if a screen is somehow
   reached anyway (e.g. stale state after a permission was revoked
   mid-session). It is NOT the security boundary - the backend's
   PermissionsGuard on every endpoint is what actually stops the
   request; this is just an honest, clear message instead of a screen
   silently failing or showing empty/broken data.
------------------------------------------------------------------- */
function AccessDeniedScreen({ requiredPermission, onBack }) {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <div className="w-12 h-12 rounded-full flex items-center justify-center mb-4" style={{ background: "rgba(165,78,42,0.12)" }}>
        <ShieldAlert size={22} style={{ color: "var(--danger)" }} />
      </div>
      <h2 className="font-display font-semibold text-lg mb-1.5" style={{ color: "var(--ink)" }}>Access denied</h2>
      <p className="text-sm max-w-xs mb-1" style={{ color: "var(--slate)" }}>
        Your account doesn't have the <span className="font-mono text-xs">{requiredPermission}</span> permission needed for this page.
      </p>
      <p className="text-xs max-w-xs mb-5" style={{ color: "var(--paper-dim)" }}>
        If you believe this is a mistake, ask your CEO or administrator to grant it from the Permissions screen.
      </p>
      <button onClick={onBack} className="px-4 py-2 rounded-lg text-sm font-medium text-white" style={{ background: "var(--fibre-black)" }}>
        Back to your workspace
      </button>
    </div>
  );
}

function AppShell({ user, token, permissions, screen, onNavigate, onLogout }) {
  const [data, setData] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [unreadCount, setUnreadCount] = useState(2); // falls back to the demo badge until a real count loads
  const [collapsed, setCollapsed] = useState(() => localStorage.getItem("serps.sidebarCollapsed") === "1");
  const [sessionWarning, setSessionWarning] = useState(false);

  const myNav = useMemo(() => navItemsForPermissions(permissions), [permissions]);
  const hasDashboardAccess = myNav.some((n) => n.key === "dashboard");

  useEffect(() => {
    localStorage.setItem("serps.sidebarCollapsed", collapsed ? "1" : "0");
  }, [collapsed]);

  // Redirect off the dashboard if this role has no backend access to it
  // (@Roles(CEO, OPERATIONS_MANAGER) on the real /dashboard controller) —
  // land on their first accessible module instead of showing a 403.
  useEffect(() => {
    if (screen === "dashboard" && !hasDashboardAccess && myNav.length > 0) {
      onNavigate(myNav[0].key);
    }
  }, [screen, hasDashboardAccess, myNav]);

  // Session expiry: the real backend issues a 12h JWT with a genuine `exp`
  // claim. Read it directly rather than guessing a timeout, warn 2 minutes
  // before it lapses, and log out automatically the moment it does — a
  // stale token would otherwise just start failing requests silently.
  useEffect(() => {
    const expiresAt = decodeJwtExp(token);
    if (!expiresAt) return;
    const warnAt = expiresAt - 2 * 60 * 1000;
    const now = Date.now();
    const warnTimer = setTimeout(() => setSessionWarning(true), Math.max(0, warnAt - now));
    const logoutTimer = setTimeout(() => onLogout(), Math.max(0, expiresAt - now));
    return () => { clearTimeout(warnTimer); clearTimeout(logoutTimer); };
  }, [token]);

  useEffect(() => {
    if (!hasDashboardAccess) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/dashboard`, {
          headers: { Authorization: `Bearer ${token || ""}` },
        });
        if (!res.ok) throw new Error("bad response");
        const payload = await res.json();
        if (!cancelled) setData(payload);
      } catch {
        if (!cancelled) {
          setData(MOCK_DASHBOARD);
          setUsingDemo(true);
        }
      }
    })();
    return () => { cancelled = true; };
  }, [hasDashboardAccess]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const unread = await apiGet("/notifications/unread", token);
        if (!cancelled) setUnreadCount(unread.length);
      } catch {
        // keep the demo fallback count — the real endpoint needs a live backend
      }
    })();
    return () => { cancelled = true; };
  }, [screen]);

  const s = data?.summary;

  return (
    <div className="min-h-screen font-body" style={{ background: "var(--paper)", color: "var(--ink)" }}>
      {/* Top bar */}
      <div
        className="flex items-center justify-between px-6 py-3.5 border-b"
        style={{ borderColor: "var(--border)", background: "#FFFFFF" }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-md flex items-center justify-center font-display font-bold text-xs"
            style={{ background: "var(--fibre-black)", color: "var(--sisal)" }}
          >
            S
          </div>
          <span className="font-display font-semibold tracking-wide" style={{ color: "var(--ink)" }}>SAABMA</span>
          {usingDemo && (
            <span
              className="font-mono text-[10px] px-2 py-0.5 rounded-full ml-2"
              style={{ background: "rgba(226,163,61,0.15)", color: "#9C6A1E" }}
            >
              DEMO DATA
            </span>
          )}
        </div>
        <div className="flex items-center gap-5">
          <button
            onClick={() => onNavigate("notifications")}
            className="relative"
            style={{ color: screen === "notifications" ? "var(--sisal-deep)" : "var(--slate)" }}
            aria-label="Notifications"
          >
            <Bell size={18} />
            {unreadCount > 0 && (
              <span
                className="absolute -top-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center font-mono text-[9px] text-white"
                style={{ background: "var(--amber)" }}
              >
                {unreadCount > 9 ? "9+" : unreadCount}
              </span>
            )}
          </button>
          <div className="flex items-center gap-2.5">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center font-display text-xs font-semibold"
              style={{ background: "rgba(47,107,60,0.15)", color: "var(--sisal-deep)" }}
            >
              {user.fullName.split(" ").map((n) => n[0]).slice(0, 2).join("")}
            </div>
            <div className="hidden sm:block leading-tight">
              <p className="text-sm font-medium">{user.fullName}</p>
              <p className="text-[11px]" style={{ color: "var(--paper-dim)" }}>{user.role}</p>
            </div>
          </div>
          <button onClick={onLogout} style={{ color: "var(--slate)" }} aria-label="Sign out">
            <LogOut size={17} />
          </button>
        </div>
      </div>

      {sessionWarning && (
        <div
          className="flex items-center justify-between px-6 py-2 text-sm"
          style={{ background: "rgba(226,163,61,0.15)", color: "#9C6A1E" }}
        >
          <span>Your session expires in less than 2 minutes. Save any unsaved work.</span>
          <button onClick={onLogout} className="font-medium underline">Sign out now</button>
        </div>
      )}

      <div className="flex">
        {/* Nav rail */}
        <div
          className="hidden md:flex flex-col gap-1 shrink-0 p-4 border-r transition-all duration-200"
          style={{ borderColor: "var(--border)", background: "#FFFFFF", width: collapsed ? "4.25rem" : "14rem" }}
        >
          <button
            onClick={() => setCollapsed((v) => !v)}
            className="flex items-center justify-center w-8 h-8 rounded-lg mb-2 self-end"
            style={{ color: "var(--slate)" }}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            title={collapsed ? "Expand" : "Collapse"}
          >
            <ChevronRight size={15} style={{ transform: collapsed ? "none" : "rotate(180deg)", transition: "transform 150ms" }} />
          </button>
          {myNav.map((item) => {
            const isActive = screen === item.key;
            const accent = item.accent || "var(--sisal-deep)";
            return (
              <button
                key={item.key}
                onClick={() => onNavigate(item.key)}
                className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors"
                title={collapsed ? item.label : undefined}
                style={{
                  background: isActive ? (ACCENT_TINT[accent] || "rgba(47,107,60,0.12)") : "transparent",
                  color: isActive ? accent : "var(--slate)",
                  justifyContent: collapsed ? "center" : "flex-start",
                }}
              >
                <item.icon size={16} />
                {!collapsed && item.label}
                {!collapsed && !item.ready && <ChevronRight size={13} className="ml-auto opacity-40" />}
              </button>
            );
          })}
        </div>

        {/* Main content */}
        <div className="flex-1 p-6 max-w-6xl">
        {(() => {
          const navItem = NAV_ITEMS.find((n) => n.key === screen);
          // Screens not in NAV_ITEMS (e.g. "notifications", reached from the
          // bell icon rather than the sidebar) are allowed through here -
          // the backend still independently enforces notifications:view.
          if (navItem && !permissions.has(navItem.permission)) {
            return <AccessDeniedScreen requiredPermission={navItem.permission} onBack={() => onNavigate(myNav[0]?.key ?? "notifications")} />;
          }
          return null;
        })()}
        {(() => {
          const navItem = NAV_ITEMS.find((n) => n.key === screen);
          if (navItem && !permissions.has(navItem.permission)) return null;
          return screen === "production" ? (
          <ProductionScreen token={token} />
        ) : screen === "shipments" ? (
          <ShipmentsScreen token={token} />
        ) : screen === "fleet" ? (
          <FleetScreen token={token} />
        ) : screen === "warehouse" ? (
          <WarehouseScreen token={token} />
        ) : screen === "sales" ? (
          <SalesScreen token={token} />
        ) : screen === "employees" ? (
          <EmployeesScreen token={token} />
        ) : screen === "attendance" ? (
          <AttendanceScreen token={token} />
        ) : screen === "notifications" ? (
          <NotificationsScreen token={token} />
        ) : screen === "permissions" ? (
          <PermissionsScreen token={token} />
        ) : screen === "reports" ? (
          <ReportsScreen token={token} />
        ) : screen === "security" ? (
          <SecurityScreen token={token} />
        ) : screen !== "dashboard" ? (
          <ComingSoon label={NAV_ITEMS.find((n) => n.key === screen)?.label ?? "This module"} />
        ) : !hasDashboardAccess ? null : !data ? (
          <div className="flex items-center justify-center py-24">
            <StrandSpinner label="Loading the day's numbers…" />
          </div>
        ) : (
          <>
          <div className="mb-6">
            <h1 className="font-display font-semibold text-xl">Good afternoon, {user.fullName.split(" ")[0]}</h1>
            <p className="text-sm mt-0.5" style={{ color: "var(--slate)" }}>
              Here's where the operation stands today.
            </p>
          </div>

          {/* Stat grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard
              icon={Users}
              label="Staff present today"
              value={`${s.employeesPresentToday}/${s.totalEmployees}`}
              sub={`${s.lateEmployees} arrived late`}
              strandValue={s.employeesPresentToday}
              strandMax={s.totalEmployees}
            />
            <StatCard
              icon={Package}
              label="Inventory items low"
              value={s.productsRunningLow}
              sub={`${s.warehouseStockCount} items tracked`}
              strandValue={s.warehouseStockCount - s.productsRunningLow}
              strandMax={s.warehouseStockCount}
              tone={s.productsRunningLow > 0 ? "var(--amber)" : "var(--sisal)"}
            />
            <StatCard
              icon={ClipboardList}
              label="Orders pending"
              value={s.ordersPending}
              sub={`${s.ordersToday} placed today`}
              strandValue={s.ordersCompleted}
              strandMax={s.ordersCompleted + s.ordersPending}
            />
            <StatCard
              icon={Wallet}
              label="Monthly revenue"
              value={kes(s.monthlyRevenue)}
              sub={`${s.outstandingInvoices} invoices outstanding`}
              strandValue={s.monthlyRevenue}
              strandMax={s.yearlyRevenue / 8}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Chart */}
            <div className="lg:col-span-2 rounded-xl p-5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display font-semibold text-sm">{data.charts[0].title}</h3>
                <span className="font-mono text-xs" style={{ color: "var(--paper-dim)" }}>
                  avg {numberFmt(s.averageDailyProduction)} kg/day
                </span>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={data.charts[0].data}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--divider)" vertical={false} />
                  <XAxis dataKey="label" tick={{ fontSize: 10, fill: "var(--paper-dim)" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: "var(--paper-dim)" }} axisLine={false} tickLine={false} width={40} />
                  <Tooltip
                    contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid var(--border)", fontFamily: "Inter" }}
                  />
                  <Line type="monotone" dataKey="value" stroke="var(--sisal-deep)" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* System health + activity */}
            <div className="flex flex-col gap-4">
              <div className="rounded-xl p-5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <CircleCheck size={15} style={{ color: "var(--sisal-deep)" }} />
                  <h3 className="font-display font-semibold text-sm">System healthy</h3>
                </div>
                <p className="text-xs" style={{ color: "var(--slate)" }}>
                  {data.systemHealth.alerts} open alert{data.systemHealth.alerts === 1 ? "" : "s"} across all modules.
                </p>
              </div>

              <div className="rounded-xl p-5 flex-1" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
                <div className="flex items-center gap-2 mb-3">
                  <Activity size={15} style={{ color: "var(--slate)" }} />
                  <h3 className="font-display font-semibold text-sm">Recent activity</h3>
                </div>
                <div className="flex flex-col gap-3">
                  {data.recentActivities.map((a) => (
                    <div key={a.id} className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-xs font-medium">{a.action}</p>
                        <p className="text-[11px]" style={{ color: "var(--paper-dim)" }}>{a.userName}</p>
                      </div>
                      <span className="font-mono text-[10px] whitespace-nowrap" style={{ color: "var(--paper-dim)" }}>
                        {timeAgo(a.createdAt)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Top performers */}
          <div className="mt-4 rounded-xl p-5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
            <h3 className="font-display font-semibold text-sm mb-3">Top performing employees this month</h3>
            <div className="flex flex-col gap-2.5">
              {data.topPerformingEmployees.map((e, i) => (
                <div key={e.id} className="flex items-center gap-3">
                  <span className="font-mono text-xs w-5" style={{ color: "var(--paper-dim)" }}>{i + 1}</span>
                  <span className="text-sm flex-1">{e.fullName}</span>
                  <span className="font-mono text-[11px]" style={{ color: "var(--paper-dim)" }}>{e.employeeCode}</span>
                  <StrandMeter value={e.boxes} max={data.topPerformingEmployees[0].boxes} count={5} />
                  <span className="font-mono text-xs w-14 text-right" style={{ color: "var(--slate)" }}>{e.boxes} boxes</span>
                </div>
              ))}
            </div>
          </div>
          </>
          );
        })()}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------
   ROOT
------------------------------------------------------------------- */
export default function SaabmaApp() {
  const [session, setSession] = useState(null); // { user, token }
  const [permissions, setPermissions] = useState(null); // Set<string> | null while loading
  const [screen, setScreen] = useState("dashboard");
  const [mustChangePassword, setMustChangePassword] = useState(false);
  const [sessionMessage, setSessionMessage] = useState("");

  const handleLogin = async (user, token, forcedChange) => {
    setSession({ user, token });
    setSessionMessage("");
    setMustChangePassword(Boolean(forcedChange));

    // Permissions come from the real backend, never guessed or defaulted -
    // if this call fails, the person is signed back out with an explicit
    // message rather than shown a fabricated set of nav items.
    try {
      const result = await apiGet("/permissions/mine", token);
      const permSet = new Set(result.permissions);
      setPermissions(permSet);
      const accessible = navItemsForPermissions(permSet);
      setScreen(accessible.some((n) => n.key === "dashboard") ? "dashboard" : (accessible[0]?.key ?? "notifications"));
    } catch {
      setSession(null);
      setPermissions(null);
      setSessionMessage("Could not load your permissions. Please sign in again.");
    }
  };
  const handleLogout = () => { setSession(null); setPermissions(null); setScreen("dashboard"); setMustChangePassword(false); };

  // Registered once for the whole app: any request anywhere that comes
  // back 401 (expired token, or superseded by a login elsewhere thanks to
  // single-session enforcement) forces a real, explained sign-out rather
  // than each screen separately and silently falling back to demo data.
  useEffect(() => {
    onUnauthorized((message) => {
      setSession((current) => {
        if (!current) return current; // already signed out - ignore
        setSessionMessage(message);
        return null;
      });
      setPermissions(null);
      setMustChangePassword(false);
      setScreen("dashboard");
    });
  }, []);

  if (session && mustChangePassword) {
    return (
      <ForceChangePasswordScreen
        token={session.token}
        onDone={() => setMustChangePassword(false)}
        onLogout={handleLogout}
      />
    );
  }

  if (session && !permissions) {
    // Between "login succeeded" and "permissions loaded" - a fraction of a
    // second normally, but a real loading state rather than a flash of an
    // empty or wrong sidebar.
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--paper)" }}>
        <StrandSpinner label="Loading your workspace…" />
      </div>
    );
  }

  return session ? (
    <AppShell
      user={session.user}
      token={session.token}
      permissions={permissions}
      screen={screen}
      onNavigate={setScreen}
      onLogout={handleLogout}
    />
  ) : (
    <LoginScreen onLogin={handleLogin} sessionMessage={sessionMessage} />
  );
}
