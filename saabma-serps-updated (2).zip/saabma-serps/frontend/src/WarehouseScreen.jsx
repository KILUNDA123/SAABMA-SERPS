import React, { useEffect, useState } from "react";
import { Plus, Warehouse as WarehouseIcon, Boxes, ArrowRightLeft, ChevronDown, AlertTriangle, Loader2 } from "lucide-react";
import { apiGet, apiPost, apiPatch } from "./api";

/* ------------------------------------------------------------------
   Domain constants — mirrors backend/src/modules/inventory and
   backend/src/modules/warehouse entities/DTOs exactly.
------------------------------------------------------------------- */
const CATEGORIES = {
  raw_sisal: "Raw sisal",
  semi_processed: "Semi-processed",
  finished_fibre: "Finished fibre",
  chemical: "Chemical",
  packaging: "Packaging",
};

// Each of these calls WarehouseTransactionDto ({ itemId, type, quantity, reference?, warehouseId? })
// at its own endpoint. `defaultType` just pre-fills the sensible movement direction —
// the backend still requires `type` to be sent explicitly.
const STOCK_ACTIONS = {
  receive: { label: "Receive", endpoint: "/warehouses/receive", defaultType: "in" },
  inspect: { label: "Inspect", endpoint: "/warehouses/inspect", defaultType: "in" },
  store: { label: "Store", endpoint: "/warehouses/store", defaultType: "in" },
  pick: { label: "Pick", endpoint: "/warehouses/pick", defaultType: "out" },
  dispatch: { label: "Dispatch", endpoint: "/warehouses/dispatch", defaultType: "out" },
  deliver: { label: "Deliver", endpoint: "/warehouses/deliver", defaultType: "out" },
};

/* ------------------------------------------------------------------
   Mock fallback data
------------------------------------------------------------------- */
const MOCK_ITEMS = [
  { id: "i1", name: "Raw sisal bales", category: "raw_sisal", unit: "kg", currentStock: 4200, reorderLevel: 2000 },
  { id: "i2", name: "Hydrogen peroxide", category: "chemical", unit: "litres", reorderLevel: 200, currentStock: 140 },
  { id: "i3", name: "Finished fibre — grade A", category: "finished_fibre", unit: "bales", currentStock: 58, reorderLevel: 30 },
  { id: "i4", name: "Export cartons", category: "packaging", unit: "pieces", currentStock: 320, reorderLevel: 400 },
];

const MOCK_WAREHOUSES = [
  { id: "w1", name: "Main Warehouse", location: "Voi, Kenya" },
  { id: "w2", name: "Port Staging", location: "Mombasa, Kenya" },
];

const MOCK_MOVEMENTS = {
  i1: [
    { id: "m1", type: "in", quantity: 800, reference: "SBM2507010001", createdAt: new Date(Date.now() - 86400000).toISOString(), recordedBy: { fullName: "Grace Muthoni" } },
    { id: "m2", type: "out", quantity: 300, reference: "SHP-2507-0009", createdAt: new Date(Date.now() - 86400000 * 3).toISOString(), recordedBy: { fullName: "Peter Kiptoo" } },
  ],
};

function Badge({ children, tone = "neutral" }) {
  const tones = {
    neutral: { bg: "var(--divider)", color: "var(--slate)" },
    warn: { bg: "rgba(226,163,61,0.15)", color: "#9C6A1E" },
    live: { bg: "rgba(47,107,60,0.15)", color: "var(--sisal-deep)" },
  };
  const t = tones[tone] || tones.neutral;
  return (
    <span className="font-mono text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wide" style={{ background: t.bg, color: t.color }}>
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------
   INVENTORY TAB
------------------------------------------------------------------- */
function InventoryTab({ token }) {
  const [items, setItems] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [lowOnly, setLowOnly] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: "", category: "raw_sisal", unit: "", currentStock: "", reorderLevel: "" });
  const [expanded, setExpanded] = useState(null);
  const [movements, setMovements] = useState({});
  const [editingReorder, setEditingReorder] = useState(null);
  const [reorderDraft, setReorderDraft] = useState("");

  async function load(lowStockOnly = lowOnly) {
    try {
      const list = await apiGet(lowStockOnly ? "/inventory/low-stock" : "/inventory", token);
      setItems(list);
      setUsingDemo(false);
    } catch {
      setItems(lowStockOnly ? MOCK_ITEMS.filter((i) => i.currentStock <= i.reorderLevel) : MOCK_ITEMS);
      setUsingDemo(true);
    }
  }

  useEffect(() => { load(); }, [lowOnly]);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await apiPost("/inventory", {
        name: form.name,
        category: form.category,
        unit: form.unit,
        currentStock: form.currentStock ? Number(form.currentStock) : undefined,
        reorderLevel: form.reorderLevel ? Number(form.reorderLevel) : undefined,
      }, token);
    } catch { /* demo mode */ }
    setForm({ name: "", category: "raw_sisal", unit: "", currentStock: "", reorderLevel: "" });
    setShowForm(false);
    setSaving(false);
    await load();
  }

  async function saveReorderLevel(item) {
    try {
      await apiPatch(`/inventory/${item.id}/reorder-level`, { reorderLevel: Number(reorderDraft) }, token);
      await load();
    } catch {
      setItems((prev) => prev.map((i) => (i.id === item.id ? { ...i, reorderLevel: Number(reorderDraft) } : i)));
    } finally {
      setEditingReorder(null);
    }
  }

  async function toggleExpand(item) {
    if (expanded === item.id) { setExpanded(null); return; }
    setExpanded(item.id);
    if (!movements[item.id]) {
      try {
        const list = await apiGet(`/warehouses/movements/${item.id}`, token);
        setMovements((m) => ({ ...m, [item.id]: list }));
      } catch {
        setMovements((m) => ({ ...m, [item.id]: MOCK_MOVEMENTS[item.id] || [] }));
      }
    }
  }

  if (!items) return <p className="text-sm" style={{ color: "var(--slate)" }}>Loading inventory…</p>;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <label className="flex items-center gap-2 text-sm" style={{ color: "var(--slate)" }}>
          <input type="checkbox" checked={lowOnly} onChange={(e) => setLowOnly(e.target.checked)} />
          Show low stock only
        </label>
        <button onClick={() => setShowForm((s) => !s)} className="flex items-center gap-1.5 font-display font-semibold text-xs rounded-lg px-3 py-2"
          style={{ background: "var(--fibre-black)", color: "var(--sisal)" }}>
          <Plus size={14} /> New item
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="rounded-xl p-4 mb-4 flex flex-wrap items-end gap-3" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
          <div className="flex-1 min-w-[160px]">
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Name *</label>
            <input required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border w-full" style={{ borderColor: "var(--border)" }} />
          </div>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Category</label>
            <select value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border bg-white" style={{ borderColor: "var(--border)" }}>
              {Object.entries(CATEGORIES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Unit *</label>
            <input required value={form.unit} onChange={(e) => setForm((f) => ({ ...f, unit: e.target.value }))}
              placeholder="kg" className="text-sm rounded-lg px-3 py-2 border w-24" style={{ borderColor: "var(--border)" }} />
          </div>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Opening stock</label>
            <input type="number" min="0" value={form.currentStock} onChange={(e) => setForm((f) => ({ ...f, currentStock: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border w-28" style={{ borderColor: "var(--border)" }} />
          </div>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Reorder level</label>
            <input type="number" min="0" value={form.reorderLevel} onChange={(e) => setForm((f) => ({ ...f, reorderLevel: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border w-28" style={{ borderColor: "var(--border)" }} />
          </div>
          <button type="submit" disabled={saving} className="font-display font-semibold text-xs rounded-lg px-4 py-2"
            style={{ background: "var(--sisal)", color: "var(--fibre-black)" }}>
            {saving ? "Saving…" : "Create item"}
          </button>
        </form>
      )}

      <div className="flex flex-col gap-2.5">
        {items.map((item) => {
          const low = Number(item.currentStock) <= Number(item.reorderLevel);
          const isOpen = expanded === item.id;
          return (
            <div key={item.id} className="rounded-xl overflow-hidden" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
              <button onClick={() => toggleExpand(item)} className="w-full flex items-center gap-3 px-4 py-3 text-left">
                <ChevronDown size={14} className="shrink-0 transition-transform" style={{ color: "var(--slate)", transform: isOpen ? "rotate(0deg)" : "rotate(-90deg)" }} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{item.name}</p>
                  <p className="text-[11px]" style={{ color: "var(--paper-dim)" }}>{CATEGORIES[item.category] || item.category}</p>
                </div>
                <span className="font-mono text-sm">{item.currentStock} {item.unit}</span>
                {low && <span title="At or below reorder level"><AlertTriangle size={14} style={{ color: "var(--amber)" }} /></span>}
                <Badge tone={low ? "warn" : "neutral"}>{low ? "Low stock" : "OK"}</Badge>
              </button>

              {isOpen && (
                <div className="px-4 pb-4 pt-1 border-t" style={{ borderColor: "var(--divider)" }}>
                  <div className="flex items-center gap-2 mb-3 text-xs">
                    <span style={{ color: "var(--slate)" }}>Reorder level:</span>
                    {editingReorder === item.id ? (
                      <>
                        <input
                          type="number" min="0" value={reorderDraft} onChange={(e) => setReorderDraft(e.target.value)} autoFocus
                          className="rounded px-2 py-1 border w-24 font-mono" style={{ borderColor: "var(--border)" }}
                        />
                        <button onClick={() => saveReorderLevel(item)} className="font-medium" style={{ color: "var(--sisal-deep)" }}>Save</button>
                        <button onClick={() => setEditingReorder(null)} style={{ color: "var(--paper-dim)" }}>Cancel</button>
                      </>
                    ) : (
                      <>
                        <span className="font-mono">{item.reorderLevel} {item.unit}</span>
                        <button onClick={() => { setEditingReorder(item.id); setReorderDraft(String(item.reorderLevel)); }}
                          className="font-medium" style={{ color: "var(--sisal-deep)" }}>Edit</button>
                      </>
                    )}
                  </div>

                  <p className="text-[11px] font-medium mb-1.5" style={{ color: "var(--slate)" }}>Recent movements</p>
                  {!movements[item.id] ? (
                    <p className="text-xs" style={{ color: "var(--paper-dim)" }}>Loading…</p>
                  ) : movements[item.id].length === 0 ? (
                    <p className="text-xs" style={{ color: "var(--paper-dim)" }}>No movements recorded yet.</p>
                  ) : (
                    <div className="flex flex-col gap-1.5">
                      {movements[item.id].map((m) => (
                        <div key={m.id} className="flex items-center justify-between text-xs">
                          <span>
                            <Badge tone={m.type === "in" ? "live" : m.type === "out" ? "warn" : "neutral"}>{m.type}</Badge>{" "}
                            {m.quantity} {item.unit} {m.reference ? `· ${m.reference}` : ""}
                          </span>
                          <span style={{ color: "var(--paper-dim)" }}>
                            {m.recordedBy?.fullName ?? "—"} · {new Date(m.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
      {usingDemo && <p className="text-[11px] mt-3" style={{ color: "var(--paper-dim)" }}>Showing demo data — changes here won't persist.</p>}
    </div>
  );
}

/* ------------------------------------------------------------------
   WAREHOUSES TAB
------------------------------------------------------------------- */
function WarehousesTab({ token }) {
  const [warehouses, setWarehouses] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: "", location: "" });

  async function load() {
    try {
      setWarehouses(await apiGet("/warehouses", token));
      setUsingDemo(false);
    } catch {
      setWarehouses(MOCK_WAREHOUSES);
      setUsingDemo(true);
    }
  }
  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await apiPost("/warehouses", { name: form.name, location: form.location || undefined }, token);
    } catch { /* demo mode */ }
    setForm({ name: "", location: "" });
    setShowForm(false);
    setSaving(false);
    await load();
  }

  if (!warehouses) return <p className="text-sm" style={{ color: "var(--slate)" }}>Loading warehouses…</p>;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm" style={{ color: "var(--slate)" }}>{warehouses.length} warehouse{warehouses.length === 1 ? "" : "s"} registered</p>
        <button onClick={() => setShowForm((s) => !s)} className="flex items-center gap-1.5 font-display font-semibold text-xs rounded-lg px-3 py-2"
          style={{ background: "var(--fibre-black)", color: "var(--sisal)" }}>
          <Plus size={14} /> New warehouse
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="rounded-xl p-4 mb-4 flex flex-wrap items-end gap-3" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Name *</label>
            <input required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border" style={{ borderColor: "var(--border)" }} />
          </div>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Location</label>
            <input value={form.location} onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border" style={{ borderColor: "var(--border)" }} />
          </div>
          <button type="submit" disabled={saving} className="font-display font-semibold text-xs rounded-lg px-4 py-2"
            style={{ background: "var(--sisal)", color: "var(--fibre-black)" }}>
            {saving ? "Saving…" : "Register"}
          </button>
        </form>
      )}

      <div className="grid grid-cols-2 gap-3">
        {warehouses.map((w) => (
          <div key={w.id} className="rounded-xl p-4 flex items-center gap-3" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
            <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: "rgba(122,90,47,0.14)" }}>
              <WarehouseIcon size={16} style={{ color: "var(--earth-brown)" }} />
            </div>
            <div>
              <p className="text-sm font-medium">{w.name}</p>
              <p className="text-[11px]" style={{ color: "var(--paper-dim)" }}>{w.location ?? "No location set"}</p>
            </div>
          </div>
        ))}
      </div>
      {usingDemo && <p className="text-[11px] mt-3" style={{ color: "var(--paper-dim)" }}>Showing demo data.</p>}
    </div>
  );
}

/* ------------------------------------------------------------------
   STOCK ACTIONS TAB
------------------------------------------------------------------- */
function StockActionsTab({ token }) {
  const [mode, setMode] = useState("receive"); // one of STOCK_ACTIONS keys, or "transfer" / "adjust"
  const [items, setItems] = useState(MOCK_ITEMS);
  const [warehouses, setWarehouses] = useState(MOCK_WAREHOUSES);
  const [values, setValues] = useState({});
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState(null);

  useEffect(() => {
    (async () => {
      try { setItems(await apiGet("/inventory", token)); } catch {}
      try { setWarehouses(await apiGet("/warehouses", token)); } catch {}
    })();
  }, []);

  function setField(name, val) { setValues((v) => ({ ...v, [name]: val })); }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setResult(null);
    try {
      if (mode === "transfer") {
        await apiPost("/warehouses/transfer", {
          itemId: values.itemId,
          fromWarehouseId: values.fromWarehouseId,
          toWarehouseId: values.toWarehouseId,
          quantity: Number(values.quantity),
          reference: values.reference,
        }, token);
        setResult({ ok: true, message: "Transfer recorded." });
      } else if (mode === "adjust") {
        await apiPost("/warehouses/adjust", {
          itemId: values.itemId,
          quantity: Number(values.quantity),
          reason: values.reason || undefined,
          reference: values.reference || undefined,
        }, token);
        setResult({ ok: true, message: "Stock level adjusted." });
      } else {
        const action = STOCK_ACTIONS[mode];
        await apiPost(action.endpoint, {
          itemId: values.itemId,
          type: values.type || action.defaultType,
          quantity: Number(values.quantity),
          reference: values.reference || undefined,
          warehouseId: values.warehouseId || undefined,
        }, token);
        setResult({ ok: true, message: `${action.label} recorded.` });
      }
      setValues({});
    } catch (err) {
      setResult({ ok: false, message: err.message || "Couldn't reach the API — this would post once the backend is running." });
    } finally {
      setSaving(false);
    }
  }

  const allModes = [...Object.entries(STOCK_ACTIONS), ["transfer", { label: "Transfer" }], ["adjust", { label: "Adjust" }]];

  return (
    <div className="max-w-xl">
      <div className="flex flex-wrap gap-1.5 mb-5">
        {allModes.map(([key, cfg]) => (
          <button key={key} onClick={() => { setMode(key); setValues({}); setResult(null); }}
            className="text-xs font-display font-semibold rounded-full px-3 py-1.5"
            style={{ background: mode === key ? "var(--fibre-black)" : "var(--divider)", color: mode === key ? "var(--sisal)" : "var(--slate)" }}>
            {cfg.label}
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="rounded-xl p-5 flex flex-col gap-3.5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
        <div>
          <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Item *</label>
          <select required value={values.itemId ?? ""} onChange={(e) => setField("itemId", e.target.value)}
            className="text-sm rounded-lg px-3 py-2 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
            <option value="">Select item…</option>
            {items.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
          </select>
        </div>

        {mode === "transfer" ? (
          <div className="grid grid-cols-2 gap-3.5">
            <div>
              <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>From warehouse *</label>
              <select required value={values.fromWarehouseId ?? ""} onChange={(e) => setField("fromWarehouseId", e.target.value)}
                className="text-sm rounded-lg px-3 py-2 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
                <option value="">Select…</option>
                {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>To warehouse *</label>
              <select required value={values.toWarehouseId ?? ""} onChange={(e) => setField("toWarehouseId", e.target.value)}
                className="text-sm rounded-lg px-3 py-2 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
                <option value="">Select…</option>
                {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
              </select>
            </div>
          </div>
        ) : mode !== "adjust" ? (
          <div className="grid grid-cols-2 gap-3.5">
            <div>
              <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Warehouse</label>
              <select value={values.warehouseId ?? ""} onChange={(e) => setField("warehouseId", e.target.value)}
                className="text-sm rounded-lg px-3 py-2 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
                <option value="">Unspecified</option>
                {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Movement type *</label>
              <select required value={values.type ?? STOCK_ACTIONS[mode].defaultType} onChange={(e) => setField("type", e.target.value)}
                className="text-sm rounded-lg px-3 py-2 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
                <option value="in">In</option>
                <option value="out">Out</option>
                <option value="adjustment">Adjustment</option>
              </select>
            </div>
          </div>
        ) : null}

        <div className="grid grid-cols-2 gap-3.5">
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Quantity *</label>
            <input required type="number" min="0" value={values.quantity ?? ""} onChange={(e) => setField("quantity", e.target.value)}
              className="text-sm rounded-lg px-3 py-2 border w-full" style={{ borderColor: "var(--border)" }} />
          </div>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>
              {mode === "adjust" ? "Reference" : "Reference"} {mode === "transfer" && "*"}
            </label>
            <input required={mode === "transfer"} value={values.reference ?? ""} onChange={(e) => setField("reference", e.target.value)}
              placeholder="batch or invoice number" className="text-sm rounded-lg px-3 py-2 border w-full" style={{ borderColor: "var(--border)" }} />
          </div>
        </div>

        {mode === "adjust" && (
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Reason</label>
            <input value={values.reason ?? ""} onChange={(e) => setField("reason", e.target.value)}
              placeholder="e.g. stock count correction" className="text-sm rounded-lg px-3 py-2 border w-full" style={{ borderColor: "var(--border)" }} />
          </div>
        )}

        <button type="submit" disabled={saving} className="font-display font-semibold text-sm rounded-lg py-2.5 flex items-center justify-center gap-2"
          style={{ background: "var(--sisal)", color: "var(--fibre-black)" }}>
          {saving && <Loader2 size={14} className="animate-spin" />}
          {saving ? "Submitting…" : `Submit ${(STOCK_ACTIONS[mode]?.label ?? mode).toLowerCase()}`}
        </button>

        {result && <p className="text-xs" style={{ color: result.ok ? "var(--sisal-deep)" : "var(--danger)" }}>{result.message}</p>}
      </form>
    </div>
  );
}

/* ------------------------------------------------------------------
   ROOT SCREEN
------------------------------------------------------------------- */
const TABS = [
  { key: "inventory", label: "Inventory", icon: Boxes },
  { key: "warehouses", label: "Warehouses", icon: WarehouseIcon },
  { key: "actions", label: "Stock actions", icon: ArrowRightLeft },
];

export default function WarehouseScreen({ token }) {
  const [tab, setTab] = useState("inventory");

  return (
    <div>
      <div className="mb-5">
        <h1 className="font-display font-semibold text-xl">Warehouse</h1>
        <p className="text-sm mt-0.5" style={{ color: "var(--slate)" }}>
          Stock on hand, where it's held, and every movement in or out.
        </p>
      </div>

      <div className="flex gap-1.5 mb-5 border-b" style={{ borderColor: "var(--border)" }}>
        {TABS.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className="flex items-center gap-1.5 text-sm font-medium px-3.5 py-2.5 -mb-px border-b-2"
            style={{ borderColor: tab === t.key ? "var(--sisal-deep)" : "transparent", color: tab === t.key ? "var(--ink)" : "var(--slate)" }}>
            <t.icon size={14} /> {t.label}
          </button>
        ))}
      </div>

      {tab === "inventory" && <InventoryTab token={token} />}
      {tab === "warehouses" && <WarehousesTab token={token} />}
      {tab === "actions" && <StockActionsTab token={token} />}
    </div>
  );
}
