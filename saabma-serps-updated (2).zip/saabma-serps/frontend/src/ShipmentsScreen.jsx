import React, { useEffect, useState } from "react";
import { Plus, Ship, Box, FileText, Download, Loader2 } from "lucide-react";
import { apiGet, apiPost, apiPatch } from "./api";

/* ------------------------------------------------------------------
   Domain constants — mirrors backend/src/modules/shipments and
   backend/src/modules/documents entities exactly.
------------------------------------------------------------------- */
const SHIPMENT_STATUSES = ["preparing", "loaded", "in_transit", "at_port", "shipped", "delivered"];

const STATUS_LABELS = {
  preparing: "Preparing",
  loaded: "Loaded",
  in_transit: "In transit",
  at_port: "At port",
  shipped: "Shipped",
  delivered: "Delivered",
};

const DOCUMENT_TYPES = {
  packing_list: { label: "Packing list", needsShipment: true, needsInvoice: false },
  certificate_of_origin: { label: "Certificate of origin", needsShipment: true, needsInvoice: false },
  cargo_manifest: { label: "Cargo manifest", needsShipment: true, needsInvoice: false },
  delivery_note: { label: "Delivery note", needsShipment: false, needsInvoice: true },
  export_declaration: { label: "Export declaration", needsShipment: true, needsInvoice: true },
};

/* ------------------------------------------------------------------
   Mock fallback data
------------------------------------------------------------------- */
const MOCK_CUSTOMERS = [
  { id: "c1", name: "Nordic Fibre Traders AB" },
  { id: "c2", name: "Gulf Cordage Co." },
];
const MOCK_BATCHES = [
  { id: "b1", batchNumber: "SBM2507010001" },
  { id: "b3", batchNumber: "SBM2507030002" },
];
const MOCK_VEHICLES = [{ id: "v1", plateNumber: "KDA 221F", type: "Container trailer" }];
const MOCK_DRIVERS = [{ id: "dr1", fullName: "James Kamau" }];
const MOCK_INVOICES = [{ id: "i1", invoiceNumber: "INV-2026-0041" }];

const MOCK_CONTAINERS = [
  { id: "ct1", containerNumber: "MSKU7283910", sealNumber: "SL-88213", totalWeightKg: 18400 },
];

const MOCK_SHIPMENTS = [
  {
    id: "sh1",
    shipmentNumber: "SHP-2507-0012",
    customer: { name: "Nordic Fibre Traders AB" },
    container: { containerNumber: "MSKU7283910" },
    vehicle: { plateNumber: "KDA 221F" },
    driver: { fullName: "James Kamau" },
    batches: [{ batchNumber: "SBM2507010001" }, { batchNumber: "SBM2507030002" }],
    port: "Mombasa",
    status: "loaded",
    eta: "2026-07-22",
  },
];

function Badge({ children, tone = "neutral" }) {
  const tones = {
    neutral: { bg: "var(--divider)", color: "var(--slate)" },
    live: { bg: "rgba(47,107,60,0.15)", color: "var(--sisal-deep)" },
    warn: { bg: "rgba(226,163,61,0.15)", color: "#9C6A1E" },
  };
  const t = tones[tone] || tones.neutral;
  return (
    <span className="font-mono text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wide" style={{ background: t.bg, color: t.color }}>
      {children}
    </span>
  );
}

function StatusTrack({ current, onChange, disabled }) {
  const idx = SHIPMENT_STATUSES.indexOf(current);
  return (
    <div className="flex items-center gap-1">
      {SHIPMENT_STATUSES.map((st, i) => (
        <div
          key={st}
          title={STATUS_LABELS[st]}
          onClick={() => !disabled && onChange && onChange(st)}
          className="w-2.5 h-2.5 rounded-full shrink-0"
          style={{
            background: i <= idx ? "var(--sisal-deep)" : "var(--border)",
            opacity: i === idx ? 1 : i < idx ? 0.55 : 1,
            cursor: onChange && !disabled ? "pointer" : "default",
          }}
        />
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------
   SHIPMENTS TAB
------------------------------------------------------------------- */
function ShipmentsTab({ token }) {
  const [shipments, setShipments] = useState(null);
  const [customers, setCustomers] = useState(MOCK_CUSTOMERS);
  const [batches, setBatches] = useState(MOCK_BATCHES);
  const [containers, setContainers] = useState(MOCK_CONTAINERS);
  const [vehicles, setVehicles] = useState(MOCK_VEHICLES);
  const [drivers, setDrivers] = useState(MOCK_DRIVERS);
  const [usingDemo, setUsingDemo] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ customerId: "", batchIds: [], containerId: "", vehicleId: "", driverId: "", port: "", eta: "" });
  const [updatingId, setUpdatingId] = useState(null);

  async function load() {
    try {
      setShipments(await apiGet("/shipments", token));
      setUsingDemo(false);
    } catch {
      setShipments(MOCK_SHIPMENTS);
      setUsingDemo(true);
    }
    try { setCustomers(await apiGet("/customers", token)); } catch {}
    try { setBatches(await apiGet("/batches", token)); } catch {}
    try { setContainers(await apiGet("/shipments/containers", token)); } catch {}
    try { setVehicles(await apiGet("/vehicles", token)); } catch {}
    try { setDrivers(await apiGet("/drivers", token)); } catch {}
  }

  useEffect(() => { load(); }, []);

  function toggleBatch(id) {
    setForm((f) => ({
      ...f,
      batchIds: f.batchIds.includes(id) ? f.batchIds.filter((b) => b !== id) : [...f.batchIds, id],
    }));
  }

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const body = {
        customerId: form.customerId,
        batchIds: form.batchIds,
        containerId: form.containerId || undefined,
        vehicleId: form.vehicleId || undefined,
        driverId: form.driverId || undefined,
        port: form.port || undefined,
        eta: form.eta || undefined,
      };
      await apiPost("/shipments", body, token);
    } catch { /* demo mode: fall through */ }
    setForm({ customerId: "", batchIds: [], containerId: "", vehicleId: "", driverId: "", port: "", eta: "" });
    setShowForm(false);
    setSaving(false);
    await load();
  }

  async function updateStatus(shipment, status) {
    setUpdatingId(shipment.id);
    try {
      await apiPatch(`/shipments/${shipment.id}/status`, { status }, token);
      await load();
    } catch {
      setShipments((prev) => prev.map((s) => (s.id === shipment.id ? { ...s, status } : s)));
    } finally {
      setUpdatingId(null);
    }
  }

  if (!shipments) return <p className="text-sm" style={{ color: "var(--slate)" }}>Loading shipments…</p>;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm" style={{ color: "var(--slate)" }}>
          {shipments.length} shipment{shipments.length === 1 ? "" : "s"} tracked
        </p>
        <button
          onClick={() => setShowForm((s) => !s)}
          className="flex items-center gap-1.5 font-display font-semibold text-xs rounded-lg px-3 py-2"
          style={{ background: "var(--fibre-black)", color: "var(--sisal)" }}
        >
          <Plus size={14} /> New shipment
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="rounded-xl p-5 mb-4 flex flex-col gap-3.5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
          <div className="grid grid-cols-2 gap-3.5">
            <div>
              <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Customer *</label>
              <select required value={form.customerId} onChange={(e) => setForm((f) => ({ ...f, customerId: e.target.value }))}
                className="text-sm rounded-lg px-3 py-2 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
                <option value="">Select customer…</option>
                {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Container</label>
              <select value={form.containerId} onChange={(e) => setForm((f) => ({ ...f, containerId: e.target.value }))}
                className="text-sm rounded-lg px-3 py-2 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
                <option value="">None yet</option>
                {containers.map((c) => <option key={c.id} value={c.id}>{c.containerNumber}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Vehicle</label>
              <select value={form.vehicleId} onChange={(e) => setForm((f) => ({ ...f, vehicleId: e.target.value }))}
                className="text-sm rounded-lg px-3 py-2 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
                <option value="">Unassigned</option>
                {vehicles.map((v) => <option key={v.id} value={v.id}>{v.plateNumber}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Driver</label>
              <select value={form.driverId} onChange={(e) => setForm((f) => ({ ...f, driverId: e.target.value }))}
                className="text-sm rounded-lg px-3 py-2 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
                <option value="">Unassigned</option>
                {drivers.map((d) => <option key={d.id} value={d.id}>{d.fullName}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Port</label>
              <input type="text" value={form.port} onChange={(e) => setForm((f) => ({ ...f, port: e.target.value }))}
                className="text-sm rounded-lg px-3 py-2 border w-full" style={{ borderColor: "var(--border)" }} placeholder="Mombasa" />
            </div>
            <div>
              <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>ETA</label>
              <input type="date" value={form.eta} onChange={(e) => setForm((f) => ({ ...f, eta: e.target.value }))}
                className="text-sm rounded-lg px-3 py-2 border w-full" style={{ borderColor: "var(--border)" }} />
            </div>
          </div>

          <div>
            <label className="text-[11px] block mb-1.5" style={{ color: "var(--slate)" }}>Batches on this shipment *</label>
            <div className="flex flex-wrap gap-1.5">
              {batches.map((b) => {
                const on = form.batchIds.includes(b.id);
                return (
                  <button
                    type="button"
                    key={b.id}
                    onClick={() => toggleBatch(b.id)}
                    className="font-mono text-[11px] rounded-full px-2.5 py-1"
                    style={{ background: on ? "var(--fibre-black)" : "var(--divider)", color: on ? "var(--sisal)" : "var(--slate)" }}
                  >
                    {b.batchNumber}
                  </button>
                );
              })}
            </div>
          </div>

          <button type="submit" disabled={saving || !form.batchIds.length} className="font-display font-semibold text-sm rounded-lg py-2.5"
            style={{ background: "var(--sisal)", color: "var(--fibre-black)", opacity: form.batchIds.length ? 1 : 0.5 }}>
            {saving ? "Creating…" : "Create shipment"}
          </button>
        </form>
      )}

      <div className="flex flex-col gap-2.5">
        {shipments.map((sh) => (
          <div key={sh.id} className="rounded-xl p-4" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
            <div className="flex items-center justify-between mb-2.5">
              <div className="flex items-center gap-2.5">
                <span className="font-mono text-xs font-medium">{sh.shipmentNumber}</span>
                <Badge tone="live">{STATUS_LABELS[sh.status]}</Badge>
              </div>
              {sh.eta && <span className="text-[11px]" style={{ color: "var(--paper-dim)" }}>ETA {sh.eta}</span>}
            </div>
            <p className="text-sm mb-1">{sh.customer?.name ?? "—"}</p>
            <p className="text-[11px] mb-3" style={{ color: "var(--paper-dim)" }}>
              {sh.container?.containerNumber ?? "No container"} · {sh.vehicle?.plateNumber ?? "No vehicle"} · {sh.driver?.fullName ?? "No driver"} · {sh.port ?? "Port TBC"}
            </p>
            <p className="text-[11px] mb-2" style={{ color: "var(--slate)" }}>
              Batches: {sh.batches?.map((b) => b.batchNumber).join(", ") || "—"}
            </p>
            <div className="flex items-center justify-between">
              <StatusTrack current={sh.status} onChange={(st) => updateStatus(sh, st)} disabled={updatingId === sh.id} />
              {updatingId === sh.id && <Loader2 size={13} className="animate-spin" style={{ color: "var(--slate)" }} />}
            </div>
          </div>
        ))}
      </div>
      {usingDemo && <p className="text-[11px] mt-3" style={{ color: "var(--paper-dim)" }}>Showing demo data — changes here won't persist.</p>}
    </div>
  );
}

/* ------------------------------------------------------------------
   CONTAINERS TAB
------------------------------------------------------------------- */
function ContainersTab({ token }) {
  const [containers, setContainers] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ containerNumber: "", sealNumber: "", totalWeightKg: "" });

  async function load() {
    try {
      setContainers(await apiGet("/shipments/containers", token));
      setUsingDemo(false);
    } catch {
      setContainers(MOCK_CONTAINERS);
      setUsingDemo(true);
    }
  }
  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await apiPost("/shipments/containers", {
        containerNumber: form.containerNumber,
        sealNumber: form.sealNumber || undefined,
        totalWeightKg: form.totalWeightKg ? Number(form.totalWeightKg) : undefined,
      }, token);
    } catch { /* demo mode */ }
    setForm({ containerNumber: "", sealNumber: "", totalWeightKg: "" });
    setShowForm(false);
    setSaving(false);
    await load();
  }

  if (!containers) return <p className="text-sm" style={{ color: "var(--slate)" }}>Loading containers…</p>;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm" style={{ color: "var(--slate)" }}>{containers.length} container{containers.length === 1 ? "" : "s"} registered</p>
        <button onClick={() => setShowForm((s) => !s)} className="flex items-center gap-1.5 font-display font-semibold text-xs rounded-lg px-3 py-2"
          style={{ background: "var(--fibre-black)", color: "var(--sisal)" }}>
          <Plus size={14} /> New container
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="rounded-xl p-4 mb-4 flex flex-wrap items-end gap-3" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Container number *</label>
            <input required value={form.containerNumber} onChange={(e) => setForm((f) => ({ ...f, containerNumber: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border" style={{ borderColor: "var(--border)" }} placeholder="MSKU7283910" />
          </div>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Seal number</label>
            <input value={form.sealNumber} onChange={(e) => setForm((f) => ({ ...f, sealNumber: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border" style={{ borderColor: "var(--border)" }} />
          </div>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Total weight (kg)</label>
            <input type="number" min="0" value={form.totalWeightKg} onChange={(e) => setForm((f) => ({ ...f, totalWeightKg: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border w-36" style={{ borderColor: "var(--border)" }} />
          </div>
          <button type="submit" disabled={saving} className="font-display font-semibold text-xs rounded-lg px-4 py-2"
            style={{ background: "var(--sisal)", color: "var(--fibre-black)" }}>
            {saving ? "Saving…" : "Register"}
          </button>
        </form>
      )}

      <div className="rounded-xl overflow-hidden" style={{ border: "1px solid var(--border)", background: "#FFFFFF" }}>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: "var(--surface-tint)" }}>
              <th className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>Container</th>
              <th className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>Seal</th>
              <th className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>Weight</th>
            </tr>
          </thead>
          <tbody>
            {containers.map((c) => (
              <tr key={c.id} style={{ borderTop: "1px solid var(--divider)" }}>
                <td className="px-4 py-3 font-mono text-xs">{c.containerNumber}</td>
                <td className="px-4 py-3 font-mono text-xs" style={{ color: "var(--paper-dim)" }}>{c.sealNumber ?? "—"}</td>
                <td className="px-4 py-3 font-mono text-xs">{c.totalWeightKg ?? 0} kg</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {usingDemo && <p className="text-[11px] mt-3" style={{ color: "var(--paper-dim)" }}>Showing demo data.</p>}
    </div>
  );
}

/* ------------------------------------------------------------------
   EXPORT DOCUMENTS TAB
------------------------------------------------------------------- */
function DocumentsTab({ token }) {
  const [docType, setDocType] = useState("packing_list");
  const [shipments, setShipments] = useState(MOCK_SHIPMENTS);
  const [invoices, setInvoices] = useState(MOCK_INVOICES);
  const [shipmentId, setShipmentId] = useState("");
  const [invoiceId, setInvoiceId] = useState("");
  const [generating, setGenerating] = useState(false);
  const [generated, setGenerated] = useState(null); // { id, documentNumber } | null
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      try { setShipments(await apiGet("/shipments", token)); } catch {}
      try { setInvoices(await apiGet("/invoices", token)); } catch {}
    })();
  }, []);

  const cfg = DOCUMENT_TYPES[docType];

  async function handleGenerate(e) {
    e.preventDefault();
    setGenerating(true);
    setError("");
    setGenerated(null);
    try {
      const doc = await apiPost("/documents/generate", {
        type: docType,
        shipmentId: cfg.needsShipment ? shipmentId : undefined,
        invoiceId: cfg.needsInvoice ? invoiceId : undefined,
      }, token);
      setGenerated(doc);
    } catch (err) {
      setError(err.message || "Couldn't reach the API — this generates a real PDF once the backend is running.");
    } finally {
      setGenerating(false);
    }
  }

  return (
    <div className="max-w-xl">
      <div className="flex flex-wrap gap-1.5 mb-5">
        {Object.entries(DOCUMENT_TYPES).map(([key, c]) => (
          <button key={key} onClick={() => { setDocType(key); setGenerated(null); setError(""); }}
            className="text-xs font-display font-semibold rounded-full px-3 py-1.5"
            style={{ background: docType === key ? "var(--fibre-black)" : "var(--divider)", color: docType === key ? "var(--sisal)" : "var(--slate)" }}>
            {c.label}
          </button>
        ))}
      </div>

      <form onSubmit={handleGenerate} className="rounded-xl p-5 flex flex-col gap-3.5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
        {cfg.needsShipment && (
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Shipment *</label>
            <select required value={shipmentId} onChange={(e) => setShipmentId(e.target.value)}
              className="text-sm rounded-lg px-3 py-2 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
              <option value="">Select shipment…</option>
              {shipments.map((s) => <option key={s.id} value={s.id}>{s.shipmentNumber}</option>)}
            </select>
          </div>
        )}
        {cfg.needsInvoice && (
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>
              Invoice {docType === "export_declaration" ? "(optional, for declared value)" : "*"}
            </label>
            <select required={docType !== "export_declaration"} value={invoiceId} onChange={(e) => setInvoiceId(e.target.value)}
              className="text-sm rounded-lg px-3 py-2 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
              <option value="">Select invoice…</option>
              {invoices.map((i) => <option key={i.id} value={i.id}>{i.invoiceNumber}</option>)}
            </select>
          </div>
        )}

        <button type="submit" disabled={generating} className="font-display font-semibold text-sm rounded-lg py-2.5 flex items-center justify-center gap-2"
          style={{ background: "var(--sisal)", color: "var(--fibre-black)" }}>
          {generating && <Loader2 size={14} className="animate-spin" />}
          {generating ? "Generating…" : `Generate ${cfg.label.toLowerCase()}`}
        </button>

        {error && <p className="text-xs" style={{ color: "var(--danger)" }}>{error}</p>}
        {generated && (
          <div className="flex items-center gap-2 rounded-lg px-3.5 py-2.5" style={{ background: "rgba(47,107,60,0.08)" }}>
            <FileText size={14} style={{ color: "var(--sisal-deep)" }} />
            <span className="text-xs flex-1">{generated.documentNumber ?? "Document"} generated</span>
            {generated.id && (
              <a href={`http://localhost:3000/documents/${generated.id}/download`} target="_blank" rel="noreferrer"
                className="flex items-center gap-1 text-xs font-medium" style={{ color: "var(--sisal-deep)" }}>
                <Download size={13} /> Download
              </a>
            )}
          </div>
        )}
      </form>
    </div>
  );
}

/* ------------------------------------------------------------------
   ROOT SCREEN
------------------------------------------------------------------- */
const TABS = [
  { key: "shipments", label: "Shipments", icon: Ship },
  { key: "containers", label: "Containers", icon: Box },
  { key: "documents", label: "Export documents", icon: FileText },
];

export default function ShipmentsScreen({ token }) {
  const [tab, setTab] = useState("shipments");

  return (
    <div>
      <div className="mb-5">
        <h1 className="font-display font-semibold text-xl">Shipments</h1>
        <p className="text-sm mt-0.5" style={{ color: "var(--slate)" }}>
          Every container from gate to port, and the export paperwork it needs to leave.
        </p>
      </div>

      <div className="flex gap-1.5 mb-5 border-b" style={{ borderColor: "var(--border)" }}>
        {TABS.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className="flex items-center gap-1.5 text-sm font-medium px-3.5 py-2.5 -mb-px border-b-2"
            style={{ borderColor: tab === t.key ? "var(--sisal-deep)" : "transparent", color: tab === t.key ? "var(--ink)" : "var(--slate)" }}>
            <t.icon size={14} /> {t.label}
          </button>
        ))}
      </div>

      {tab === "shipments" && <ShipmentsTab token={token} />}
      {tab === "containers" && <ContainersTab token={token} />}
      {tab === "documents" && <DocumentsTab token={token} />}
    </div>
  );
}
