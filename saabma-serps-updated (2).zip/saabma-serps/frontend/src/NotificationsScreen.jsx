import React, { useEffect, useState } from "react";
import { Loader2, Bell, CheckCheck, Package, AlertTriangle, Truck, Receipt, ClipboardCheck } from "lucide-react";
import { apiGet, apiPatch } from "./api";

/* ------------------------------------------------------------------
   Mirrors backend/src/modules/notifications exactly. Every call is
   scoped to the logged-in user via the JWT (no id param needed):
     GET   /notifications
     GET   /notifications/unread
     PATCH /notifications/read-all
     PATCH /notifications/:id/read
------------------------------------------------------------------- */

const TYPE_ICON = {
  invoice_paid: Receipt,
  low_stock: AlertTriangle,
  attendance_missing: ClipboardCheck,
  shipment_loaded: Truck,
  approval_needed: ClipboardCheck,
  general: Bell,
};

const MOCK_NOTIFICATIONS = [
  { id: "n1", type: "approval_needed", message: "Baling record #B-2291 is waiting on your approval", linkRef: "/production", isRead: false, createdAt: new Date(Date.now() - 1000 * 60 * 14).toISOString() },
  { id: "n2", type: "low_stock", message: "Sisal bales at Warehouse 2 have dropped below the reorder point", linkRef: "/warehouse", isRead: false, createdAt: new Date(Date.now() - 1000 * 60 * 55).toISOString() },
  { id: "n3", type: "invoice_paid", message: "Invoice INV-1042 was marked paid by Finance", linkRef: "/sales", isRead: true, createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString() },
  { id: "n4", type: "shipment_loaded", message: "Container MSCU-771244 finished loading at the port", linkRef: "/shipments", isRead: true, createdAt: new Date(Date.now() - 1000 * 60 * 60 * 22).toISOString() },
];

function timeAgo(iso) {
  const mins = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

export default function NotificationsScreen({ token }) {
  const [items, setItems] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [filter, setFilter] = useState("all");

  async function load() {
    try {
      const list = await apiGet("/notifications", token);
      setItems(list);
      setUsingDemo(false);
    } catch {
      setItems(MOCK_NOTIFICATIONS);
      setUsingDemo(true);
    }
  }

  useEffect(() => { load(); }, []);

  async function markRead(id) {
    setItems((cur) => cur.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
    try {
      await apiPatch(`/notifications/${id}/read`, {}, token);
    } catch { /* demo mode / already local */ }
  }

  async function markAllRead() {
    setItems((cur) => cur.map((n) => ({ ...n, isRead: true })));
    try {
      await apiPatch("/notifications/read-all", {}, token);
    } catch { /* demo mode */ }
  }

  if (!items) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="animate-spin" size={20} style={{ color: "var(--sisal)" }} />
      </div>
    );
  }

  const unreadCount = items.filter((n) => !n.isRead).length;
  const visible = filter === "unread" ? items.filter((n) => !n.isRead) : items;

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="font-display font-semibold text-xl">Notifications</h1>
          <p className="text-sm mt-0.5" style={{ color: "var(--slate)" }}>
            {unreadCount} unread
            {usingDemo && <span className="font-mono text-[10px] px-2 py-0.5 rounded-full ml-2" style={{ background: "rgba(226,163,61,0.15)", color: "#9C6A1E" }}>DEMO DATA</span>}
          </p>
        </div>
        {unreadCount > 0 && (
          <button onClick={markAllRead} className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium" style={{ color: "var(--sisal-deep)" }}>
            <CheckCheck size={15} /> Mark all read
          </button>
        )}
      </div>

      <div className="flex gap-1.5 mb-5 border-b" style={{ borderColor: "var(--border)" }}>
        {[{ key: "all", label: `All (${items.length})` }, { key: "unread", label: `Unread (${unreadCount})` }].map((t) => (
          <button
            key={t.key}
            onClick={() => setFilter(t.key)}
            className="px-3 py-2 text-sm font-medium border-b-2 -mb-px"
            style={{ borderColor: filter === t.key ? "var(--sisal)" : "transparent", color: filter === t.key ? "var(--ink)" : "var(--slate)" }}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-2">
        {visible.length === 0 ? (
          <p className="text-sm text-center py-16" style={{ color: "var(--slate)" }}>Nothing here.</p>
        ) : (
          visible.map((n) => {
            const Icon = TYPE_ICON[n.type] || Bell;
            return (
              <button
                key={n.id}
                onClick={() => !n.isRead && markRead(n.id)}
                className="flex items-start gap-3 rounded-xl p-3.5 text-left"
                style={{ background: n.isRead ? "#FFFFFF" : "rgba(47,107,60,0.06)", border: "1px solid var(--border)" }}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0" style={{ background: n.isRead ? "var(--divider)" : "rgba(47,107,60,0.15)", color: n.isRead ? "var(--slate)" : "var(--sisal-deep)" }}>
                  <Icon size={14} />
                </div>
                <div className="flex-1">
                  <p className="text-sm" style={{ fontWeight: n.isRead ? 400 : 500 }}>{n.message}</p>
                  <p className="text-[11px] mt-1" style={{ color: "var(--paper-dim)" }}>{timeAgo(n.createdAt)}</p>
                </div>
                {!n.isRead && <div className="w-2 h-2 rounded-full mt-1.5 shrink-0" style={{ background: "var(--sisal)" }} />}
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}
