export const API_BASE_URL = "http://localhost:3000";

// When a request comes back 401, that means this specific token is no
// longer valid - expired, or superseded by a login elsewhere (single-
// session enforcement). That is meaningfully different from "the backend
// is unreachable" (which is when screens fall back to demo data) and
// should force a real sign-out with an explanation, not a silent slide
// into fake data. Screens don't each need to know this - they just call
// apiGet/apiPost as before; the app shell subscribes once here.
let unauthorizedHandler = null;
export function onUnauthorized(handler) {
  unauthorizedHandler = handler;
}

async function request(path, { token, method = "GET", body } = {}) {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const payload = await res.json().catch(() => null);
    if (res.status === 401 && token && unauthorizedHandler) {
      unauthorizedHandler(payload?.message || "Your session is no longer valid.");
    }
    const err = new Error(payload?.message || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return res.json();
}

export const apiGet = (path, token) => request(path, { token });
export const apiPost = (path, body, token) => request(path, { token, method: "POST", body });
export const apiPatch = (path, body, token) => request(path, { token, method: "PATCH", body });
