import React, { useEffect, useMemo, useState } from "react";
import {
  Plus,
  Check,
  X,
  Loader2,
  PackageSearch,
  ClipboardCheck,
  FilePlus2,
  ChevronDown,
} from "lucide-react";
import { apiGet, apiPost, apiPatch } from "./api";

/* ------------------------------------------------------------------
   Domain constants — mirrors backend/src/modules/batches/entities/batch.entity.ts
   and the six stage-record modules exactly.
------------------------------------------------------------------- */
const STAGE_ORDER = ["received", "soaking", "washing", "drying", "brushing", "baling", "warehouse", "shipped"];

const STAGE_LABELS = {
  received: "Received",
  soaking: "Soaking",
  washing: "Washing",
  drying: "Drying",
  brushing: "Brushing",
  baling: "Baling",
  warehouse: "Warehouse",
  shipped: "Shipped",
};

// The six loggable/reviewable record types (each has its own controller:
// POST /, GET /pending, PATCH /:id/review).
const RECORD_TYPES = {
  soaking: {
    label: "Soaking",
    endpoint: "/soaking",
    metric: (r) => `${r.kg ?? "—"} kg`,
    fields: [
      { name: "date", label: "Date", type: "date", required: true },
      { name: "kg", label: "Weight (kg)", type: "number", required: true },
      { name: "soakingDurationHours", label: "Duration (hours)", type: "number" },
      { name: "remarks", label: "Remarks", type: "text" },
    ],
  },
  washing: {
    label: "Washing",
    endpoint: "/washing",
    metric: (r) => `${r.kg ?? "—"} kg`,
    fields: [
      { name: "date", label: "Date", type: "date", required: true },
      { name: "kg", label: "Weight (kg)", type: "number", required: true },
      { name: "hydrogenUsedKg", label: "Hydrogen used (kg)", type: "number", required: true },
      { name: "fee", label: "Fee", type: "number", required: true },
      { name: "remarks", label: "Remarks", type: "text" },
    ],
  },
  drying: {
    label: "Drying",
    endpoint: "/drying",
    metric: (r) => `${r.weightBeforeKg ?? "—"} → ${r.weightAfterKg ?? "—"} kg`,
    fields: [
      { name: "date", label: "Date", type: "date", required: true },
      { name: "weightBeforeKg", label: "Weight before (kg)", type: "number", required: true },
      { name: "weightAfterKg", label: "Weight after (kg)", type: "number" },
      { name: "method", label: "Method (sun-dried, machine-dried…)", type: "text" },
      { name: "remarks", label: "Remarks", type: "text" },
    ],
  },
  production: {
    label: "Production",
    endpoint: "/production",
    metric: (r) => `${r.boxes ?? 0} boxes · ${r.weightKg ?? 0} kg`,
    fields: [
      { name: "date", label: "Date", type: "date", required: true },
      { name: "shift", label: "Shift", type: "text", required: true },
      { name: "machine", label: "Machine", type: "text" },
      { name: "boxes", label: "Boxes", type: "number", required: true },
      { name: "weightKg", label: "Weight (kg)", type: "number", required: true },
      { name: "remarks", label: "Remarks", type: "text" },
    ],
  },
  brushing: {
    label: "Brushing",
    endpoint: "/brushing",
    metric: (r) => `${r.boxes ?? 0} boxes · ${r.weightKg ?? 0} kg`,
    fields: [
      { name: "date", label: "Date", type: "date", required: true },
      { name: "machine", label: "Machine", type: "text", required: true },
      { name: "shift", label: "Shift", type: "text", required: true },
      { name: "boxes", label: "Boxes", type: "number", required: true },
      { name: "weightKg", label: "Weight (kg)", type: "number", required: true },
      { name: "supervisorId", label: "Supervisor employee ID", type: "text" },
    ],
  },
  baling: {
    label: "Baling",
    endpoint: "/baling",
    metric: (r) => `${r.numberOfBales ?? 0} bales · ${r.totalWeightKg ?? 0} kg`,
    fields: [
      { name: "date", label: "Date", type: "date", required: true },
      { name: "numberOfBales", label: "Number of bales", type: "number", required: true },
      { name: "totalWeightKg", label: "Total weight (kg)", type: "number", required: true },
      { name: "baleTagPrefix", label: "Bale tag prefix", type: "text" },
    ],
  },
};

/* ------------------------------------------------------------------
   Mock fallback data — used only when the API isn't reachable, so the
   screen is never empty while wiring up a live backend.
------------------------------------------------------------------- */
const MOCK_BATCHES = [
  { id: "b1", batchNumber: "SBM2507010001", currentStage: "brushing", rawWeightKg: 1250, createdAt: new Date(Date.now() - 86400000 * 4).toISOString() },
  { id: "b2", batchNumber: "SBM2507020004", currentStage: "washing", rawWeightKg: 980, createdAt: new Date(Date.now() - 86400000 * 2).toISOString() },
  { id: "b3", batchNumber: "SBM2507030002", currentStage: "baling", rawWeightKg: 1510, createdAt: new Date(Date.now() - 86400000 * 6).toISOString() },
  { id: "b4", batchNumber: "SBM2507040001", currentStage: "received", rawWeightKg: 640, createdAt: new Date(Date.now() - 3600000 * 5).toISOString() },
];

const MOCK_EMPLOYEES = [
  { id: "e1", fullName: "Peter Kiptoo", employeeCode: "EMP-014" },
  { id: "e2", fullName: "Grace Muthoni", employeeCode: "EMP-028" },
  { id: "e3", fullName: "Samuel Otieno", employeeCode: "EMP-007" },
];

const MOCK_PENDING = {
  soaking: [{ id: "s1", batch: { batchNumber: "SBM2507040001" }, operator: { fullName: "Grace Muthoni" }, date: "2026-07-10", kg: 640, status: "pending" }],
  washing: [],
  drying: [{ id: "d1", batch: { batchNumber: "SBM2507020004" }, operator: { fullName: "Peter Kiptoo" }, date: "2026-07-09", weightBeforeKg: 900, weightAfterKg: 810, status: "pending" }],
  production: [],
  brushing: [{ id: "br1", batch: { batchNumber: "SBM2507010001" }, operator: { fullName: "Samuel Otieno" }, date: "2026-07-08", boxes: 22, weightKg: 410, status: "pending" }],
  baling: [],
};

function StagePipeline({ current }) {
  const idx = STAGE_ORDER.indexOf(current);
  return (
    <div className="flex items-center gap-1">
      {STAGE_ORDER.map((stage, i) => (
        <React.Fragment key={stage}>
          <div
            title={STAGE_LABELS[stage]}
            className="w-2.5 h-2.5 rounded-full shrink-0"
            style={{
              background: i <= idx ? "var(--sisal-deep)" : "var(--border)",
              opacity: i === idx ? 1 : i < idx ? 0.55 : 1,
            }}
          />
          {i < STAGE_ORDER.length - 1 && (
            <div className="h-[2px] w-3" style={{ background: i < idx ? "var(--sisal-deep)" : "var(--border)", opacity: 0.55 }} />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function Badge({ children, tone = "neutral" }) {
  const tones = {
    neutral: { bg: "var(--divider)", color: "var(--slate)" },
    pending: { bg: "rgba(226,163,61,0.15)", color: "#9C6A1E" },
    approved: { bg: "rgba(47,107,60,0.15)", color: "var(--sisal-deep)" },
    rejected: { bg: "rgba(165,78,42,0.12)", color: "var(--danger)" },
  };
  const t = tones[tone] || tones.neutral;
  return (
    <span
      className="font-mono text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wide"
      style={{ background: t.bg, color: t.color }}
    >
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------
   BATCHES TAB
------------------------------------------------------------------- */
function BatchesTab({ token }) {
  const [batches, setBatches] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [showNewForm, setShowNewForm] = useState(false);
  const [form, setForm] = useState({ rawWeightKg: "", notes: "" });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  async function load() {
    try {
      const list = await apiGet("/batches", token);
      setBatches(list);
      setUsingDemo(false);
    } catch {
      setBatches(MOCK_BATCHES);
      setUsingDemo(true);
    }
  }

  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    setErr("");
    try {
      await apiPost("/batches", { rawWeightKg: Number(form.rawWeightKg), notes: form.notes || undefined }, token);
      setForm({ rawWeightKg: "", notes: "" });
      setShowNewForm(false);
      await load();
    } catch (e2) {
      setErr(usingDemo ? "" : e2.message);
      setShowNewForm(false);
      setForm({ rawWeightKg: "", notes: "" });
    } finally {
      setSaving(false);
    }
  }

  if (!batches) {
    return <p className="text-sm" style={{ color: "var(--slate)" }}>Loading batches…</p>;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm" style={{ color: "var(--slate)" }}>
          {batches.length} batch{batches.length === 1 ? "" : "es"} in the pipeline
        </p>
        <button
          onClick={() => setShowNewForm((s) => !s)}
          className="flex items-center gap-1.5 font-display font-semibold text-xs rounded-lg px-3 py-2"
          style={{ background: "var(--fibre-black)", color: "var(--sisal)" }}
        >
          <Plus size={14} /> New batch
        </button>
      </div>

      {showNewForm && (
        <form
          onSubmit={handleCreate}
          className="rounded-xl p-4 mb-4 flex flex-wrap items-end gap-3"
          style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}
        >
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Raw weight (kg)</label>
            <input
              required
              type="number"
              min="0"
              value={form.rawWeightKg}
              onChange={(e) => setForm((f) => ({ ...f, rawWeightKg: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border w-40"
              style={{ borderColor: "var(--border)" }}
            />
          </div>
          <div className="flex-1 min-w-[180px]">
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Notes (optional)</label>
            <input
              type="text"
              value={form.notes}
              onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border w-full"
              style={{ borderColor: "var(--border)" }}
            />
          </div>
          <button
            type="submit"
            disabled={saving}
            className="font-display font-semibold text-xs rounded-lg px-4 py-2"
            style={{ background: "var(--sisal)", color: "var(--fibre-black)" }}
          >
            {saving ? "Saving…" : "Create batch"}
          </button>
        </form>
      )}
      {err && <p className="text-xs mb-3" style={{ color: "var(--danger)" }}>{err}</p>}

      <div className="rounded-xl overflow-hidden" style={{ border: "1px solid var(--border)", background: "#FFFFFF" }}>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: "var(--surface-tint)" }}>
              <th className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>Batch</th>
              <th className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>Raw weight</th>
              <th className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>Pipeline</th>
              <th className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>Stage</th>
              <th className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>Created</th>
            </tr>
          </thead>
          <tbody>
            {batches.map((b) => (
              <tr key={b.id} style={{ borderTop: "1px solid var(--divider)" }}>
                <td className="px-4 py-3 font-mono text-xs">{b.batchNumber}</td>
                <td className="px-4 py-3 font-mono text-xs">{b.rawWeightKg} kg</td>
                <td className="px-4 py-3"><StagePipeline current={b.currentStage} /></td>
                <td className="px-4 py-3"><Badge>{STAGE_LABELS[b.currentStage] || b.currentStage}</Badge></td>
                <td className="px-4 py-3 text-xs" style={{ color: "var(--paper-dim)" }}>
                  {new Date(b.createdAt).toLocaleDateString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------
   PENDING APPROVALS TAB
------------------------------------------------------------------- */
function PendingTab({ token }) {
  const [items, setItems] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [reviewerId, setReviewerId] = useState("");
  const [busyId, setBusyId] = useState(null);

  async function load() {
    try {
      const entries = await Promise.all(
        Object.entries(RECORD_TYPES).map(async ([key, cfg]) => {
          const list = await apiGet(`${cfg.endpoint}/pending`, token);
          return list.map((r) => ({ ...r, __type: key }));
        })
      );
      setItems(entries.flat());
      setUsingDemo(false);
    } catch {
      const entries = Object.entries(MOCK_PENDING).flatMap(([key, list]) => list.map((r) => ({ ...r, __type: key })));
      setItems(entries);
      setUsingDemo(true);
    }
  }

  useEffect(() => { load(); }, []);

  async function decide(item, decision) {
    setBusyId(item.id);
    try {
      const cfg = RECORD_TYPES[item.__type];
      await apiPatch(`${cfg.endpoint}/${item.id}/review`, { reviewerEmployeeId: reviewerId, decision }, token);
      await load();
    } catch {
      // Demo mode / offline: reflect the decision locally so review still feels real.
      setItems((prev) => (prev ? prev.filter((i) => i.id !== item.id) : prev));
    } finally {
      setBusyId(null);
    }
  }

  if (!items) return <p className="text-sm" style={{ color: "var(--slate)" }}>Loading pending approvals…</p>;

  return (
    <div>
      <div
        className="rounded-xl p-4 mb-4 flex items-center gap-3"
        style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}
      >
        <label className="text-xs whitespace-nowrap" style={{ color: "var(--slate)" }}>Reviewing as (employee ID)</label>
        <input
          value={reviewerId}
          onChange={(e) => setReviewerId(e.target.value)}
          placeholder="e.g. 3fbb2b3e-…"
          className="text-sm rounded-lg px-3 py-1.5 border flex-1 font-mono text-xs"
          style={{ borderColor: "var(--border)" }}
        />
      </div>

      {items.length === 0 ? (
        <p className="text-sm" style={{ color: "var(--paper-dim)" }}>Nothing waiting on review right now.</p>
      ) : (
        <div className="flex flex-col gap-2.5">
          {items.map((item) => (
            <div
              key={`${item.__type}-${item.id}`}
              className="rounded-xl p-4 flex items-center gap-4"
              style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}
            >
              <Badge>{RECORD_TYPES[item.__type].label}</Badge>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">
                  {item.batch?.batchNumber ?? "Batch"} · {RECORD_TYPES[item.__type].metric(item)}
                </p>
                <p className="text-[11px]" style={{ color: "var(--paper-dim)" }}>
                  {item.operator?.fullName ?? "Unknown operator"} · {item.date}
                </p>
              </div>
              <button
                disabled={busyId === item.id || !reviewerId}
                onClick={() => decide(item, "approved")}
                className="flex items-center gap-1 text-xs font-display font-semibold rounded-lg px-3 py-1.5"
                style={{ background: "rgba(47,107,60,0.15)", color: "var(--sisal-deep)", opacity: reviewerId ? 1 : 0.5 }}
              >
                <Check size={13} /> Approve
              </button>
              <button
                disabled={busyId === item.id || !reviewerId}
                onClick={() => decide(item, "rejected")}
                className="flex items-center gap-1 text-xs font-display font-semibold rounded-lg px-3 py-1.5"
                style={{ background: "rgba(165,78,42,0.12)", color: "var(--danger)", opacity: reviewerId ? 1 : 0.5 }}
              >
                <X size={13} /> Reject
              </button>
            </div>
          ))}
        </div>
      )}
      {usingDemo && (
        <p className="text-[11px] mt-3" style={{ color: "var(--paper-dim)" }}>
          Showing demo data — approve/reject here just removes the item locally.
        </p>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------
   LOG A RECORD TAB
------------------------------------------------------------------- */
function LogRecordTab({ token }) {
  const [stageKey, setStageKey] = useState("soaking");
  const [batches, setBatches] = useState(MOCK_BATCHES);
  const [employees, setEmployees] = useState(MOCK_EMPLOYEES);
  const [values, setValues] = useState({ batchId: "", operatorId: "" });
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState(null); // { ok: bool, message }

  useEffect(() => {
    (async () => {
      try {
        setBatches(await apiGet("/batches", token));
      } catch { /* keep mock */ }
      try {
        setEmployees(await apiGet("/employees", token));
      } catch { /* keep mock */ }
    })();
  }, []);

  const cfg = RECORD_TYPES[stageKey];

  function setField(name, val) {
    setValues((v) => ({ ...v, [name]: val }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setResult(null);
    const body = { batchId: values.batchId, operatorId: values.operatorId };
    for (const f of cfg.fields) {
      if (values[f.name] === undefined || values[f.name] === "") continue;
      body[f.name] = f.type === "number" ? Number(values[f.name]) : values[f.name];
    }
    try {
      await apiPost(cfg.endpoint, body, token);
      setResult({ ok: true, message: `${cfg.label} record submitted for review.` });
      setValues({ batchId: "", operatorId: "" });
    } catch (err) {
      setResult({ ok: false, message: err.message || "Could not reach the API — this would submit once the backend is running." });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-xl">
      <div className="flex flex-wrap gap-1.5 mb-5">
        {Object.entries(RECORD_TYPES).map(([key, c]) => (
          <button
            key={key}
            onClick={() => { setStageKey(key); setResult(null); }}
            className="text-xs font-display font-semibold rounded-full px-3 py-1.5"
            style={{
              background: stageKey === key ? "var(--fibre-black)" : "var(--divider)",
              color: stageKey === key ? "var(--sisal)" : "var(--slate)",
            }}
          >
            {c.label}
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="rounded-xl p-5 flex flex-col gap-3.5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
        <div className="grid grid-cols-2 gap-3.5">
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Batch</label>
            <select
              required
              value={values.batchId}
              onChange={(e) => setField("batchId", e.target.value)}
              className="text-sm rounded-lg px-3 py-2 border w-full bg-white"
              style={{ borderColor: "var(--border)" }}
            >
              <option value="">Select batch…</option>
              {batches.map((b) => (
                <option key={b.id} value={b.id}>{b.batchNumber}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Operator</label>
            <select
              required
              value={values.operatorId}
              onChange={(e) => setField("operatorId", e.target.value)}
              className="text-sm rounded-lg px-3 py-2 border w-full bg-white"
              style={{ borderColor: "var(--border)" }}
            >
              <option value="">Select employee…</option>
              {employees.map((e) => (
                <option key={e.id} value={e.id}>{e.fullName} ({e.employeeCode})</option>
              ))}
            </select>
          </div>
        </div>

        {cfg.fields.map((f) => (
          <div key={f.name}>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>
              {f.label}{f.required && " *"}
            </label>
            <input
              type={f.type === "number" ? "number" : f.type === "date" ? "date" : "text"}
              required={f.required}
              min={f.type === "number" ? 0 : undefined}
              value={values[f.name] ?? ""}
              onChange={(e) => setField(f.name, e.target.value)}
              className="text-sm rounded-lg px-3 py-2 border w-full"
              style={{ borderColor: "var(--border)" }}
            />
          </div>
        ))}

        <button
          type="submit"
          disabled={saving}
          className="font-display font-semibold text-sm rounded-lg py-2.5 mt-1"
          style={{ background: "var(--sisal)", color: "var(--fibre-black)" }}
        >
          {saving ? "Submitting…" : `Submit ${cfg.label.toLowerCase()} record`}
        </button>

        {result && (
          <p className="text-xs" style={{ color: result.ok ? "var(--sisal-deep)" : "var(--danger)" }}>
            {result.message}
          </p>
        )}
      </form>
    </div>
  );
}

/* ------------------------------------------------------------------
   ROOT SCREEN
------------------------------------------------------------------- */
const TABS = [
  { key: "batches", label: "Batches", icon: PackageSearch },
  { key: "pending", label: "Pending approvals", icon: ClipboardCheck },
  { key: "log", label: "Log a record", icon: FilePlus2 },
];

export default function ProductionScreen({ token }) {
  const [tab, setTab] = useState("batches");

  return (
    <div>
      <div className="mb-5">
        <h1 className="font-display font-semibold text-xl">Production</h1>
        <p className="text-sm mt-0.5" style={{ color: "var(--slate)" }}>
          Batches move soaking → washing → drying → brushing → baling → warehouse, each stage reviewed before it advances.
        </p>
      </div>

      <div className="flex gap-1.5 mb-5 border-b" style={{ borderColor: "var(--border)" }}>
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className="flex items-center gap-1.5 text-sm font-medium px-3.5 py-2.5 -mb-px border-b-2"
            style={{
              borderColor: tab === t.key ? "var(--sisal-deep)" : "transparent",
              color: tab === t.key ? "var(--ink)" : "var(--slate)",
            }}
          >
            <t.icon size={14} /> {t.label}
          </button>
        ))}
      </div>

      {tab === "batches" && <BatchesTab token={token} />}
      {tab === "pending" && <PendingTab token={token} />}
      {tab === "log" && <LogRecordTab token={token} />}
    </div>
  );
}
