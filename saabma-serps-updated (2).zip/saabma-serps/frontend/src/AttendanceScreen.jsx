import React, { useEffect, useState } from "react";
import { Loader2, BellRing, CheckCircle2 } from "lucide-react";
import { apiGet, apiPost } from "./api";

/* ------------------------------------------------------------------
   Mirrors backend/src/modules/attendance exactly:
     GET  /attendance                     (HR/CEO/Operations Manager only)
     GET  /attendance/missing-today       (same roles)
     POST /attendance/notify-missing-today
     GET  /attendance/employee/:employeeId

   Records are populated by the fingerprint door-controller integration,
   not typed in by hand — so this screen is read + notify only, no
   "create attendance record" form (there's no such endpoint, and there
   shouldn't be one: faking manual entry would undermine the point of
   biometric tracking).
------------------------------------------------------------------- */

const MOCK_RECORDS = [
  { id: "a1", employee: { employeeCode: "EMP-014", fullName: "Peter Kiptoo" }, date: "2026-07-14", timeIn: "2026-07-14T06:02:00Z", timeOut: null, hoursWorked: 0, isLate: false, overtimeHours: 0 },
  { id: "a2", employee: { employeeCode: "EMP-028", fullName: "Grace Muthoni" }, date: "2026-07-14", timeIn: "2026-07-14T06:24:00Z", timeOut: null, hoursWorked: 0, isLate: true, overtimeHours: 0 },
  { id: "a3", employee: { employeeCode: "EMP-007", fullName: "Samuel Otieno" }, date: "2026-07-13", timeIn: "2026-07-13T05:58:00Z", timeOut: "2026-07-13T14:10:00Z", hoursWorked: 8.2, isLate: false, overtimeHours: 0.2 },
];

const MOCK_MISSING = [
  { id: "e4", employeeCode: "EMP-041", fullName: "Faith Nyambura", position: "Warehouse clerk" },
  { id: "e9", employeeCode: "EMP-063", fullName: "John Kamau", position: "Brushing operator" },
];

function fmtTime(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleTimeString("en-KE", { hour: "2-digit", minute: "2-digit" });
}

export default function AttendanceScreen({ token }) {
  const [tab, setTab] = useState("today");
  const [records, setRecords] = useState(null);
  const [missing, setMissing] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [notifying, setNotifying] = useState(false);
  const [notified, setNotified] = useState(false);

  async function load() {
    try {
      const [rec, miss] = await Promise.all([
        apiGet("/attendance", token),
        apiGet("/attendance/missing-today", token),
      ]);
      setRecords(rec);
      setMissing(miss);
      setUsingDemo(false);
    } catch {
      setRecords(MOCK_RECORDS);
      setMissing(MOCK_MISSING);
      setUsingDemo(true);
    }
  }

  useEffect(() => { load(); }, []);

  async function handleNotify() {
    setNotifying(true);
    try {
      await apiPost("/attendance/notify-missing-today", {}, token);
      setNotified(true);
      setTimeout(() => setNotified(false), 4000);
    } catch {
      // in demo mode there's nothing to notify — fail quietly
    } finally {
      setNotifying(false);
    }
  }

  const today = new Date().toISOString().slice(0, 10);
  const todaysRecords = records?.filter((r) => r.date === today) ?? [];

  if (!records || !missing) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="animate-spin" size={20} style={{ color: "var(--sisal)" }} />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="font-display font-semibold text-xl">Attendance</h1>
          <p className="text-sm mt-0.5" style={{ color: "var(--slate)" }}>
            Fingerprint clock-in records
            {usingDemo && <span className="font-mono text-[10px] px-2 py-0.5 rounded-full ml-2" style={{ background: "rgba(226,163,61,0.15)", color: "#9C6A1E" }}>DEMO DATA</span>}
          </p>
        </div>
        {missing.length > 0 && (
          <button
            onClick={handleNotify}
            disabled={notifying}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium text-white"
            style={{ background: notified ? "var(--sisal-deep)" : "var(--fibre-black)" }}
          >
            {notified ? <CheckCircle2 size={15} /> : <BellRing size={15} />}
            {notifying ? "Sending…" : notified ? "Notified" : `Notify ${missing.length} missing`}
          </button>
        )}
      </div>

      <div className="flex gap-1.5 mb-5 border-b" style={{ borderColor: "var(--border)" }}>
        {[
          { key: "today", label: `Today (${todaysRecords.length})` },
          { key: "all", label: `All records (${records.length})` },
          { key: "missing", label: `Missing today (${missing.length})` },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className="px-3 py-2 text-sm font-medium border-b-2 -mb-px"
            style={{
              borderColor: tab === t.key ? "var(--sisal)" : "transparent",
              color: tab === t.key ? "var(--ink)" : "var(--slate)",
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "missing" ? (
        <div className="rounded-xl overflow-hidden" style={{ border: "1px solid var(--border)", background: "#FFFFFF" }}>
          {missing.length === 0 ? (
            <p className="text-sm text-center py-10" style={{ color: "var(--slate)" }}>Everyone has clocked in today.</p>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: "var(--surface-tint)" }}>
                  {["Code", "Name", "Position"].map((h) => (
                    <th key={h} className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {missing.map((m) => (
                  <tr key={m.id} style={{ borderTop: "1px solid var(--divider)" }}>
                    <td className="px-4 py-2.5 font-mono text-xs">{m.employeeCode}</td>
                    <td className="px-4 py-2.5 font-medium">{m.fullName}</td>
                    <td className="px-4 py-2.5" style={{ color: "var(--slate)" }}>{m.position || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      ) : (
        <div className="rounded-xl overflow-hidden" style={{ border: "1px solid var(--border)", background: "#FFFFFF" }}>
          <table className="w-full text-sm">
            <thead>
              <tr style={{ background: "var(--surface-tint)" }}>
                {["Code", "Name", "Date", "In", "Out", "Hours", "OT", "Status"].map((h) => (
                  <th key={h} className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(tab === "today" ? todaysRecords : records).map((r) => (
                <tr key={r.id} style={{ borderTop: "1px solid var(--divider)" }}>
                  <td className="px-4 py-2.5 font-mono text-xs">{r.employee?.employeeCode}</td>
                  <td className="px-4 py-2.5 font-medium">{r.employee?.fullName}</td>
                  <td className="px-4 py-2.5" style={{ color: "var(--slate)" }}>{r.date}</td>
                  <td className="px-4 py-2.5 font-mono">{fmtTime(r.timeIn)}</td>
                  <td className="px-4 py-2.5 font-mono">{fmtTime(r.timeOut)}</td>
                  <td className="px-4 py-2.5 font-mono">{r.hoursWorked || "—"}</td>
                  <td className="px-4 py-2.5 font-mono">{r.overtimeHours || "—"}</td>
                  <td className="px-4 py-2.5">
                    {r.isLate ? (
                      <span className="font-mono text-[10px] px-2 py-0.5 rounded-full uppercase" style={{ background: "rgba(226,163,61,0.15)", color: "#9C6A1E" }}>Late</span>
                    ) : (
                      <span className="font-mono text-[10px] px-2 py-0.5 rounded-full uppercase" style={{ background: "rgba(47,107,60,0.15)", color: "var(--sisal-deep)" }}>On time</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
