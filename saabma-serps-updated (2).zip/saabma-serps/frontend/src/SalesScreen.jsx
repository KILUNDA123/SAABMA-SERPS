import React, { useEffect, useState } from "react";
import { Plus, Users, ClipboardList, Receipt, X, Loader2, ArrowRight, Ban, Wallet } from "lucide-react";
import { apiGet, apiPost, apiPatch } from "./api";

/* ------------------------------------------------------------------
   Domain constants — mirrors backend/src/modules/{orders,invoices,customers}
   entities and DTOs exactly.
------------------------------------------------------------------- */
const ORDER_STATUS_LABELS = { draft: "Draft", confirmed: "Confirmed", invoiced: "Invoiced", cancelled: "Cancelled" };
const INVOICE_STATUS_LABELS = { draft: "Draft", sent: "Sent", paid: "Paid", overdue: "Overdue" };
const PAYMENT_METHODS = {
  bank_transfer: "Bank transfer",
  cash: "Cash",
  mobile_money: "Mobile money",
  cheque: "Cheque",
  letter_of_credit: "Letter of credit",
};

const kes = (n) => `KES ${new Intl.NumberFormat("en-KE").format(Number(n || 0))}`;

/* ------------------------------------------------------------------
   Mock fallback data
------------------------------------------------------------------- */
const MOCK_CUSTOMERS = [
  { id: "c1", name: "Nordic Fibre Traders AB", country: "Sweden", email: "orders@nordicfibre.se", phone: "+46701234567", outstandingBalance: 182000 },
  { id: "c2", name: "Gulf Cordage Co.", country: "UAE", email: "procure@gulfcordage.ae", phone: "+971501234567", outstandingBalance: 0 },
];

const MOCK_INVENTORY = [
  { id: "i1", name: "Raw sisal bales", unit: "kg" },
  { id: "i3", name: "Finished fibre — grade A", unit: "bales" },
];

const MOCK_ORDERS = [
  { id: "o1", orderNumber: "ORD-2507-0031", customer: { name: "Nordic Fibre Traders AB" }, status: "confirmed", total: 640000, items: [{ description: "Grade A fibre", quantity: 40, unitPrice: 16000 }] },
  { id: "o2", orderNumber: "ORD-2507-0032", customer: { name: "Gulf Cordage Co." }, status: "draft", total: 210000, items: [{ description: "Raw sisal", quantity: 3000, unitPrice: 70 }] },
];

const MOCK_INVOICES = [
  { id: "inv1", invoiceNumber: "INV-2507-0041", customer: { name: "Nordic Fibre Traders AB" }, invoiceDate: "2026-07-05", total: 640000, status: "sent" },
];

function Badge({ children, tone = "neutral" }) {
  const tones = {
    neutral: { bg: "var(--divider)", color: "var(--slate)" },
    live: { bg: "rgba(47,107,60,0.15)", color: "var(--sisal-deep)" },
    warn: { bg: "rgba(226,163,61,0.15)", color: "#9C6A1E" },
    danger: { bg: "rgba(165,78,42,0.12)", color: "var(--danger)" },
  };
  const t = tones[tone] || tones.neutral;
  return (
    <span className="font-mono text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wide" style={{ background: t.bg, color: t.color }}>
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------
   Shared line-item builder — used by both the New Order and New
   Invoice forms, since CreateOrderDto/CreateInvoiceDto share the same
   { inventoryItemId, description, quantity, unitPrice } line shape.
------------------------------------------------------------------- */
function LineItemsEditor({ items, setItems, inventory }) {
  function update(i, field, val) {
    setItems((prev) => prev.map((it, idx) => (idx === i ? { ...it, [field]: val } : it)));
  }
  function add() {
    setItems((prev) => [...prev, { inventoryItemId: "", description: "", quantity: "", unitPrice: "" }]);
  }
  function remove(i) {
    setItems((prev) => prev.filter((_, idx) => idx !== i));
  }
  const total = items.reduce((sum, it) => sum + (Number(it.quantity) || 0) * (Number(it.unitPrice) || 0), 0);

  return (
    <div>
      <div className="flex flex-col gap-2.5">
        {items.map((it, i) => (
          <div key={i} className="flex items-end gap-2">
            <div className="flex-1 min-w-[120px]">
              <label className="text-[10px] block mb-1" style={{ color: "var(--slate)" }}>Stock item</label>
              <select value={it.inventoryItemId} onChange={(e) => update(i, "inventoryItemId", e.target.value)}
                className="text-sm rounded-lg px-2.5 py-1.5 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
                <option value="">Select…</option>
                {inventory.map((inv) => <option key={inv.id} value={inv.id}>{inv.name}</option>)}
              </select>
            </div>
            <div className="flex-1 min-w-[120px]">
              <label className="text-[10px] block mb-1" style={{ color: "var(--slate)" }}>Description</label>
              <input required value={it.description} onChange={(e) => update(i, "description", e.target.value)}
                className="text-sm rounded-lg px-2.5 py-1.5 border w-full" style={{ borderColor: "var(--border)" }} />
            </div>
            <div className="w-24">
              <label className="text-[10px] block mb-1" style={{ color: "var(--slate)" }}>Qty</label>
              <input required type="number" min="0" value={it.quantity} onChange={(e) => update(i, "quantity", e.target.value)}
                className="text-sm rounded-lg px-2.5 py-1.5 border w-full" style={{ borderColor: "var(--border)" }} />
            </div>
            <div className="w-28">
              <label className="text-[10px] block mb-1" style={{ color: "var(--slate)" }}>Unit price</label>
              <input required type="number" min="0" value={it.unitPrice} onChange={(e) => update(i, "unitPrice", e.target.value)}
                className="text-sm rounded-lg px-2.5 py-1.5 border w-full" style={{ borderColor: "var(--border)" }} />
            </div>
            <button type="button" onClick={() => remove(i)} className="mb-1.5 p-1.5 rounded-lg" style={{ color: "var(--danger)" }}>
              <X size={14} />
            </button>
          </div>
        ))}
      </div>
      <button type="button" onClick={add} className="flex items-center gap-1 text-xs font-medium mt-2" style={{ color: "var(--sisal-deep)" }}>
        <Plus size={12} /> Add line
      </button>
      <p className="text-xs font-mono mt-3" style={{ color: "var(--slate)" }}>Line total: {kes(total)}</p>
    </div>
  );
}

/* ------------------------------------------------------------------
   CUSTOMERS TAB
------------------------------------------------------------------- */
function CustomersTab({ token }) {
  const [customers, setCustomers] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: "", country: "", email: "", phone: "" });

  async function load() {
    try { setCustomers(await apiGet("/customers", token)); setUsingDemo(false); }
    catch { setCustomers(MOCK_CUSTOMERS); setUsingDemo(true); }
  }
  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await apiPost("/customers", {
        name: form.name,
        country: form.country || undefined,
        email: form.email || undefined,
        phone: form.phone || undefined,
      }, token);
    } catch { /* demo mode */ }
    setForm({ name: "", country: "", email: "", phone: "" });
    setShowForm(false);
    setSaving(false);
    await load();
  }

  if (!customers) return <p className="text-sm" style={{ color: "var(--slate)" }}>Loading customers…</p>;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm" style={{ color: "var(--slate)" }}>{customers.length} customer{customers.length === 1 ? "" : "s"}</p>
        <button onClick={() => setShowForm((s) => !s)} className="flex items-center gap-1.5 font-display font-semibold text-xs rounded-lg px-3 py-2"
          style={{ background: "var(--fibre-black)", color: "var(--sisal)" }}>
          <Plus size={14} /> New customer
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="rounded-xl p-4 mb-4 flex flex-wrap items-end gap-3" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
          <div className="flex-1 min-w-[160px]">
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Name *</label>
            <input required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border w-full" style={{ borderColor: "var(--border)" }} />
          </div>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Country</label>
            <input value={form.country} onChange={(e) => setForm((f) => ({ ...f, country: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border" style={{ borderColor: "var(--border)" }} />
          </div>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Email</label>
            <input type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border" style={{ borderColor: "var(--border)" }} />
          </div>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Phone</label>
            <input value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
              className="text-sm rounded-lg px-3 py-2 border" style={{ borderColor: "var(--border)" }} />
          </div>
          <button type="submit" disabled={saving} className="font-display font-semibold text-xs rounded-lg px-4 py-2"
            style={{ background: "var(--sisal)", color: "var(--fibre-black)" }}>
            {saving ? "Saving…" : "Create customer"}
          </button>
        </form>
      )}

      <div className="rounded-xl overflow-hidden" style={{ border: "1px solid var(--border)", background: "#FFFFFF" }}>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: "var(--surface-tint)" }}>
              <th className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>Customer</th>
              <th className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>Country</th>
              <th className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>Contact</th>
              <th className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>Outstanding</th>
            </tr>
          </thead>
          <tbody>
            {customers.map((c) => (
              <tr key={c.id} style={{ borderTop: "1px solid var(--divider)" }}>
                <td className="px-4 py-3">{c.name}</td>
                <td className="px-4 py-3 text-xs" style={{ color: "var(--paper-dim)" }}>{c.country ?? "—"}</td>
                <td className="px-4 py-3 text-xs" style={{ color: "var(--paper-dim)" }}>{c.email ?? c.phone ?? "—"}</td>
                <td className="px-4 py-3 font-mono text-xs">
                  {Number(c.outstandingBalance) > 0 ? <Badge tone="warn">{kes(c.outstandingBalance)}</Badge> : <Badge tone="live">Settled</Badge>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {usingDemo && <p className="text-[11px] mt-3" style={{ color: "var(--paper-dim)" }}>Showing demo data.</p>}
    </div>
  );
}

/* ------------------------------------------------------------------
   ORDERS TAB
------------------------------------------------------------------- */
function OrdersTab({ token }) {
  const [orders, setOrders] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [customers, setCustomers] = useState(MOCK_CUSTOMERS);
  const [inventory, setInventory] = useState(MOCK_INVENTORY);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [customerId, setCustomerId] = useState("");
  const [items, setItems] = useState([{ inventoryItemId: "", description: "", quantity: "", unitPrice: "" }]);
  const [busyId, setBusyId] = useState(null);

  async function load() {
    try { setOrders(await apiGet("/orders", token)); setUsingDemo(false); }
    catch { setOrders(MOCK_ORDERS); setUsingDemo(true); }
    try { setCustomers(await apiGet("/customers", token)); } catch {}
    try { setInventory(await apiGet("/inventory", token)); } catch {}
  }
  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await apiPost("/orders", {
        customerId,
        items: items.map((it) => ({ ...it, quantity: Number(it.quantity), unitPrice: Number(it.unitPrice) })),
      }, token);
    } catch { /* demo mode */ }
    setCustomerId("");
    setItems([{ inventoryItemId: "", description: "", quantity: "", unitPrice: "" }]);
    setShowForm(false);
    setSaving(false);
    await load();
  }

  async function act(order, action) {
    setBusyId(order.id);
    try {
      await apiPatch(`/orders/${order.id}/${action}`, {}, token);
      await load();
    } catch {
      const next = action === "confirm" ? "confirmed" : action === "invoice" ? "invoiced" : "cancelled";
      setOrders((prev) => prev.map((o) => (o.id === order.id ? { ...o, status: next } : o)));
    } finally {
      setBusyId(null);
    }
  }

  if (!orders) return <p className="text-sm" style={{ color: "var(--slate)" }}>Loading orders…</p>;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm" style={{ color: "var(--slate)" }}>{orders.length} order{orders.length === 1 ? "" : "s"}</p>
        <button onClick={() => setShowForm((s) => !s)} className="flex items-center gap-1.5 font-display font-semibold text-xs rounded-lg px-3 py-2"
          style={{ background: "var(--fibre-black)", color: "var(--sisal)" }}>
          <Plus size={14} /> New order
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="rounded-xl p-5 mb-4 flex flex-col gap-3.5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
          <div>
            <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Customer *</label>
            <select required value={customerId} onChange={(e) => setCustomerId(e.target.value)}
              className="text-sm rounded-lg px-3 py-2 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
              <option value="">Select customer…</option>
              {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <LineItemsEditor items={items} setItems={setItems} inventory={inventory} />
          <button type="submit" disabled={saving} className="font-display font-semibold text-sm rounded-lg py-2.5">
            <span className="rounded-lg px-4 py-2" style={{ background: "var(--sisal)", color: "var(--fibre-black)" }}>
              {saving ? "Creating…" : "Create order"}
            </span>
          </button>
        </form>
      )}

      <div className="flex flex-col gap-2.5">
        {orders.map((o) => (
          <div key={o.id} className="rounded-xl p-4" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2.5">
                <span className="font-mono text-xs font-medium">{o.orderNumber}</span>
                <Badge tone={o.status === "cancelled" ? "danger" : o.status === "invoiced" ? "live" : "neutral"}>
                  {ORDER_STATUS_LABELS[o.status] || o.status}
                </Badge>
              </div>
              <span className="font-mono text-sm">{kes(o.total)}</span>
            </div>
            <p className="text-sm mb-3">{o.customer?.name ?? "—"}</p>
            <div className="flex items-center gap-2">
              {o.status === "draft" && (
                <button disabled={busyId === o.id} onClick={() => act(o, "confirm")}
                  className="flex items-center gap-1 text-xs font-display font-semibold rounded-lg px-3 py-1.5"
                  style={{ background: "rgba(47,107,60,0.15)", color: "var(--sisal-deep)" }}>
                  <ArrowRight size={12} /> Confirm
                </button>
              )}
              {o.status === "confirmed" && (
                <button disabled={busyId === o.id} onClick={() => act(o, "invoice")}
                  className="flex items-center gap-1 text-xs font-display font-semibold rounded-lg px-3 py-1.5"
                  style={{ background: "rgba(47,107,60,0.15)", color: "var(--sisal-deep)" }}>
                  <Receipt size={12} /> Convert to invoice
                </button>
              )}
              {(o.status === "draft" || o.status === "confirmed") && (
                <button disabled={busyId === o.id} onClick={() => act(o, "cancel")}
                  className="flex items-center gap-1 text-xs font-display font-semibold rounded-lg px-3 py-1.5"
                  style={{ background: "rgba(165,78,42,0.12)", color: "var(--danger)" }}>
                  <Ban size={12} /> Cancel
                </button>
              )}
              {busyId === o.id && <Loader2 size={13} className="animate-spin" style={{ color: "var(--slate)" }} />}
            </div>
          </div>
        ))}
      </div>
      {usingDemo && <p className="text-[11px] mt-3" style={{ color: "var(--paper-dim)" }}>Showing demo data — actions here won't persist.</p>}
    </div>
  );
}

/* ------------------------------------------------------------------
   INVOICES TAB
------------------------------------------------------------------- */
function InvoicesTab({ token }) {
  const [invoices, setInvoices] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [customers, setCustomers] = useState(MOCK_CUSTOMERS);
  const [inventory, setInventory] = useState(MOCK_INVENTORY);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [customerId, setCustomerId] = useState("");
  const [invoiceDate, setInvoiceDate] = useState("");
  const [discount, setDiscount] = useState("");
  const [taxRatePercent, setTaxRatePercent] = useState("");
  const [items, setItems] = useState([{ inventoryItemId: "", description: "", quantity: "", unitPrice: "" }]);
  const [payingId, setPayingId] = useState(null);
  const [payForm, setPayForm] = useState({ amount: "", method: "bank_transfer", paidOn: "", reference: "" });
  const [paySaving, setPaySaving] = useState(false);

  async function load() {
    try { setInvoices(await apiGet("/invoices", token)); setUsingDemo(false); }
    catch { setInvoices(MOCK_INVOICES); setUsingDemo(true); }
    try { setCustomers(await apiGet("/customers", token)); } catch {}
    try { setInventory(await apiGet("/inventory", token)); } catch {}
  }
  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await apiPost("/invoices", {
        customerId,
        invoiceDate,
        items: items.map((it) => ({ ...it, quantity: Number(it.quantity), unitPrice: Number(it.unitPrice) })),
        discount: discount ? Number(discount) : undefined,
        taxRatePercent: taxRatePercent ? Number(taxRatePercent) : undefined,
      }, token);
    } catch { /* demo mode */ }
    setCustomerId(""); setInvoiceDate(""); setDiscount(""); setTaxRatePercent("");
    setItems([{ inventoryItemId: "", description: "", quantity: "", unitPrice: "" }]);
    setShowForm(false);
    setSaving(false);
    await load();
  }

  async function submitPayment(invoice) {
    setPaySaving(true);
    try {
      await apiPost(`/invoices/${invoice.id}/payments`, {
        amount: Number(payForm.amount),
        method: payForm.method,
        paidOn: payForm.paidOn,
        reference: payForm.reference || undefined,
      }, token);
      await load();
    } catch {
      setInvoices((prev) => prev.map((i) => (i.id === invoice.id ? { ...i, status: "paid" } : i)));
    } finally {
      setPaySaving(false);
      setPayingId(null);
      setPayForm({ amount: "", method: "bank_transfer", paidOn: "", reference: "" });
    }
  }

  if (!invoices) return <p className="text-sm" style={{ color: "var(--slate)" }}>Loading invoices…</p>;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm" style={{ color: "var(--slate)" }}>{invoices.length} invoice{invoices.length === 1 ? "" : "s"}</p>
        <button onClick={() => setShowForm((s) => !s)} className="flex items-center gap-1.5 font-display font-semibold text-xs rounded-lg px-3 py-2"
          style={{ background: "var(--fibre-black)", color: "var(--sisal)" }}>
          <Plus size={14} /> New invoice
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="rounded-xl p-5 mb-4 flex flex-col gap-3.5" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
          <div className="grid grid-cols-3 gap-3.5">
            <div className="col-span-1">
              <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Customer *</label>
              <select required value={customerId} onChange={(e) => setCustomerId(e.target.value)}
                className="text-sm rounded-lg px-3 py-2 border w-full bg-white" style={{ borderColor: "var(--border)" }}>
                <option value="">Select…</option>
                {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Invoice date *</label>
              <input required type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)}
                className="text-sm rounded-lg px-3 py-2 border w-full" style={{ borderColor: "var(--border)" }} />
            </div>
            <div className="flex gap-2">
              <div>
                <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Discount</label>
                <input type="number" min="0" value={discount} onChange={(e) => setDiscount(e.target.value)}
                  className="text-sm rounded-lg px-3 py-2 border w-24" style={{ borderColor: "var(--border)" }} />
              </div>
              <div>
                <label className="text-[11px] block mb-1" style={{ color: "var(--slate)" }}>Tax %</label>
                <input type="number" min="0" value={taxRatePercent} onChange={(e) => setTaxRatePercent(e.target.value)}
                  className="text-sm rounded-lg px-3 py-2 border w-20" style={{ borderColor: "var(--border)" }} />
              </div>
            </div>
          </div>
          <LineItemsEditor items={items} setItems={setItems} inventory={inventory} />
          <button type="submit" disabled={saving} className="font-display font-semibold text-sm rounded-lg py-2.5"
            style={{ background: "var(--sisal)", color: "var(--fibre-black)" }}>
            {saving ? "Creating…" : "Create invoice"}
          </button>
        </form>
      )}

      <div className="flex flex-col gap-2.5">
        {invoices.map((inv) => (
          <div key={inv.id} className="rounded-xl p-4" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2.5">
                <span className="font-mono text-xs font-medium">{inv.invoiceNumber}</span>
                <Badge tone={inv.status === "paid" ? "live" : inv.status === "overdue" ? "danger" : "neutral"}>
                  {INVOICE_STATUS_LABELS[inv.status] || inv.status}
                </Badge>
              </div>
              <span className="font-mono text-sm">{kes(inv.total)}</span>
            </div>
            <p className="text-sm mb-1">{inv.customer?.name ?? "—"}</p>
            <p className="text-[11px] mb-3" style={{ color: "var(--paper-dim)" }}>{inv.invoiceDate}</p>

            {inv.status !== "paid" && (
              payingId === inv.id ? (
                <div className="flex flex-wrap items-end gap-2 rounded-lg p-3" style={{ background: "var(--surface-tint)" }}>
                  <div>
                    <label className="text-[10px] block mb-1" style={{ color: "var(--slate)" }}>Amount</label>
                    <input type="number" min="0" value={payForm.amount} onChange={(e) => setPayForm((f) => ({ ...f, amount: e.target.value }))}
                      className="text-sm rounded-lg px-2.5 py-1.5 border w-28" style={{ borderColor: "var(--border)" }} />
                  </div>
                  <div>
                    <label className="text-[10px] block mb-1" style={{ color: "var(--slate)" }}>Method</label>
                    <select value={payForm.method} onChange={(e) => setPayForm((f) => ({ ...f, method: e.target.value }))}
                      className="text-sm rounded-lg px-2.5 py-1.5 border bg-white" style={{ borderColor: "var(--border)" }}>
                      {Object.entries(PAYMENT_METHODS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] block mb-1" style={{ color: "var(--slate)" }}>Paid on</label>
                    <input type="date" value={payForm.paidOn} onChange={(e) => setPayForm((f) => ({ ...f, paidOn: e.target.value }))}
                      className="text-sm rounded-lg px-2.5 py-1.5 border" style={{ borderColor: "var(--border)" }} />
                  </div>
                  <div className="flex-1 min-w-[100px]">
                    <label className="text-[10px] block mb-1" style={{ color: "var(--slate)" }}>Reference</label>
                    <input value={payForm.reference} onChange={(e) => setPayForm((f) => ({ ...f, reference: e.target.value }))}
                      className="text-sm rounded-lg px-2.5 py-1.5 border w-full" style={{ borderColor: "var(--border)" }} />
                  </div>
                  <button onClick={() => submitPayment(inv)} disabled={paySaving || !payForm.amount || !payForm.paidOn}
                    className="text-xs font-display font-semibold rounded-lg px-3 py-1.5" style={{ background: "var(--sisal)", color: "var(--fibre-black)" }}>
                    {paySaving ? "Saving…" : "Save payment"}
                  </button>
                  <button onClick={() => setPayingId(null)} className="text-xs" style={{ color: "var(--paper-dim)" }}>Cancel</button>
                </div>
              ) : (
                <button onClick={() => setPayingId(inv.id)} className="flex items-center gap-1 text-xs font-display font-semibold rounded-lg px-3 py-1.5"
                  style={{ background: "rgba(47,107,60,0.15)", color: "var(--sisal-deep)" }}>
                  <Wallet size={12} /> Record payment
                </button>
              )
            )}
          </div>
        ))}
      </div>
      {usingDemo && <p className="text-[11px] mt-3" style={{ color: "var(--paper-dim)" }}>Showing demo data — actions here won't persist.</p>}
    </div>
  );
}

/* ------------------------------------------------------------------
   ROOT SCREEN
------------------------------------------------------------------- */
const TABS = [
  { key: "customers", label: "Customers", icon: Users },
  { key: "orders", label: "Orders", icon: ClipboardList },
  { key: "invoices", label: "Invoices", icon: Receipt },
];

export default function SalesScreen({ token }) {
  const [tab, setTab] = useState("customers");

  return (
    <div>
      <div className="mb-5">
        <h1 className="font-display font-semibold text-xl">Sales</h1>
        <p className="text-sm mt-0.5" style={{ color: "var(--slate)" }}>
          Quote as an order, confirm it, then invoice it — stock and balances only move once it's real.
        </p>
      </div>

      <div className="flex gap-1.5 mb-5 border-b" style={{ borderColor: "var(--border)" }}>
        {TABS.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className="flex items-center gap-1.5 text-sm font-medium px-3.5 py-2.5 -mb-px border-b-2"
            style={{ borderColor: tab === t.key ? "var(--sisal-deep)" : "transparent", color: tab === t.key ? "var(--ink)" : "var(--slate)" }}>
            <t.icon size={14} /> {t.label}
          </button>
        ))}
      </div>

      {tab === "customers" && <CustomersTab token={token} />}
      {tab === "orders" && <OrdersTab token={token} />}
      {tab === "invoices" && <InvoicesTab token={token} />}
    </div>
  );
}
