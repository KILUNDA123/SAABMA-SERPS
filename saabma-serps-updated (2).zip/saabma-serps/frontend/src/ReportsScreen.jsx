import React, { useEffect, useState } from "react";
import { Loader2, Calendar } from "lucide-react";
import { apiGet } from "./api";

/* ------------------------------------------------------------------
   Mirrors backend/src/modules/reports exactly — all 8 endpoints:
     GET /reports/daily-production?date=YYYY-MM-DD
     GET /reports/monthly-finance?year=YYYY&month=M
     GET /reports/attendance          [fromDate, toDate, employeeId, departmentId]
     GET /reports/washing             [fromDate, toDate]
     GET /reports/inventory           [warehouseId]
     GET /reports/invoices            [fromDate, toDate, status]
     GET /reports/revenue             [fromDate, toDate]
     GET /reports/employee-performance [fromDate, toDate, employeeId]

   Gated on the backend by @Roles(CEO, OPERATIONS_MANAGER, FINANCE) AND
   @RequirePermission('reports.view') — so this screen is only reachable
   for those three roles, and only once their role has been granted
   reports.view (seeded by default; adjustable from the Permissions screen).
   CSV/PDF/Excel export (the DTO's `format` field) isn't wired up here yet —
   the service methods only return JSON today; exporting would need either
   backend support for those formats or a client-side CSV conversion of
   what's already on screen.
------------------------------------------------------------------- */

const REPORTS = [
  { key: "revenue", label: "Revenue" },
  { key: "invoices", label: "Invoices" },
  { key: "monthly-finance", label: "Monthly finance" },
  { key: "daily-production", label: "Daily production" },
  { key: "attendance", label: "Attendance" },
  { key: "washing", label: "Washing" },
  { key: "inventory", label: "Inventory" },
  { key: "employee-performance", label: "Employee performance" },
];

const MOCK_BY_REPORT = {
  revenue: { title: "Revenue Report", summary: { invoiceCount: 400, billedRevenue: 7766036.91, collectedRevenue: 1994147.48, outstandingRevenue: 5771889.43 }, rows: [{ invoiceDate: "2026-04-15", invoiceNumber: "INV-00382", total: 28342.66, status: "paid" }] },
  invoices: { title: "Invoice Report", summary: { totalInvoices: 400, totalValue: 7766036.91, paid: 100, overdue: 100 }, rows: [{ invoiceNumber: "INV-00382", customer: "Nairobi Fibre Traders", total: 28342.66, status: "paid" }] },
  attendance: { title: "Attendance Report", summary: { totalRecords: 700, present: 700, late: 150, overtimeHours: 59 }, rows: [{ employeeCode: "EMP-0006", date: "2026-07-13", timeIn: "06:12", isLate: true }] },
  washing: { title: "Washing Report", summary: { totalJobs: 0, totalKg: 0, totalFee: 0, approved: 0 }, rows: [] },
  inventory: { title: "Inventory Report", summary: { totalItems: 6, totalStock: 7000, lowStockAlerts: 0 }, rows: [{ name: "Detergent", quantity: 1200, reorderLevel: 300 }] },
  "employee-performance": { title: "Employee Performance Report", summary: { totalRecords: 0, totalBoxes: 0, totalWeightKg: 0 }, rows: [] },
  "daily-production": { date: "2026-07-13", boxes: 210, weightKg: 4200, employees: 14, rejected: 3 },
  "monthly-finance": { year: 2026, month: 6, invoiceCount: 154, revenueBilled: 2996759.65, collected: 422305.03, outstanding: 2574454.62 },
};

function fmt(n) {
  if (typeof n !== "number") return String(n);
  return Number.isInteger(n) ? new Intl.NumberFormat("en-KE").format(n) : new Intl.NumberFormat("en-KE", { maximumFractionDigits: 2 }).format(n);
}

function humanize(key) {
  return key.replace(/([A-Z])/g, " $1").replace(/^./, (c) => c.toUpperCase());
}

export default function ReportsScreen({ token }) {
  const [tab, setTab] = useState("revenue");
  const [data, setData] = useState(null);
  const [usingDemo, setUsingDemo] = useState(false);
  const [loading, setLoading] = useState(false);
  const [dateParams, setDateParams] = useState({
    date: new Date().toISOString().slice(0, 10),
    year: String(new Date().getFullYear()),
    month: String(new Date().getMonth() + 1),
  });

  async function load(reportKey) {
    setLoading(true);
    let path = `/reports/${reportKey}`;
    if (reportKey === "daily-production") path += `?date=${dateParams.date}`;
    if (reportKey === "monthly-finance") path += `?year=${dateParams.year}&month=${dateParams.month}`;
    try {
      const result = await apiGet(path, token);
      setData(result);
      setUsingDemo(false);
    } catch {
      setData(MOCK_BY_REPORT[reportKey]);
      setUsingDemo(true);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(tab); }, [tab]);

  const isFlat = tab === "daily-production" || tab === "monthly-finance";
  const summary = isFlat ? data : data?.summary;
  const rows = data?.rows;

  return (
    <div>
      <div className="mb-5">
        <h1 className="font-display font-semibold text-xl">Reports</h1>
        <p className="text-sm mt-0.5" style={{ color: "var(--slate)" }}>
          {data?.title || "Operational and financial reporting"}
          {usingDemo && <span className="font-mono text-[10px] px-2 py-0.5 rounded-full ml-2" style={{ background: "rgba(226,163,61,0.15)", color: "#9C6A1E" }}>DEMO DATA</span>}
        </p>
      </div>

      <div className="flex gap-1.5 mb-5 flex-wrap">
        {REPORTS.map((r) => (
          <button
            key={r.key}
            onClick={() => setTab(r.key)}
            className="px-3 py-1.5 rounded-full text-xs font-medium"
            style={{ background: tab === r.key ? "var(--fibre-black)" : "var(--divider)", color: tab === r.key ? "#FFFFFF" : "var(--slate)" }}
          >
            {r.label}
          </button>
        ))}
      </div>

      {tab === "daily-production" && (
        <div className="flex items-center gap-2 mb-4">
          <Calendar size={14} style={{ color: "var(--slate)" }} />
          <input
            type="date"
            value={dateParams.date}
            onChange={(e) => setDateParams({ ...dateParams, date: e.target.value })}
            onBlur={() => load("daily-production")}
            className="px-3 py-1.5 rounded-lg text-sm"
            style={{ border: "1px solid var(--border)" }}
          />
        </div>
      )}
      {tab === "monthly-finance" && (
        <div className="flex items-center gap-2 mb-4">
          <Calendar size={14} style={{ color: "var(--slate)" }} />
          <input type="number" value={dateParams.year} onChange={(e) => setDateParams({ ...dateParams, year: e.target.value })}
            onBlur={() => load("monthly-finance")} placeholder="Year"
            className="w-20 px-3 py-1.5 rounded-lg text-sm" style={{ border: "1px solid var(--border)" }} />
          <input type="number" min="1" max="12" value={dateParams.month} onChange={(e) => setDateParams({ ...dateParams, month: e.target.value })}
            onBlur={() => load("monthly-finance")} placeholder="Month"
            className="w-20 px-3 py-1.5 rounded-lg text-sm" style={{ border: "1px solid var(--border)" }} />
        </div>
      )}

      {loading || !data ? (
        <div className="flex items-center justify-center py-24">
          <Loader2 className="animate-spin" size={20} style={{ color: "var(--sisal)" }} />
        </div>
      ) : (
        <>
          {summary && (
            <div className="grid gap-3 mb-5" style={{ gridTemplateColumns: `repeat(${Math.min(Object.keys(summary).length, 4)}, minmax(0, 1fr))` }}>
              {Object.entries(summary).map(([k, v]) => (
                <div key={k} className="rounded-xl p-4" style={{ background: "#FFFFFF", border: "1px solid var(--border)" }}>
                  <p className="font-mono text-xl font-medium" style={{ color: "var(--ink)" }}>{fmt(v)}</p>
                  <p className="text-xs mt-0.5" style={{ color: "var(--slate)" }}>{humanize(k)}</p>
                </div>
              ))}
            </div>
          )}

          {Array.isArray(rows) && rows.length > 0 && (
            <div className="rounded-xl overflow-hidden" style={{ border: "1px solid var(--border)", background: "#FFFFFF" }}>
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ background: "var(--surface-tint)" }}>
                    {Object.keys(rows[0]).map((h) => (
                      <th key={h} className="text-left font-medium px-4 py-2.5" style={{ color: "var(--slate)" }}>{humanize(h)}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.slice(0, 50).map((row, i) => (
                    <tr key={i} style={{ borderTop: "1px solid var(--divider)" }}>
                      {Object.values(row).map((v, j) => (
                        <td key={j} className="px-4 py-2.5 font-mono text-xs">{typeof v === "number" ? fmt(v) : String(v)}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
              {rows.length > 50 && (
                <p className="text-xs text-center py-2.5" style={{ color: "var(--paper-dim)" }}>Showing first 50 of {rows.length} rows</p>
              )}
            </div>
          )}

          {Array.isArray(rows) && rows.length === 0 && (
            <p className="text-sm text-center py-16" style={{ color: "var(--slate)" }}>No records for this report yet.</p>
          )}
        </>
      )}
    </div>
  );
}
