# Saabma SERPS — Frontend

Login + dashboard screens for the backend in `../backend`, built with Vite + React + Tailwind.

Themed off the Saabma logo: sisal-green (`#7EC93A`) against a warm near-black, with a
"strand meter" motif (bundles of vertical bars) standing in for sisal fibre and for the
batch-traceability idea that runs through the backend. Fonts: Space Grotesk (headings),
Inter (body), IBM Plex Mono (all numeric/stat data).

## Setup

```bash
cd frontend
npm install
npm run dev
```

Open the printed local URL (default `http://localhost:5173`).

## Connecting to the backend

Open `src/App.jsx` and set:

```js
const API_BASE_URL = "http://localhost:3000"; // your running NestJS backend
```

The login form sends exactly what the backend's `LoginDto` expects
(`email`, `password`, `latitude`, `longitude`, `accuracyMeters`), and won't submit until
the browser has actually returned a location — matching the backend's forced-location
login rule. The dashboard calls `GET /dashboard`, matching `DashboardOverviewPayload`
field-for-field.

If the backend isn't reachable, the app falls back to realistic mock data and shows a
"DEMO DATA" badge in the top bar, so the UI is never a dead screen while you're wiring
things up.

## What's here

- `src/App.jsx` — `LoginScreen` and `DashboardScreen`, plus the `StrandMeter` / `StrandSpinner`
  signature components
- `src/index.css` — theme tokens (`--sisal`, `--fibre-black`, etc.) and the strand-pulse animation
- `tailwind.config.js` — brand colors and font families wired into Tailwind utilities

## What's not here yet

Login, Dashboard, Production, Shipments, Warehouse, and Sales are built. The nav rail
still links to Reports but that screen isn't implemented yet.
