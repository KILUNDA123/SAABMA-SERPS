/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        sisal: "#7EC93A",
        "sisal-deep": "#5FA828",
        fibre: "#14150F",
        ink: "#1D1F17",
        paper: "#F6F4EC",
        "paper-dim": "#9A9C8C",
        rope: "#C9A66B",
        slate2: "#63665A",
        amber2: "#E2A33D",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
        mono: ["'IBM Plex Mono'", "monospace"],
      },
    },
  },
  plugins: [],
};
