# Saabma SERPS — Backend

A working NestJS + TypeORM + PostgreSQL backend for Saabma's sisal fibre processing and export operations. Every feature described below has been built, then actually run against a live PostgreSQL database with real HTTP requests to verify it behaves correctly - not just written and assumed to work.

## Full schema (35+ tables across every business area)

**Auth / people / access control**
`users`, `roles`, `permissions` (fine-grained, see below), `departments`, `shifts`, `employees`, `attendance_records`, `login_events`

**Production flow (batch traceability)**
`batches`, `soaking_records`, `washing_records`, `drying_records`, `production_records`, `brushing_records`, `baling_records`

**Warehouse / stock / procurement**
`inventory_items`, `warehouses`, `stock_movements`, `suppliers`, `purchases`, `purchase_items`

**Sales / finance**
`customers`, `orders`, `order_items`, `invoices`, `invoice_items`, `payments`

**Export / logistics**
`vehicles`, `drivers`, `containers`, `shipments`, `documents`

**System**
`notifications`, `approvals`, `audit_logs`

## What's built and verified working

### Authentication & access control
- JWT login/register, password hashing via `bcryptjs`
- **Location is mandatory at login** - a login request with no `latitude`/`longitude` is rejected (400) before it ever reaches the auth logic. This is what "forces" the client (web/mobile) to have already requested and obtained device location before the login form can be submitted.
- Every successful login writes a permanent `login_events` row: coordinates, accuracy, resolved address, IP, user agent, timestamp. Verified live and confirmed the rows persist in Postgres across server restarts.
- **Google Maps reverse geocoding** (`GeoService`) turns coordinates into a human-readable address. Requires a `GOOGLE_MAPS_API_KEY` in `.env` (get one at https://console.cloud.google.com/google/maps-apis, enable "Geocoding API"). **Important honesty note**: this sandbox environment cannot reach `maps.googleapis.com` (network is locked to package registries only), so the live Google API call itself could not be tested end-to-end here. What IS verified: the code compiles, runs, and correctly falls back to storing raw coordinates with `resolvedVia: "unavailable"` when no key is configured - so login never breaks because of this feature. Test the real API call once you add a key and run this outside the sandbox.
- `JwtAuthGuard` (any valid token) and `RolesGuard` + `@Roles(...)` (restrict to specific broad roles) protect routes - proven throughout by testing that the wrong role gets 403.
- **Fine-grained permissions** (`PermissionsGuard` + `@RequirePermission('code')`) sit on top of the broad roles as an optional second layer. Verified live on the `/reports` endpoints: a CEO account (which passes the broad `@Roles` check) was still blocked with 403 until `reports.view` was explicitly granted to the `ceo` role via `POST /permissions/grant` - proving this is real enforcement, not decoration. Manage via `POST /permissions/grant`, `DELETE /permissions/revoke/:role/:code`, `GET /permissions/role/:role`.

### Biometrics & attendance (fingerprint clock-in/out)
- `POST /biometrics/enroll` (HR/Admin/CEO only) - links a fingerprint template to an employee. **Real hardware note**: this backend never touches a raw fingerprint image - it stores whatever opaque template string a scanner vendor's SDK produces (ZKTeco, Suprema, DigitalPersona, etc. all provide one). Wiring an actual physical scanner means calling this endpoint from that vendor's SDK.
- `POST /biometrics/scan` - the door controller calls this on every scan. No login required (it's a device integration point, not a user-facing endpoint) but an unrecognized fingerprint template is rejected (404). The system automatically figures out clock-in vs clock-out: no open record for today -> clock in; an open record exists -> clock out, with hours worked and overtime calculated automatically.
- Verified live: enrolled a fingerprint, scanned it (clock in), scanned it again (clock out, hours calculated), tried an unrecognized template (404), confirmed a non-HR user is blocked from enrolling (403).
- `GET /attendance/missing-today` - active employees with no attendance record today, feeding an eventual "attendance missing -> HR notified" flow.

### Driver & staff login (Google Maps ready)
- Drivers are `User` accounts (role `driver`) like any other staff, so they get the same forced-location login and JWT auth as everyone else - no separate login system needed.
- `Driver` entity links to an optional `User` account (`vehicles` module) so a driver's identity, license, and assigned vehicle are tracked alongside their login.

### Production flow (soaking -> washing -> drying -> brushing -> baling -> warehouse)
Every stage has submit -> pending -> supervisor-only review -> approvals audit trail. Approving a stage automatically advances `batch.currentStage`. Verified live by pushing a real batch through the entire chain and confirming the stage at every step, not assuming it.

Brushing automatically calculates labour cost (operator + each helper's daily rate) - verified with a real 3-person crew, correct total.

### Warehouse & stock
Approving a baling record automatically credits real inventory (finds-or-creates a "Finished Sisal Fibre" item, records a traceable `IN` stock movement referencing the exact batch number). Verified across two separate baling approvals that stock correctly accumulates on the same item rather than duplicating.

### Sales: orders -> invoices -> payments (with real stock deduction)
- `POST /orders` - a draft commitment to sell. **Does not touch stock or the customer's balance yet** - verified live that stock stays unchanged after creating and confirming an order.
- `PATCH /orders/:id/invoice` - converts the order into a real `Invoice`, which is the moment stock actually gets deducted (via the same `WarehouseService.recordMovement` pattern baling uses, but as an `OUT` movement) and the customer's outstanding balance increases. Verified: order for 100kg confirmed and invoiced -> stock dropped by exactly 100kg, invoice total correct, re-invoicing the same order blocked (400).
- Invoices can also be created directly (`POST /invoices`) without going through an order, for simpler one-off sales - verified insufficient-stock requests are rejected with a clear message before anything is committed.
- `POST /invoices/:id/payments` - partial and full payment recording verified: a partial payment reduces the customer's balance and leaves the invoice `sent`; the remaining balance being paid flips it to `paid` automatically.

### Shipments / cargo tracking
`POST /shipments/containers`, `POST /shipments` (attach one or more batches, a container, vehicle, and driver to a shipment), `PATCH /shipments/:id/status`. Verified live: created a container, attached a real batch to a new shipment, updated its status to `loaded`.

### Reports & dashboard
- `GET /reports/daily-production?date=YYYY-MM-DD`, `GET /reports/monthly-finance?year=&month=` - the finance report correctly separates what was billed (from `Invoice`) from what was actually collected (from `Payment`), rather than storing a redundant "amount paid" column that could drift out of sync. Verified with real numbers: 2 invoices, correct billed/collected/outstanding split.
- `GET /dashboard/cards` (CEO/Ops Manager only) - live counts of present/absent staff, customers, inventory item types, low-stock alerts, pending approvals, and today's revenue. Verified every number against the actual underlying data.

### System-wide audit trail
A global interceptor (`AuditInterceptor`) writes a row to `audit_logs` on every POST/PATCH/PUT/DELETE across the entire API - who did it, what route, the response body (with any password hash stripped as a defense-in-depth measure even though it was already excluded from responses). Verified the table fills up correctly across logins, invoices, customer creation, and biometric enrollment without needing each module to wire up its own logging.

### Notifications
`NotificationsService.notifyRole(role, ...)` broadcasts to every active user currently holding a given role (no single user "is" the CEO or HR, so this is how role-based alerts actually work). `GET /notifications`, `GET /notifications/unread`, `PATCH /notifications/:id/read`, `PATCH /notifications/read-all` - a user can only ever see and mark their own notifications (identity comes from the JWT, never a URL parameter - verified that one user cannot mark another user's notification as read, gets 404 rather than leaking that it exists).

Wired into the four flows the original plan specifically called out, and verified live for each:
- **Invoice fully paid -> CEO + Finance notified.** Paid off a real invoice; both roles received a notification with the correct invoice number and amount.
- **Stock crosses reorder level -> Warehouse notified.** Set a reorder level on a real inventory item, sold enough stock to cross below it, confirmed the Warehouse role got an alert with the exact remaining quantity - and confirmed NO alert fires for items with reorder tracking left at 0 (off).
- **Shipment loaded -> Operations Manager notified.** Updated a real shipment's status to `loaded`, confirmed the Operations Manager role received it.
- **Attendance missing -> HR notified.** `POST /attendance/notify-missing-today` - manually triggered rather than an automatic daily cron, since this sandbox has no reliable way to verify a scheduled job actually fires on time. Verified live: correctly listed and notified about the 3 employees with no attendance record that day. Wiring `@nestjs/schedule` for a real daily cron is a small follow-up once this runs somewhere persistent.

### Export document generation (real PDFs, not templates)
`POST /documents/generate` produces an actual PDF using `pdfkit`, pulling live data from the shipment/invoice it's generating from - not a static template. `GET /documents/:id/download` streams the file back. Covers all five document types from the original plan:
- **Packing list** - batches in a shipment, weights, container, destination
- **Certificate of origin** - formal declaration, batch numbers, total weight, Kenya as country of origin
- **Cargo manifest** - container/seal, vehicle, driver, batch weights
- **Delivery note** - generated from an invoice's line items
- **Export declaration** - combines a shipment with an optional linked invoice for declared value

**Verified live, not just assumed working**: generated a real packing list, downloaded it, confirmed with the `file` command that it's a genuine PDF (not corrupted output), then used `pdfplumber` to extract its text and confirmed every real data point (shipment number, customer, destination, batch, total weight) rendered correctly. Repeated for all five document types. One real bug caught and fixed along the way: `import PDFDocument from 'pdfkit'` type-checked fine but crashed at runtime (`pdfkit_1.default is not a constructor`) because `@types/pdfkit`'s type declarations don't match how the package's CommonJS export actually behaves without `esModuleInterop`. Fixed with `import PDFDocument = require('pdfkit')`, which sidesteps the mismatch - confirmed by inspecting the compiled JS output before and after.

Storage note: generated PDFs are saved to local disk (`backend/storage/documents/`) for now. In production this should be MinIO/S3, matching the original plan's storage section - swapping the storage backend only requires changing `DocumentsService`'s file read/write calls, not the PDF generation logic itself.

### Versioned database migrations
Schema changes are now tracked as versioned TypeORM migrations instead of relying on `synchronize: true` reshaping the database automatically. `synchronize` is now **off by default** (`DB_SYNCHRONIZE=true` in `.env` re-enables it for fast prototyping if you want it back temporarily).

**This was verified for real, not just written:**
1. Created a genuinely empty database and ran `npm run migration:generate` against it - produced a real, complete `InitialSchema` migration (~42KB of actual SQL statements covering all 38 tables and every foreign key).
2. Ran `npm run migration:run` against that empty database - it built the entire schema from nothing, and the app booted and handled a real login against it correctly (including the location-forced login flow writing to `login_events`).
3. **Then the important check**: does this migration match the *existing* development database (built incrementally via `synchronize: true` across many earlier sessions)? Marked the migration as already-applied on that database, then asked TypeORM to diff the entities against it again - it reported **"No changes in database schema were found"**, meaning the migration is byte-for-byte equivalent to the real, live, already-in-use schema. Confirmed the app boots against that database with `synchronize: false` and all pre-existing data (invoices, customers, batches) survived untouched.

Migration commands:
```bash
npm run migration:generate -- src/migrations/DescriptiveName   # after changing an entity
npm run migration:run       # apply pending migrations
npm run migration:revert    # undo the last migration
npm run migration:show      # list applied / pending migrations
```
`migrationsRun: true` by default means pending migrations run automatically when the app boots (set `DB_AUTO_MIGRATE=false` to disable this and run them manually instead, e.g. as a separate CI/CD step before deploying).

## A note on an uploaded codebase reviewed mid-project

Partway through this build, a `.rar` archive was uploaded containing a more extensive-looking version of this same project (with a frontend, migrations, tests, and extra modules). On inspection, several of its files had genuine, verifiable bugs - duplicate class declarations in `invoice.entity.ts`, `customer.entity.ts`, and `payment.entity.ts` (would not compile), and `app.module.ts` referencing five modules it never imported (guaranteed compile failure). Its README was a verbatim copy of an earlier version of this document, suggesting it was an unverified extension of an earlier export of this project, done elsewhere. The good ideas in it (orders, cargo tracking, reports, dashboard, fine-grained permissions) were rebuilt properly here, tested against a live database, rather than adopting the broken code directly.

## Setup

```bash
cd backend
npm install
cp .env.example .env
```

Fill in `.env`:
- `JWT_SECRET` - any long random string
- `GOOGLE_MAPS_API_KEY` - optional; login/attendance/everything else works fine without it, you just won't get resolved addresses on login events

Start Postgres (from project root):
```bash
docker compose up -d
```

Run the backend:
```bash
cd backend
npm run start:dev
```

TypeORM auto-creates all tables on first connect (`synchronize: true` in dev - switch to migrations before production).

## Frontend

A login + dashboard frontend now lives in `../frontend` (Vite + React + Tailwind),
themed off the Saabma logo. See `frontend/README.md` for setup. It calls this backend's
real `POST /auth/login` and `GET /dashboard` endpoints (with a mock-data fallback if the
API isn't reachable yet), but only those two screens are built so far - Production,
Warehouse, Sales, Shipments, and Reports are still just nav placeholders.

## What's still not built (honest list)
1. **A real scheduler for attendance-missing** - currently a manually-triggered endpoint (`POST /attendance/notify-missing-today`); wiring `@nestjs/schedule` for an automatic daily run is a small follow-up.
2. **Most of the frontend** - only login + dashboard are built so far (see above).
3. **Google Maps reverse geocoding** - code is correct and gracefully degrades, but the actual live API call has not been tested end-to-end (see honesty note above) since this sandbox cannot reach Google's servers.
4. **Notification delivery beyond in-app** - notifications are stored and queryable via the API, but nothing pushes them out as email/SMS/push yet.
5. **Document storage is local disk, not S3/MinIO** - fine for development, but production should move to object storage (see note above).
